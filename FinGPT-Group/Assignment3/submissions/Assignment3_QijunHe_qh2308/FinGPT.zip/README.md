# FinGPT Part 2

Inference-only financial news pipeline for turning news into trading signals.

The repository has three main workflows:

1. Live news ingestion: fetch recent news from Alpaca or Finnhub, then run Agent 1 and Agent 2 end to end.
2. Historical backtesting: run the same pipeline on an existing CSV, parquet file, or Hugging Face dataset.
3. Alpaca weekly backtest prep: fetch Alpaca news by weekly windows, build a backtest dataset, and optionally run the existing backtester on top of it.

The core design is consistent across all modes: the model is not asked to self-report probabilities. We read real token log-probabilities from vLLM, then apply deterministic Python-side calibration, PMI correction, and signal filters.

## Current Architecture

- `Agent 1` in [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py) builds a `NewsFingerprint`
- `Agent 2` in [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py) converts that fingerprint into a `TradingSignal`
- [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py) runs the live fetch-to-signal path
- [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py) runs historical backtests and computes metrics
- [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py) builds weekly Alpaca datasets and can launch the backtest stage
- [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py) runs offline hyperparameter sweeps without rerunning the LLM

## Repository Layout

```text
FinGPT_Part2/
|- agent1/
|- agent2/
|- backtest/
|- configs/
|- docs/
|- evaluation/
|- ingestion/
|- notebooks/
|- output/
|- tests/
|- config.py
|- pipeline.py
|- vllm_logits_client.py
`- README.md
```

Useful docs:

- English development guide: [docs/DEVELOPMENT.md](/C:/Project/FinGPT/FinGPT_Part2/docs/DEVELOPMENT.md)
- Chinese summary: [docs/summary.md](/C:/Project/FinGPT/FinGPT_Part2/docs/summary.md)
- Chinese Alpaca weekly guide: [docs/alpaca_weekly_backtest_guide_zh.md](/C:/Project/FinGPT/FinGPT_Part2/docs/alpaca_weekly_backtest_guide_zh.md)
- Chinese Alpaca output-column reference: [docs/alpaca_weekly_backtest_columns_zh.md](/C:/Project/FinGPT/FinGPT_Part2/docs/alpaca_weekly_backtest_columns_zh.md)

## How The Signal Is Computed

### Agent 1

Agent 1 performs three model-assisted steps:

1. Guided extraction of metadata such as `source`, `published_at`, and `companies_named`
2. Sentiment scoring over `POSITIVE`, `NEGATIVE`, and `NEUTRAL`
3. Event-type scoring over `A-G`, mapped to labels such as `EARNINGS`, `GUIDANCE`, and `MACRO`

The final output is a `NewsFingerprint` object defined in [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py).

### Agent 2

Agent 2 scores the strategy choices `A/B/C`, mapped to:

- `A -> BUY -> long`
- `B -> HOLD -> neutral`
- `C -> SELL -> short`

The raw strategy logits can be PMI-corrected before softmax:

```text
adjusted_logit = raw_logit - alpha * null_logprob
```

This is then followed by confidence, margin, buy-threshold, and sell-threshold filtering. The final output is a `TradingSignal` object defined in [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py).

## Installation

Install Python dependencies:

```bash
pip install -r requirements.txt
```

This project expects local model weights accessible through `FINGPT_MODEL_PATH`, plus API keys for whichever news provider you use.

## Environment Variables

Main settings live in [config.py](/C:/Project/FinGPT/FinGPT_Part2/config.py).

Important variables:

| Variable | Purpose |
|---|---|
| `FINGPT_MODEL_PATH` | Path to local model weights |
| `FINGPT_ADAPTER_PATH` | Optional adapter path |
| `SHARE_SINGLE_LLM_BETWEEN_AGENTS` | Reuse one engine across both agents |
| `NEWS_PROVIDER` | `alpaca` or `finnhub` |
| `ALPACA_API_KEY` / `ALPACA_API_SECRET` | Alpaca credentials |
| `FINNHUB_API_KEY` | Finnhub credential |
| `FINGPT_CALIBRATION_T` | Softmax calibration temperature |
| `FINGPT_PMI_ALPHA` | PMI correction strength |
| `FINGPT_SIGNAL_MIN_CONFIDENCE` | Force-hold threshold on top probability |
| `FINGPT_SIGNAL_MIN_MARGIN` | Force-hold threshold on top1-top2 margin |
| `FINGPT_BUY_THRESHOLD` | Minimum probability to emit `BUY` |
| `FINGPT_SELL_THRESHOLD` | Minimum probability to emit `SELL` |
| `FINGPT_SIGNAL_USE_COT` | Whether Agent 2 generates CoT before scoring |
| `FINGPT_BACKTEST_BATCH_SIZE` | Batch size for backtests |
| `FINGPT_PMI_PRIOR_PATH` | Optional cache path for null-context PMI priors |

Current notable defaults in code:

- `NEWS_PROVIDER="alpaca"`
- `FINGPT_PMI_ALPHA=0.0`
- `FINGPT_SIGNAL_USE_COT=False`
- `FINGPT_BACKTEST_STRICT_MODE=False`
- `FINGPT_BACKTEST_BATCH_SIZE=10`

## Live Pipeline

The live entry point is [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py).

It:

1. Fetches recent news from Alpaca or Finnhub
2. Keeps only articles with `created_at <= as_of_timestamp`
3. Keeps the latest eligible article per requested ticker
4. Builds `article_text = headline + summary`
5. Runs Agent 1 then Agent 2
6. Saves `output/signals_<timestamp>.json`

## Standard Backtest

Run the main backtester on an existing dataset:

```bash
python -m backtest.run_backtest --dataset path/to/dataset.csv --output output/backtest_results.csv --metrics
```

Useful options:

```bash
python -m backtest.run_backtest --dataset path/to/dataset.csv --max-rows 50 --batch-size 10 --metrics
python -m backtest.run_backtest --resume-csv output/backtest_results.csv --output output/backtest_repriced.csv --metrics
```

Supported inputs include:

- local `.csv`
- local `.parquet`
- compatible Hugging Face datasets through the dataset parser

## Alpaca Weekly Backtest Workflow

The config-driven Alpaca pipeline is separate from the standard live path. It fetches news in weekly windows and materializes a dataset for the backtester.

Example config: [configs/alpaca_backtest.example.json](/C:/Project/FinGPT/FinGPT_Part2/configs/alpaca_backtest.example.json)

Build dataset only:

```bash
python -m backtest.run_alpaca_backtest --config configs/alpaca_backtest.example.json --dataset-only
```

Build dataset and run the existing backtest:

```bash
python -m backtest.run_alpaca_backtest --config configs/alpaca_backtest.example.json
```

What this workflow does:

1. Splits the configured date range into rolling 7-day weekly windows
2. Fetches Alpaca news separately for each `symbol x week`
3. Caches normalized news plus a config fingerprint under `output/alpaca_news_cache/`
4. Combines up to `combine_articles_per_sample` articles into one dataset row
5. Marks empty weeks as `no_signal` / `no_article_provided` without calling the LLM
6. Optionally runs the standard backtester on the generated dataset CSV

The main implementation is in [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py).

## Offline Grid Search

Once you already have a backtest CSV with raw Agent 2 logits, you can sweep hyperparameters without rerunning inference.

Implemented in [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py):

- PMI alpha sweeps
- confidence sweeps
- joint alpha-confidence sweeps
- mixed strategy alpha-confidence-margin sweeps
- long-only alpha-confidence-margin sweeps
- no-PMI convenience wrappers

This is useful for turning one expensive inference run into many cheap offline evaluations.

## Notebooks

- [notebooks/demo.ipynb](/C:/Project/FinGPT/FinGPT_Part2/notebooks/demo.ipynb): end-to-end demo and backtest flow
- [notebooks/resume_backtest.ipynb](/C:/Project/FinGPT/FinGPT_Part2/notebooks/resume_backtest.ipynb): reprice, rescore, and run offline grid search from an existing CSV
- [notebooks/alpaca_weekly_backtest.ipynb](/C:/Project/FinGPT/FinGPT_Part2/notebooks/alpaca_weekly_backtest.ipynb): weekly Alpaca dataset generation and optional backtest execution

## Testing

Run the test suite with:

```bash
pytest
```

There are targeted tests for:

- news fetching
- PMI grid search
- Alpaca weekly dataset generation

## Output Artifacts

Typical outputs:

- `output/signals_<timestamp>.json`
- `output/backtest_results.csv`
- `output/*_metrics.json`
- `output/alpaca_news_backtest_dataset.csv`
- `output/alpaca_news_backtest_results.csv`
- `output/dashboard/*.html`

## Notes

- The repo currently contains some historical markdown files with encoding damage; the maintained versions are under `docs/`.
- If you are changing prompts, scoring rules, or filters, read [docs/DEVELOPMENT.md](/C:/Project/FinGPT/FinGPT_Part2/docs/DEVELOPMENT.md) first because it maps the codepaths and data contracts in more detail.
