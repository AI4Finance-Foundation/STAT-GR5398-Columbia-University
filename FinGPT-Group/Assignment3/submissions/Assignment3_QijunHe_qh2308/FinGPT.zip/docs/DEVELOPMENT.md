# FinGPT Part 2 Development Guide

This guide reflects the repository as it exists now. It is meant to help you change code safely, understand which workflow you are touching, and know where each decision is made.

## Scope

There are now three first-class workflows in this repo:

1. Live news-to-signal inference via [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py)
2. Historical backtesting via [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py)
3. Config-driven Alpaca weekly dataset generation via [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py)

The two-agent inference core is shared across the first two, and the Alpaca weekly flow feeds the second one.

## Main Modules

- [config.py](/C:/Project/FinGPT/FinGPT_Part2/config.py): environment loading and runtime constants
- [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py): live orchestration
- [vllm_logits_client.py](/C:/Project/FinGPT/FinGPT_Part2/vllm_logits_client.py): vLLM wrapper and softmax utilities
- [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py): extraction, sentiment scoring, event-type scoring
- [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py): `NewsFingerprint`
- [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py): signal scoring, PMI prior handling, signal filters
- [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py): `TradingSignal`
- [backtest/dataset_parser.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/dataset_parser.py): input normalization for backtests
- [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py): end-to-end historical evaluation
- [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py): offline post-processing sweeps
- [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py): weekly Alpaca news fetch, cache, dataset materialization
- [ingestion/news_fetcher.py](/C:/Project/FinGPT/FinGPT_Part2/ingestion/news_fetcher.py): live-provider fetch layer

## Data Contracts

### `NewsFingerprint`

Defined in [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py).

Important current fields:

- upstream metadata: `ticker`, `headline`, `source`, `published_at`
- sentiment outputs: `sentiment_label`, `sentiment_confidence`, `sentiment_probabilities`, `sentiment_logits`
- event outputs: `event_type`, `event_type_confidence`, `event_type_margin`, `event_type_method`
- passthrough text: `article_text`

Current behavior to remember:

- `ticker` is treated as upstream truth, not re-inferred from named companies
- `headline` is preserved when the caller provides it
- `event_keywords` is compatibility-oriented and effectively derived from the final event label

### `TradingSignal`

Defined in [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py).

Important current fields:

- `direction`
- `confidence`
- `raw_signal_logits`
- `pmi_null_logprobs`
- `signal_logits`
- `signal_probabilities`
- `signal_filter_forced_hold`
- `signal_filter_reason`
- `strategy_tag`

Current behavior to remember:

- `strategy_tag` is fixed to `"event_driven"`
- CoT is optional and governed by `FINGPT_SIGNAL_USE_COT`

## Live Workflow

Entry point: [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py)

Current flow:

1. `run_pipeline(tickers, limit, as_of_timestamp)` calls the ingestion layer
2. [ingestion/news_fetcher.py](/C:/Project/FinGPT/FinGPT_Part2/ingestion/news_fetcher.py) fetches from Alpaca or Finnhub
3. The fetch layer keeps only articles at or before `as_of_timestamp`
4. It keeps the latest eligible article per requested ticker
5. The pipeline builds `article_text = headline + " " + summary`
6. Agent 1 produces a fingerprint
7. Agent 2 produces a signal
8. Results are saved to `output/signals_<timestamp>.json`

Important live assumptions:

- `ticker` and `headline` come from the fetch layer
- Agent 2 consumes the fingerprint contract, not a fresh provider payload

## Standard Backtest Workflow

Entry points:

- [backtest/run_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_backtest.py)
- [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py)

Current flow:

1. Load a dataset from CSV, parquet, or a compatible Hugging Face source
2. Normalize rows through [backtest/dataset_parser.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/dataset_parser.py)
3. Build per-row fields such as `ticker`, `headline`, `article_text`, `start_date`, `end_date`, and `fingpt_label`
4. Run Agent 1 in batches
5. Run Agent 2 in batches
6. Fetch realized returns
7. Flatten everything into an output CSV
8. Optionally compute or re-compute metrics

Useful CLI behaviors:

- `--batch-size` overrides `FINGPT_BACKTEST_BATCH_SIZE`
- `--resume-csv` reprices an existing CSV without rerunning Agent 1 or Agent 2
- `--metrics` prints the summary table after completion

## Alpaca Weekly Backtest Workflow

Entry points:

- [backtest/run_alpaca_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_alpaca_backtest.py)
- [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py)

This flow exists to build a backtest dataset directly from Alpaca news instead of starting from an already-packaged dataset.

Current flow:

1. Load JSON config from [configs/alpaca_backtest.example.json](/C:/Project/FinGPT/FinGPT_Part2/configs/alpaca_backtest.example.json)
2. Validate and normalize the config into `AlpacaBacktestConfig`
3. Split the configured period into rolling 7-day windows
4. For each `symbol x week`, fetch Alpaca news with retry and rate limiting
5. Cache normalized results under `cache_dir`
6. Combine up to `combine_articles_per_sample` articles into one backtest row
7. For empty weeks, emit a skip row with `forced_signal="no_signal"` and `skip_reason="no_article_provided"`
8. Save the dataset CSV
9. Optionally run the standard backtester on that dataset

Important implementation details:

- Cache reuse is controlled by a config fingerprint, not only file existence
- `frequency` currently supports only `"weekly"`
- `start_date` is the next US trading day after the weekly news window ends
- `end_date` is `holding_period_days` after `start_date`, moved forward to the next valid US trading day if needed

## Agent 1 Internals

Main code: [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py)

Agent 1 currently has three model-assisted stages:

### 1. Guided extraction

Prompt source: [agent1/prompt.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/prompt.py)

Requested fields include:

- `source`
- `published_at`
- `companies_named`
- `event_keywords`

Current degradation behavior:

- Extraction parsing failure does not necessarily kill the row
- The code can fall back to an empty extraction payload so later stages still run

### 2. Sentiment scoring

Label set:

- `POSITIVE`
- `NEGATIVE`
- `NEUTRAL`

Current behavior:

- Uses logits instead of free-form model prose as the decision source
- Applies temperature calibration with `CALIBRATION_T`
- Falls back to neutral/uniform style defaults if logits processing fails

### 3. Event-type scoring

Score tokens:

- `A`, `B`, `C`, `D`, `E`, `F`, `G`

Current mapping:

- `A -> EARNINGS`
- `B -> GUIDANCE`
- `C -> ANALYST_RATING`
- `D -> LEGAL_REGULATORY`
- `E -> MNA`
- `F -> PRODUCT_BUSINESS`
- `G -> MACRO`

Important behavior:

- `OTHER` is not model-scored
- `OTHER` is assigned in Python when confidence or margin thresholds are missed

## Agent 2 Internals

Main code: [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py)

### Null-context PMI prior

Agent 2 can compute and cache one null-context `A/B/C` prior:

- in memory for the current session
- optionally on disk via `FINGPT_PMI_PRIOR_PATH`

This prior is then used as:

```text
adjusted = raw - pmi_alpha * null
```

### Strategy scoring

Current strategy token mapping:

- `A -> BUY -> long`
- `B -> HOLD -> neutral`
- `C -> SELL -> short`

Current post-processing stages:

1. Optional CoT generation
2. A/B/C logprob scoring
3. Optional PMI correction
4. Softmax calibration
5. Signal filters:
   - minimum confidence
   - minimum margin
   - buy threshold
   - sell threshold

If any filter fails, the strategy is forced to `HOLD`.

## Backtest Output Semantics

Common skip or degradation reasons in current code:

- `fingerprint_failed`
- `signal_failed`
- `price_fetch_failed`
- `no_article_provided`

The repo intentionally distinguishes:

- rows skipped before LLM inference
- rows with degraded fallback behavior
- rows with valid signals but failed pricing

That distinction matters for metrics and for offline grid search.

## Offline Grid Search

Main code: [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py)

These functions do not rerun inference. They reuse stored raw logits already present in a backtest CSV or DataFrame.

Current supported analyses:

- `run_pmi_alpha_grid_search`
- `run_signal_confidence_grid_search`
- `run_alpha_confidence_grid_search`
- `run_alpha_confidence_margin_grid_search`
- `run_long_only_grid_search`
- `run_no_pmi_confidence_margin_grid_search`
- `run_no_pmi_long_only_grid_search`

The long-only path uses a different decision rule from the mixed strategy:

```text
take_long if prob_buy >= confidence_threshold
and buy_margin >= margin_threshold
otherwise stay in cash
```

## Configuration That Matters Most

Main file: [config.py](/C:/Project/FinGPT/FinGPT_Part2/config.py)

Important current defaults:

- `NEWS_PROVIDER = "alpaca"`
- `CALIBRATION_T = 1.2`
- `FINGPT_PMI_ALPHA = 0.0`
- `FINGPT_SIGNAL_MIN_CONFIDENCE = 0.0`
- `FINGPT_SIGNAL_MIN_MARGIN = 0.0`
- `FINGPT_BUY_THRESHOLD = 0.0`
- `FINGPT_SELL_THRESHOLD = 0.0`
- `FINGPT_SIGNAL_USE_COT = False`
- `FINGPT_BACKTEST_STRICT_MODE = False`
- `FINGPT_BACKTEST_BATCH_SIZE = 10`

This means the current baseline is intentionally permissive and expects more selective tuning to happen through offline sweeps.

## Files To Edit By Goal

If you want to change extraction behavior:

- [agent1/prompt.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/prompt.py)
- [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py)
- [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py)

If you want to change strategy behavior:

- [agent2/prompt.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/prompt.py)
- [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py)
- [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py)

If you want to change historical evaluation:

- [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py)
- [backtest/dataset_parser.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/dataset_parser.py)
- [backtest/price_fetcher.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/price_fetcher.py)
- [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py)

If you want to change the Alpaca weekly ingestion path:

- [configs/alpaca_backtest.example.json](/C:/Project/FinGPT/FinGPT_Part2/configs/alpaca_backtest.example.json)
- [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py)
- [backtest/run_alpaca_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_alpaca_backtest.py)
- [notebooks/alpaca_weekly_backtest.ipynb](/C:/Project/FinGPT/FinGPT_Part2/notebooks/alpaca_weekly_backtest.ipynb)

If you want to change live ingestion:

- [ingestion/news_fetcher.py](/C:/Project/FinGPT/FinGPT_Part2/ingestion/news_fetcher.py)
- [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py)
