# FinGPT Part 2 中文摘要

这份文档是当前仓库实现的中文总览，对应英文版开发说明 [docs/DEVELOPMENT.md](/C:/Project/FinGPT/FinGPT_Part2/docs/DEVELOPMENT.md)。

现在仓库里有三条主要工作流：

1. 实时新闻推理
2. 历史数据回测
3. 基于 Alpaca 周频新闻的数据集构建与回测

它们共享同一个核心思想：不让模型自己“报概率”，而是直接读取 vLLM 的真实 token log-probabilities，再由 Python 做校准、PMI 修正和信号过滤。

## 1. 当前项目在做什么

项目核心是两个 Agent：

- `Agent 1` 把新闻文本转换成结构化 `NewsFingerprint`
- `Agent 2` 把 fingerprint 转成 `TradingSignal`

主要入口文件：

- 实时入口：[pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py)
- 标准回测：[backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py)
- Alpaca 周频流程：[backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py)

## 2. 三条主流程

### 2.1 实时流程

实时流程由 [pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/pipeline.py) 驱动：

1. 从 Alpaca 或 Finnhub 抓最近新闻
2. 只保留 `created_at <= as_of_timestamp` 的新闻
3. 每个 ticker 只保留一篇最新可用新闻
4. 用 `headline + summary` 组成 `article_text`
5. 交给 Agent 1 和 Agent 2
6. 输出到 `output/signals_<timestamp>.json`

这里的关键约束是：

- `ticker` 和 `headline` 来自抓取层
- Agent 2 消费的是 fingerprint，而不是重新直接读取 provider 原始返回

### 2.2 标准回测流程

标准回测由 [backtest/run_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_backtest.py) 和 [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py) 驱动：

1. 读取 CSV、parquet，或兼容的 Hugging Face 数据集
2. 统一整理出 `ticker`、`headline`、`article_text`、`start_date`、`end_date`
3. 批量跑 Agent 1
4. 批量跑 Agent 2
5. 抓取真实收益
6. 输出结果 CSV，并可计算 metrics

常用命令：

```bash
python -m backtest.run_backtest --dataset path/to/dataset.csv --output output/backtest_results.csv --metrics
```

如果已经有结果 CSV，也可以只重定价和重算指标：

```bash
python -m backtest.run_backtest --resume-csv output/backtest_results.csv --output output/backtest_repriced.csv --metrics
```

### 2.3 Alpaca 周频流程

这是当前仓库新增且很重要的一条线，入口是：

- [backtest/run_alpaca_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_alpaca_backtest.py)
- [configs/alpaca_backtest.example.json](/C:/Project/FinGPT/FinGPT_Part2/configs/alpaca_backtest.example.json)

它的作用不是直接替代标准回测，而是先从 Alpaca 新闻构建出一份可回测 dataset，再选择是否继续调用现有 backtester。

当前流程：

1. 读取 JSON 配置
2. 把 `start` 到 `end` 切成连续滚动的 7 天窗口
3. 对每个 `symbol x week` 单独向 Alpaca 拉新闻
4. 把结果缓存到 `output/alpaca_news_cache/`
5. 每周最多取前 `combine_articles_per_sample` 篇新闻拼成一个 prompt 样本
6. 如果某周该股票没有新闻，直接写 `no_signal`，不调用 LLM
7. 输出 dataset CSV
8. 如有需要，再继续跑标准 backtest

只生成 dataset：

```bash
python -m backtest.run_alpaca_backtest --config configs/alpaca_backtest.example.json --dataset-only
```

生成 dataset 并继续回测：

```bash
python -m backtest.run_alpaca_backtest --config configs/alpaca_backtest.example.json
```

## 3. 两个 Agent 现在怎么工作

### 3.1 Agent 1

定义见 [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py) 和 [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py)。

它现在实际包含三步：

1. guided extraction
2. sentiment scoring
3. event-type scoring

输出核心字段包括：

- `ticker`
- `headline`
- `source`
- `published_at`
- `sentiment_label`
- `sentiment_confidence`
- `sentiment_probabilities`
- `event_type`
- `event_type_confidence`
- `event_type_margin`
- `article_text`

当前实现里要特别记住：

- `ticker` 不再依赖 `companies_named[0]` 推断
- `headline` 优先保留上游传入值
- `OTHER` 不是模型直接打分出来的，而是 Python 侧阈值规则给出的

### 3.2 Agent 2

定义见 [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py) 和 [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py)。

它对 `A/B/C` 三个策略 token 打分，映射关系是：

- `A -> BUY -> long`
- `B -> HOLD -> neutral`
- `C -> SELL -> short`

然后再做：

1. 可选 CoT
2. PMI 修正
3. softmax 校准
4. confidence / margin / buy / sell 阈值过滤

PMI 修正公式是：

```text
adjusted_logit = raw_logit - alpha * null_logprob
```

如果过滤没过，最后会被强制改成 `HOLD`。

## 4. 当前新增的离线调参能力

[backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py) 可以在已经产出的 backtest CSV 上做离线 sweep，不需要重新跑大模型。

当前支持：

- PMI alpha sweep
- confidence sweep
- alpha + confidence 二维 sweep
- mixed strategy 的 alpha + confidence + margin 三维 sweep
- long-only 策略 sweep
- no-PMI 包装版本

这部分的意义是：一次昂贵推理，可以复用成多轮便宜的后处理实验。

## 5. 配置里最值得关注的项

配置主文件是 [config.py](/C:/Project/FinGPT/FinGPT_Part2/config.py)。

当前关键默认值：

- `NEWS_PROVIDER = "alpaca"`
- `CALIBRATION_T = 1.2`
- `FINGPT_PMI_ALPHA = 0.0`
- `FINGPT_SIGNAL_MIN_CONFIDENCE = 0.0`
- `FINGPT_SIGNAL_MIN_MARGIN = 0.0`
- `FINGPT_BUY_THRESHOLD = 0.0`
- `FINGPT_SELL_THRESHOLD = 0.0`
- `FINGPT_SIGNAL_USE_COT = False`
- `FINGPT_BACKTEST_STRICT_MODE = False`
- `FINGPT_BACKTEST_BATCH_SIZE = 10`

这意味着当前默认基线比较宽松，更偏向先保留原始信号，再通过离线 grid search 调参。

## 6. 现在最常改哪些地方

如果你想改 Agent 1：

- [agent1/prompt.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/prompt.py)
- [agent1/extractor.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/extractor.py)
- [agent1/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent1/schema.py)

如果你想改 Agent 2：

- [agent2/prompt.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/prompt.py)
- [agent2/reasoner.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/reasoner.py)
- [agent2/schema.py](/C:/Project/FinGPT/FinGPT_Part2/agent2/schema.py)

如果你想改回测：

- [backtest/backtester.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/backtester.py)
- [backtest/dataset_parser.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/dataset_parser.py)
- [backtest/price_fetcher.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/price_fetcher.py)
- [backtest/pmi_grid_search.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/pmi_grid_search.py)

如果你想改 Alpaca 周频流程：

- [configs/alpaca_backtest.example.json](/C:/Project/FinGPT/FinGPT_Part2/configs/alpaca_backtest.example.json)
- [backtest/alpaca_news_pipeline.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/alpaca_news_pipeline.py)
- [backtest/run_alpaca_backtest.py](/C:/Project/FinGPT/FinGPT_Part2/backtest/run_alpaca_backtest.py)
- [notebooks/alpaca_weekly_backtest.ipynb](/C:/Project/FinGPT/FinGPT_Part2/notebooks/alpaca_weekly_backtest.ipynb)

## 7. 一句话总结

这版仓库已经不只是“新闻到信号”的基础 pipeline 了，还多了一个更完整的 Alpaca 周频数据构建和离线调参体系。现在最重要的理解方式是：

- 在线抓新闻是一条线
- 历史回测是一条线
- Alpaca 周频数据构建是给回测喂数据的第三条线

三者底层共享同一个两 Agent 推理核心。
