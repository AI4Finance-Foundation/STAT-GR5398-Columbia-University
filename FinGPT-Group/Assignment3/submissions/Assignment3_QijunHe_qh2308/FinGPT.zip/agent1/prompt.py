"""
agent1/prompt.py — Prompts for Agent 1.

Two prompts are used:

EXTRACTION_PROMPT
    Instructs the model to extract structured facts from the article and
    return them as a JSON object.  Guided decoding enforces the schema.
    Unchanged from previous version.

SENTIMENT_COT_PROMPT
    Instructs the DeepSeek-R1 model to write chain-of-thought reasoning
    about the article's market sentiment inside ``<think>…</think>`` tags.
    The model stops at ``</think>`` (via vLLM ``stop=["</think>"]``).

    The scoring phase in ``vllm_logits_client.get_real_choice_logits``
    then appends ``</think>\\n`` + ``SENTIMENT_DECISION_PREFIX`` and reads
    the model's genuine token-level log-probabilities for each class label
    (POSITIVE, NEGATIVE, NEUTRAL) via ``SamplingParams(prompt_logprobs=1)``.

    The model is NOT asked to output logit numbers or a JSON object.  All
    probability calculations happen in Python from the real model logprobs.

SENTIMENT_DECISION_PREFIX
    Short string appended after the CoT to create the decision context.
    The model's next-token distribution at this point is scored for each
    choice label.  Must end with a space so the choice token attaches
    cleanly (e.g. "Sentiment: POSITIVE").
"""

# ---------------------------------------------------------------------------
# Fact-extraction prompt (guided decoding — unchanged)
# ---------------------------------------------------------------------------

EXTRACTION_PROMPT: str = (
    "Extract structured facts from the article below. "
    "Use only information explicitly stated. "
    "Return only a JSON object.\n"
    "Good output example:\n"
    '{"source":"Reuters","published_at":"2024-02-25T14:30:00Z",'
    '"companies_named":["Apple","AAPL"],"event_keywords":["iphone","demand","earnings"]}\n'
    "Now return JSON with these fields:\n"
    "- source: publisher name or empty string\n"
    "- published_at: ISO datetime if present, or empty string\n"
    "- companies_named: list of company names or tickers\n"
    "- event_keywords: list of lowercase topic keywords"
)

# Backward-compatible alias.
SYSTEM_PROMPT: str = EXTRACTION_PROMPT

# ---------------------------------------------------------------------------
# Sentiment CoT prompt (Phase 1 — reasoning only, no answer expected)
# ---------------------------------------------------------------------------

SENTIMENT_PROMPT: str = """\
You are a financial news sentiment analyst.

Use the article as the only source of truth.
Do not judge the general market sentiment unless it directly affects the target asset.
If the article mentions multiple companies or macro events, classify only the likely impact on the target asset.
If the article is not relevant to the target asset, choose NEUTRAL.

Sentiment labels:
- POSITIVE: the news is likely favorable for the target asset.
- NEUTRAL: the news is mixed, unclear, already non-directional, or not clearly relevant.
- NEGATIVE: the news is likely unfavorable for the target asset.


{article_text}\
"""

# Backward-compatible alias for older imports.
SENTIMENT_COT_PROMPT: str = SENTIMENT_PROMPT

# ---------------------------------------------------------------------------
# Decision prefix (Phase 2 — appended after </think> for logprob scoring)
# ---------------------------------------------------------------------------

# The model's next-token distribution at "Sentiment: " is scored for each
# of the three class labels: POSITIVE, NEGATIVE, NEUTRAL.
# Must end with a space so the choice token aligns with BPE tokenisation.
SENTIMENT_DECISION_PREFIX: str = "Sentiment: "

# ---------------------------------------------------------------------------
# Event type classification prompt (direct scoring, no CoT)
# ---------------------------------------------------------------------------
# Scores single-character tokens A-G using prompt_logprobs.
# OTHER is deliberately excluded — it is assigned by Python post-processing
# when confidence or margin falls below configured thresholds, preventing
# OTHER from becoming a prior sink for the model.

EVENT_TYPE_PROMPT: str = """\
Classify the main financial event type.

Choose the best matching category:
A. Earnings, revenue, EPS, profit, or quarterly results
B. Guidance, outlook, forecast, or management expectations
C. Analyst rating, upgrade, downgrade, or price target change
D. Legal, regulatory, investigation, lawsuit, fine, or approval
E. Merger, acquisition, divestiture, takeover, or strategic stake
F. Product launch, partnership, contract, customer win, or business update
G. Macro, rates, inflation, commodity, market-wide, or policy event

Text:
{article_text}

Answer:\
"""

# Appended to the event_type prompt to create the decision context for
# prompt_logprobs scoring of tokens A-G.
# Must end with a space so single-letter tokens are not BPE-merged.
EVENT_TYPE_DECISION_PREFIX: str = "Answer: "
