# Keeping each meeting's full-text trade size

The experiment evaluates the 16 scheduled FOMC statements in the January 2022–December 2023 validation period. It asks whether the direction of the policy signal helps when the magnitude comes from the full-text model at the same meeting. There is no fitted coefficient. The primary endpoints are the after-cost stock portfolio’s cumulative return and maximum daily drawdown depth.

At the previous-session information cutoff, take the absolute difference between the full-text model’s exposure target and the neutral-news engine’s target. Apply that magnitude downward on a hawkish call and upward on a dovish call. On a neutral or offsetting call, use the neutral engine’s target. All ordinary rebalancing driven by the other five timing inputs, stock rankings and prices still takes place. No body tilt means no size to trade, whatever the stance label. The feasible equity target lies between zero and one. The event audit checks any clipping against the requested magnitude.

## Comparisons

- **Full-text model** applies the original sentiment signal on all 16 decisions.
- **Full-text direction on active calls** keeps the body model’s target on hawkish or dovish calls and uses the neutral engine on neutral calls. Comparing this portfolio with the full-text model measures the effect of skipping the neutral calls.
- **Policy direction at the same size** trades on exactly the same active calls using the same absolute size as the preceding portfolio. Comparing these two portfolios isolates the change in direction. Comparing this portfolio directly with the original full-text model includes both changes.
- **Neutral input** provides the original timing portfolio with news fixed at 0.5. The other risk inputs still move its weekly target.

Each arm starts with the same capital, stock scores, universe, weekly decision calendar and next-open execution. Trading costs are 6 basis points per dollar traded. Whole shares, minimum-order rules and the holdings carried between rebalances are applied independently in each arm. This historical follow-up uses a previously examined validation period. The formal valuation holdout begins in 2024 and falls outside this replay.

## Validation results

| News target | Cumulative return | Maximum drawdown depth | Mean absolute shift from neutral on meeting dates |
|---|---:|---:|---:|
| Full-text model, all calls | 3.76451% | 27.69708% | 6.6875 bp |
| Full-text direction, active calls only | 3.76896% | 27.69708% | 3.0000 bp |
| Policy direction, same sizes on active calls | 3.78483% | 27.69803% | 3.0000 bp |
| Neutral news input | 3.78647% | 27.69639% | 0 bp |

Against the original full-text model, the requested policy earned **0.02032 percentage points** more and experienced a **0.00096-point deeper** maximum drawdown. Removing four nonzero targets on neutral calls lifted return by 0.00445 points. Reversing six targets with their magnitudes fixed raised return by another 0.01587 points. The latter comparison holds the traded dates and their sizes constant. All four portfolios had the same drawdown peak and trough, January 3 and December 28, 2022. [After-cost stock results](results/comparison.csv) · [Matched comparisons](results/paired_differences.csv) · [Daily equity](results/daily_nav.csv)

The 16 meetings produced six reversals, two retained directions, four canceled trades and four dates with zero original magnitude. All targets lay inside the feasible exposure bounds. The six reversals turned increases into reductions. Over the following open-to-open windows, the neutral arm’s tradable stock basket fell three times and rose three times. At the August 1, 2022 open, the first different fills associated with the sign reversals were single-share differences in JNPR and NVDA. Whole shares and positions carried across weeks influence the net return. The gain from the six reversals was about 1.59 bp. That small advantage in a previously examined, tightening-heavy sample offers little evidence of a repeatable directional edge. [Meeting decisions and sign checks](results/event_audit.csv) · [Weekly targets](results/weekly_decisions.csv) · [Differences in stock orders](results/order_differences.csv) · [Direction diagnostics](DIRECTION.md)

## Replay locally

From the course Assignment2 directory, run the commands below in the course Python environment with its data bundle and extracted supplemental timing archive. The replay verifies the archived full-text and neutral daily NAV paths. The separate audit reconstructs the per-meeting targets from the original signals and verifies all 104 weekly decisions.

```sh
PYTHONHASHSEED=0 python extensions/fingpt/direction_swap/backtest.py
python extensions/fingpt/direction_swap/audit_events.py
```
