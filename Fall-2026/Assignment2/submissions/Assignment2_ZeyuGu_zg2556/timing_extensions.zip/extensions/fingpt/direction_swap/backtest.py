"""Validation stock portfolios using the body-model trade size and the policy direction."""
import argparse
import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from statement_comparison import backtest as course

EARLIER = HERE.parent / "stance_comparison"
ARMS = ("neutral", "body", "body_active", "swap")
PAIRS = (("swap", "body"), ("swap", "body_active"), ("body_active", "body"), ("swap", "neutral"))


def make_schedule(sessions):
    cols = ["rebalance", "period", "as_of", "meetings", "meeting_dates", "published_at_utc", "source_urls",
            "neutral_score", "neutral_exposure", "body_score", "body_exposure", "stance_score"]
    archived = pd.read_csv(EARLIER / "results/weekly_decisions.csv", usecols=cols,
                           parse_dates=["rebalance", "as_of"],
                           converters={"neutral_exposure": float, "body_exposure": float})
    weekly = archived.loc[archived.period.eq("val")].set_index("rebalance").copy()
    start, end = course.PERIODS["val"]
    dates = sessions[(sessions >= pd.Timestamp(start)) & (sessions <= pd.Timestamp(end))]
    openings = dates.to_series().groupby(dates.to_period("W-SUN")).first()
    assert weekly.index.equals(pd.DatetimeIndex(openings))
    np.testing.assert_array_equal(weekly.as_of, sessions[sessions.get_indexer(weekly.index) - 1])

    source = pd.read_csv(EARLIER / "meeting_scores.csv").set_index("date").loc[str(start):str(end)]
    event = weekly.meetings.eq(1)
    assert weekly.meetings.isin([0, 1]).all() and source.index.is_unique
    observed = weekly.loc[event]
    assert list(observed.meeting_dates) == list(source.index) and len(source) == 16
    assert list(observed.source_urls) == list(source.source_url)
    np.testing.assert_array_equal(observed.stance_score, source.stance_score)
    published = pd.to_datetime(observed.published_at_utc, utc=True)
    np.testing.assert_array_equal(published, pd.to_datetime(source.published_at_utc, utc=True))
    assert (published < observed.as_of.dt.tz_localize("America/New_York")).all()

    direction = {"hawkish": -1, "dovish": 1, "neutral": 0}
    np.testing.assert_array_equal(source.stance_label.map(direction), np.sign(source.stance_score - 0.5))
    weekly["stance_label"] = weekly.meeting_dates.map(source.stance_label).fillna("no_meeting")
    sign = weekly.stance_label.map({**direction, "no_meeting": 0})
    neutral, body = weekly.neutral_exposure, weekly.body_exposure
    tilt = body - neutral
    assert neutral.between(0, 1).all() and body.between(0, 1).all() and tilt.loc[~event].eq(0).all()
    same = np.sign(tilt).eq(sign)
    weekly["body_active_exposure"] = body.where(sign.ne(0), neutral)
    # Copy a retained target exactly. The opposite sign reflects it across the neutral target.
    requested = (neutral + sign * tilt.abs()).where(~same, body)
    weekly["requested_swap_exposure"] = requested
    weekly["swap_exposure"] = requested.clip(0, 1)
    weekly["clipped"] = requested.ne(weekly.swap_exposure)
    weekly["body_shift_bp"] = tilt * 10000
    weekly["swap_shift_bp"] = (weekly.swap_exposure - neutral) * 10000
    weekly["action"] = np.select([~event, tilt.eq(0), sign.eq(0), same],
                                 ["non_event", "zero_magnitude", "abstain", "retain"], default="reverse")
    on = event & sign.ne(0) & ~weekly.clipped
    np.testing.assert_allclose(weekly.swap_shift_bp[on].abs(), weekly.body_shift_bp[on].abs(), atol=2e-12, rtol=0)
    assert weekly.swap_shift_bp[sign.eq(0)].eq(0).all()
    return weekly


def replay(out, scratch):
    prices, stock_scores, params, universe = course.portfolio_inputs(scratch)
    weekly = make_schedule(prices.sessions)
    targets = weekly.set_index("as_of")
    event = weekly.meetings.eq(1)
    start, end = course.PERIODS["val"]
    cfg = course.BacktestConfig(start=start, end=end, stops=False, use_exposure_engine=True)
    assert pd.Timestamp(end) == course.LAST and np.isclose(cfg.slippage + cfg.commission, 0.0006)
    previous = pd.read_csv(EARLIER / "results/daily_nav.csv", parse_dates=["date"],
                           converters={"neutral": float, "body": float})
    previous = previous.loc[previous.period.eq("val")].set_index("date")
    curves, orders, stats = {}, {}, {}
    for arm in ARMS:
        def exposure(prev_day):
            cutoff = pd.Timestamp(prices.last_session_on_or_before(prev_day))
            return SimpleNamespace(exposureMultiplier=float(targets.at[cutoff, f"{arm}_exposure"]))

        result = course.run_backtest(prices, stock_scores, params, universe, cfg, exposure_fn=exposure)
        nav = result.equity
        assert nav.index.equals(previous.index)
        assert all(row["model_cutoff"] < row["date"] for row in result.weekly_targets)
        if arm in ("neutral", "body"):
            np.testing.assert_array_equal(nav, previous[arm])
        orders[arm] = result.trades.groupby(["date", "symbol"]).qty.sum()
        curves[arm] = nav
        ret, dd = course.exact_metrics(nav)
        daily = nav.pct_change().dropna()
        trough = (nav / nav.cummax()).idxmin()
        traded = result.trades.notional.abs().sum()
        shift = weekly[f"{arm}_exposure"] - weekly.neutral_exposure
        stats[arm] = dict(period="val", policy=arm, sessions=len(nav), meetings=int(event.sum()),
                          total_return_pct=ret, max_drawdown_pct=dd, sharpe=daily.mean() / daily.std() * np.sqrt(252),
                          max_drawdown_peak=nav.loc[:trough].idxmax(), max_drawdown_trough=trough,
                          trades=len(result.trades), turnover_per_year=traded / nav.mean() * 252 / len(nav),
                          mean_abs_target_shift_bp=shift.loc[event].abs().mean() * 10000)
    comparisons = []
    ledger = pd.concat(orders, axis=1).fillna(0)
    for arm, reference in PAIRS:
        changed_orders = ledger[arm].ne(ledger[reference]).groupby(level="date").sum()
        changed_orders.index = pd.DatetimeIndex(changed_orders.index)
        weekly[f"different_orders_{arm}_vs_{reference}"] = changed_orders.reindex(weekly.index, fill_value=0)
        a, b = stats[arm], stats[reference]
        comparisons.append(dict(policy=arm, reference=reference, return_diff_pp=a["total_return_pct"]-b["total_return_pct"],
                                max_drawdown_depth_diff_pp=b["max_drawdown_pct"]-a["max_drawdown_pct"],
                                sharpe_diff=a["sharpe"]-b["sharpe"],
                                different_target_weeks=int(weekly[f"{arm}_exposure"].ne(weekly[f"{reference}_exposure"]).sum()),
                                different_order_dates=int(changed_orders.gt(0).sum())))
    signal_orders = ledger[["body", "body_active", "swap"]].astype(int)
    different_orders = signal_orders.loc[signal_orders.nunique(axis=1).gt(1)].add_suffix("_qty").reset_index()
    different_orders["open_price"] = [
        prices.open.at[pd.Timestamp(day), symbol] for day, symbol in different_orders[["date", "symbol"]].itertuples(index=False)
    ]
    out.mkdir(parents=True, exist_ok=True)
    for name, frame in (("comparison", pd.DataFrame(stats.values())), ("paired_differences", pd.DataFrame(comparisons)),
                        ("order_differences", different_orders),
                        ("weekly_decisions", weekly.reset_index()), ("daily_nav", pd.DataFrame(curves).rename_axis("date").reset_index())):
        frame.to_csv(out / f"{name}.csv", index=False, date_format="%Y-%m-%d")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Set PYTHONHASHSEED=0 for reproducible course stock-order ties.")
    with TemporaryDirectory(prefix="gr5398-direction-swap-") as temp:
        replay(args.out, Path(temp))
