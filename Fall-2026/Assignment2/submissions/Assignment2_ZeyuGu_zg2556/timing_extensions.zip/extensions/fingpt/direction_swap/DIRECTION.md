# Did reversing the full-text trades improve their direction?

At six of the 16 scheduled validation decisions, the original full-text model raised its equity target and the policy rule called for a reduction. The trading replay reversed each of those six target changes at exactly its original size. Two other target changes already pointed in the policy direction. Four originally nonzero changes were canceled because the policy rule was neutral. The remaining four meetings had a full-text target identical to the neutral engine's target, leaving no size to assign. All requested exposures were feasible without clipping.

| What happened to the original news tilt? | Meetings | Result at the next weekly open |
|---|---:|---|
| Reversed | 6 | Three baskets fell after the new cut. Three rose. |
| Retained | 2 | Both baskets rose following a cut. |
| Canceled because the policy label was neutral | 4 | Two original tilts would have pointed in the correct direction, two in the wrong direction. |
| Original tilt had zero size | 4 | Two meetings had hawkish labels and two had neutral labels. |

The requested policy averaged **3.000 bp** of absolute target tilt per validation meeting, versus **6.6875 bp** for the full-text policy. Both the masked full-text control and the direction-swap policy retain the same **48 bp** of total absolute tilt over eight meetings. Removing the four nonzero tilts on neutral-label dates accounts for the other 59 bp. “No move” concerns the news component of the target. The rest of the neutral timing engine can still move exposure at an ordinary rebalance.

The control named `body_active` follows the original full-text direction and size on hawkish or dovish dates and uses the neutral target otherwise. The difference from full text isolates the four cancellations along this comparison path. Comparing the swapped policy with that control isolates the six reversals with identical dates and magnitudes. The two terminal-return differences add to the headline difference because all paths use the same base. Share rounding, trading thresholds, costs and carried holdings affect each path. The differences describe those portfolios under these rules.

## Event outcome and independent checks

For each news date, use the neutral portfolio's tradable opening shares and adjusted opening prices. Hold those shares fixed from the first executable rebalance open through the opening of the next weekly rebalance. All 16 horizons have four or five trading sessions. The direction check labels a higher tilt correct when that basket rises and a lower tilt correct when it falls, against the course model's zero-yield cash. Holdings lacking an entry opening quote are excluded from the tradable basket. The earlier audit reconciled the complete neutral portfolio, including stale-mark holdings, to every archived daily NAV. [Opening baskets, dates and coverage](../stance_amplitude/DIRECTION.md)

As an additional size-weighted sign check, multiply each change in exposure target by the same window's basket return, then sum across meetings. Relative to the masked full-text control, the six reversals produced a gross proxy difference of −0.88 bp; canceling four tilts contributed −0.68 bp relative to the original body model. This proxy uses the tradable neutral basket instead of the replay’s individual stock orders. It omits the stock cash buffer, discrete shares, costs, compounding and later position differences. The after-cost replay and this proxy can therefore have different signs. [Portfolio contrasts](results/paired_differences.csv) · [Event outcomes](results/event_audit.csv) · [Event counts and proxy sums](results/audit_summary.csv)

The audit independently reconstructs each target with decimal arithmetic from the archived original decision-day body and neutral exposures and the published hawkish, neutral or dovish label. It compares every target and release timestamp with the replay, checks all 104 validation weeks, and reconciles all 16 windows to their audited opening baskets. To reproduce it, run this command from the course Assignment2 directory after the stock replay.

```sh
python extensions/fingpt/direction_swap/audit_events.py
```
