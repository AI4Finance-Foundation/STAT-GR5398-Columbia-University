"""Check matched target magnitudes and measure the direction of the changed event trades."""
import argparse
import csv
from collections import Counter
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
NEWS = HERE.parent
BP = Decimal(10000)
ZERO = Decimal(0)
ONE = Decimal(1)
TOLERANCE = Decimal("0.000000000001")
SIGNS = {"hawkish": -1, "neutral": 0, "dovish": 1}


def read(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def by_key(rows, key):
    result = {row[key]: row for row in rows}
    if len(result) != len(rows):
        raise ValueError(f"Duplicate {key}")
    return result


def outcome(tilt, basket):
    if not tilt:
        return "inactive"
    directional_return = tilt * basket
    if not directional_return:
        return "flat"
    return "right" if directional_return > 0 else "wrong"


def audit(results):
    source = read(NEWS / "statement_comparison/results/weekly_decisions.csv")
    original = by_key([r for r in source if r["period"] == "val"], "rebalance")
    replay = by_key(read(results / "weekly_decisions.csv"), "rebalance")
    assert list(original) == list(replay) and len(replay) == 104
    policies = by_key(read(NEWS / "stance_comparison/meeting_scores.csv"), "date")
    baskets = by_key([r for r in read(NEWS / "stance_amplitude/results/direction_events.csv")
                      if r["period"] == "val"], "meeting_date")
    rows = []
    for opening, baseline in original.items():
        row = replay[opening]
        for field in ("as_of", "meeting_dates", "meetings", "published_at_utc", "source_urls"):
            assert row[field] == baseline[field]
        neutral = Decimal(baseline["neutral_exposure"])
        body = Decimal(baseline["body_exposure"])
        assert neutral == Decimal(row["neutral_exposure"]) and body == Decimal(row["body_exposure"])
        if not int(baseline["meetings"]):
            assert body == neutral == Decimal(row["body_active_exposure"]) == Decimal(row["swap_exposure"])
            continue
        day = baseline["meeting_dates"]
        policy, basket = policies[day], baskets[day]
        timestamp = datetime.fromisoformat(policy["published_at_utc"])
        cutoff = datetime.fromisoformat(baseline["as_of"]).replace(tzinfo=ZoneInfo("America/New_York"))
        assert datetime.fromisoformat(policy["previous_published_at_utc"]) < timestamp < cutoff
        assert timestamp == datetime.fromisoformat(row["published_at_utc"])
        assert policy["source_url"] == baseline["source_urls"]
        assert row["stance_label"] == policy["stance_label"] and basket["entry_open"] == opening
        assert Decimal(row["stance_score"]) == Decimal(policy["stance_score"])
        assert row["as_of"] < opening < basket["exit_open"] < "2024-01-01"
        signal = SIGNS[policy["stance_label"]]
        tilt = body - neutral
        requested = neutral + signal * abs(tilt)
        swapped = min(ONE, max(ZERO, requested))
        bridge = body if signal else neutral
        assert abs(requested - Decimal(row["requested_swap_exposure"])) < TOLERANCE
        assert abs(swapped - Decimal(row["swap_exposure"])) < TOLERANCE
        assert abs(bridge - Decimal(row["body_active_exposure"])) < TOLERANCE
        if not tilt:
            action = "zero_magnitude"
        elif not signal:
            action = "abstain"
        elif tilt * signal > 0:
            action = "retain"
        else:
            action = "reverse"
        assert row["action"] == action
        truncated = requested != swapped
        assert row["clipped"].lower() == str(truncated).lower()
        if signal and not truncated:
            assert abs(swapped - neutral) == abs(tilt)
        gross = Decimal(basket["neutral_basket_return_pct"])
        swap_tilt = swapped - neutral
        rows.append(dict(meeting_date=day, previous_meeting=policy["previous_date"],
                         published_at_utc=policy["published_at_utc"], source_url=policy["source_url"],
                         entry_open=opening, exit_open=basket["exit_open"], trading_sessions=basket["trading_sessions"],
                         stance_label=policy["stance_label"], action=action, clipped=int(truncated),
                         body_shift_bp=tilt * BP, bridge_shift_bp=(bridge - neutral) * BP,
                         swap_shift_bp=swap_tilt * BP, tradable_basket_return_pct=gross,
                         body_direction_check=outcome(tilt, gross), swap_direction_check=outcome(swap_tilt, gross),
                         # Gross shift × basket return, in bp. The source return is already in percent.
                         flip_gross_difference_bp=(swapped - bridge) * gross * 100,
                         abstention_gross_difference_bp=(bridge - body) * gross * 100))
    assert {r["meeting_date"] for r in rows} == set(baskets) and len(rows) == 16
    return rows


def summarize(rows):
    actions = Counter(r["action"] for r in rows)
    flips = [r for r in rows if r["action"] == "reverse"]
    cancellations = [r for r in rows if r["action"] == "abstain"]
    size = Decimal(len(rows))
    return dict(period="val", meetings=len(rows), reversed=actions["reverse"], retained=actions["retain"],
                canceled=actions["abstain"], zero_magnitude=actions["zero_magnitude"],
                clipped=sum(r["clipped"] for r in rows),
                swap_correct_on_flips=sum(r["swap_direction_check"] == "right" for r in flips),
                swap_wrong_on_flips=sum(r["swap_direction_check"] == "wrong" for r in flips),
                body_correct_on_canceled=sum(r["body_direction_check"] == "right" for r in cancellations),
                body_wrong_on_canceled=sum(r["body_direction_check"] == "wrong" for r in cancellations),
                mean_abs_body_shift_bp=sum(abs(r["body_shift_bp"]) for r in rows) / size,
                mean_abs_bridge_shift_bp=sum(abs(r["bridge_shift_bp"]) for r in rows) / size,
                mean_abs_swap_shift_bp=sum(abs(r["swap_shift_bp"]) for r in rows) / size,
                flip_gross_difference_bp=sum(r["flip_gross_difference_bp"] for r in rows),
                abstention_gross_difference_bp=sum(r["abstention_gross_difference_bp"] for r in rows))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=HERE / "results")
    folder = parser.parse_args().results
    events = audit(folder)
    write(folder / "event_audit.csv", events)
    write(folder / "audit_summary.csv", [summarize(events)])
