# Federal Reserve news and the timing engine

This optional FinGPT-method experiment fine-tunes the three sentiment answers of a GPT-2 small language model. It uses FinGPT's financial-sentiment instruction format and low-rank adaptation. Its base is the public 124M-parameter GPT-2 checkpoint from February 2019. The official FinGPT v3.3 distribution uses a 13B-parameter Llama 2 base released in 2023. This project has its own locally trained adapter and distinct model lineage. [FinGPT model card](https://huggingface.co/FinGPT/fingpt-sentiment_llama2-13b_lora) · [GPT-2 release](https://openai.com/index/better-language-models/) · [Pinned 2019 weights and tokenizer](https://huggingface.co/openai-community/gpt2/tree/703af3447380a4fdf35eb5c2c13b281dc3fd2cad)

## Information available to the model

Malo and colleagues released Financial PhraseBank v1.0 in July 2013. The training source is the coauthor's fixed redistribution of the original archive. The unanimous-agreement file in the archive is dated April 25, 2013. Duplicate normalized sentences are excluded before sampling. For each sentiment class, a fixed seed draws 180 training and 60 held-out sentences. The 180 held-out labels measure classifier quality on a balanced sample of unanimous Finnish financial-news sentences. Formulaic reports can still share wording between splits, and the Federal Reserve headlines have a different subject and class distribution. No training, early stopping, threshold selection or calibration uses market returns or Federal Reserve news. The model is first eligible on March 1, 2019, the first full month after the checkpoint's release. The daily series is neutral before that date. Training today on fixed inputs that existed then reconstructs a hypothetical historical signal. [Original author release](https://www.researchgate.net/publication/251231364_FinancialPhraseBank-v10) · [Pinned corpus](https://huggingface.co/datasets/takala/financial_phrasebank/tree/eadad06a324e9580384760ad3fc7b99b1604b75b/data) · [Labeling study](https://doi.org/10.1002/asi.23062)

The classifier computes the causal hidden state at the end of the sentiment prompt and restricts next-token probabilities to ` negative`, ` neutral` and ` positive`. A rank-two update to those three rows of the original language-model output weights learns from the labels. Rank two spans the two independent contrasts among three answers; the remaining 124M model weights stay fixed. Cross-entropy training uses AdamW, 24 fixed passes, minibatches of 36, a learning rate of 0.001 and weight decay of 0.01. The fixed 72-token context limit preserves the instruction at the end. Software versions, expected hashes, split membership and classification diagnostics accompany the adapter.

## Inputs and signal

The input comprises the headings and publication dates on the Board of Governors' annual press-release pages, collected with the same HTML rule across all years. This includes enforcement actions, appointments, bank applications, policy updates and other official announcements. These releases represent one public institution. Corporate earnings and independent reporting are outside their coverage. Archived calendars can receive later editorial corrections. The release URLs and hashes of the annual archive snapshots provide an audit trail. [2019 archive](https://www.federalreserve.gov/newsevents/pressreleases/2019-press.htm) · [2020](https://www.federalreserve.gov/newsevents/pressreleases/2020-press.htm) · [2021](https://www.federalreserve.gov/newsevents/pressreleases/2021-press.htm) · [2022](https://www.federalreserve.gov/newsevents/pressreleases/2022-press.htm) · [2023](https://www.federalreserve.gov/newsevents/pressreleases/2023-press.htm)

Each dated headline receives `P(positive) + 0.5 × P(neutral)`. Same-day scores receive equal weight. Every calendar day without a qualifying headline receives 0.5. The weekly rule averages the seven preceding calendar days, excluding the decision day to allow for unknown release times. One week matches the rebalance cadence and limits carryover. The original six-factor engine uses this average in its 12% news term. The matched control always passes 0.5 to the same engine. All other factors, volatility scaling, position limits, prices, portfolio weights and costs are held fixed.

## Coverage and a development-period pilot

The annual press-release archive contains none of the 16 scheduled statement URLs listed on the 2022–2023 FOMC meeting calendar. It does contain 33 monetary-policy titles mentioning minutes during those years. In 2019 seven scheduled statements share the same title and the same score, 0.440458. The May 1 and July 31 statement bodies describe a hold and a 25 bp cut, respectively. [Calendar coverage](results/corpus_calendar_coverage.csv) · [Topic counts](results/corpus_topics.csv) · [Repeated titles](results/corpus_repeated_fomc.csv) · [Federal Reserve meeting calendar](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)

The development-only [release-day averaging pilot](release_day_pilot/README.md) changes the treatment of dates without a release. Compared with the original seven-day average, the mean absolute change in exposure relative to neutral rose from 1.09 to 3.23 bp and stock returns fell from 127.70% to 127.40%. These observations motivate a test of the statement content before any change to the 12% factor weight.

The paired statement study recovers all 55 scheduled releases in 2017–2023 from the official calendars. On the 38 model-eligible meetings it compares neutral input, each meeting’s title and the complete statement. Full text raised cumulative stock return by 0.537 percentage points in development relative to titles. In validation it lowered return by 0.010 points and deepened maximum drawdown by 0.005 points. [Paired results, release data and reproduction](statement_comparison/README.md)

A second paired study scores the change in the target rate and forward guidance from the preceding policy statement. Relative to the existing full-body model, the rule reduced 2022–2023 stock return by 0.466 percentage points and deepened drawdown by 0.284 points. Ten of the 16 validation decisions generated a hawkish signal and six were neutral or offsetting. [Decision rules and portfolio replay](stance_comparison/README.md)

A sizing follow-up retained 33.88% of each policy rule tilt, matching the full-text model’s average target change in development. This lifted validation return from 3.298% to 3.675%, compared with 3.765% for full text. Maximum drawdown depth narrowed from 27.981% to 27.712%. Four of nine reductions in equity exposure preceded a fall in the tradable stock basket. [Calibration, portfolio outcomes and directional evidence](stance_amplitude/README.md)

A final comparison keeps each meeting’s actual full-text target magnitude. Policy labels reverse six tilts and suppress four on neutral calls. The requested policy increased validation return by 2.03 bp versus the original full-text model and deepened maximum drawdown by 0.10 bp. With the same neutral calls suppressed in both arms, the six reversals added 1.59 bp of return. [Matched dates, magnitudes and actual orders](direction_swap/README.md)

## Reproduction

The course evaluator can replay the included data without an internet connection or GPT installation. From this directory, use the official course Python environment and set `SOURCE` to the path of the populated course `source_code` directory.

```sh
python evaluate.py --source "$SOURCE" --results results
python audit_signal.py --source "$SOURCE" --results results --out results
```

The second command checks the adapter and train/held-out label split, reconstructs the daily values from saved headline probabilities, and traces those values through the shipped weekly hook. It compares every exposure to the same engine supplied with the independently computed seven-day score, then reproduces all six SPY performance metrics for both arms. The audit reads market rows through December 31, 2023. To check the original inputs locally as well, pass `--cache ./download_cache` with the cache made by `fetch_inputs.py`. The hashes cover the original GPT-2 checkpoint, the PhraseBank archive and all five saved Federal Reserve annual pages.

To repeat the model fine-tuning and data creation, install `requirements-nlp.txt` in a separate Python 3.10 environment. The generator takes a download cache and output directory. To reproduce the exact original headlines if the public pages change, add `--published-headlines results/headline_scores.csv`; the reader selects only date, title and URL. Use a fresh directory for a repeat to keep the delivered evidence intact. Then run `evaluate.py` in the course environment with `--results reconstructed`.

```sh
python fetch_inputs.py ./download_cache
python train_sentiment.py ./download_cache --out reconstructed
```

`results/student_data/news_sentiment.parquet` contains the `date,value` input. `results/headline_scores.csv` traces every score to a headline and publication URL. `results/training.json` records classifier and source diagnostics. `results/paired_comparison.csv` contains the two-by-two SPY/stock and dev/validation comparison. All evaluation uses a temporary copy of the course source; the primary submission and test ledger are left in place.

Financial PhraseBank is by Malo, Sinha, Takala, Korhonen and Wallenius and is distributed under [CC BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/). The derived answer adapter is supplied under the same terms. The training sentences are obtained from the authors' archive by the download script.

## Results

The 810 qualifying headlines occur on 555 of the 2,556 calendar days in the delivered series. Annual headline counts are 167 in the eligible part of 2019, then 220, 145, 150 and 128. The held-out classifier accuracy increased from 40.0% with the original answer head to 66.1% after tuning. Macro F1 increased from 0.287 to 0.595. Positive recall remained 15.0% (9 of 60). A second training run using the saved headline snapshot reproduced the adapter weights, classification split, headline probabilities and daily parquet byte for byte.

| Period and asset | Total return, neutral → news | Sharpe, neutral → news | Maximum drawdown, neutral → news |
| --- | ---: | ---: | ---: |
| Dev · SPY | 82.82% → 82.81% | 1.175 → 1.175 | −13.73% → −13.74% |
| Dev · stocks | 127.75% → 127.70% | 0.934 → 0.934 | −20.90% → −20.90% |
| Validation · SPY | 4.78% → 4.76% | 0.280 → 0.279 | −14.41% → −14.42% |
| Validation · stocks | 3.79% → 3.66% | 0.194 → 0.190 | −27.70% → −27.73% |

The marginal effect was slightly adverse in both validation portfolios. Validation stock turnover was 7.88× for both arms to two decimals. The engine's 12% news weight is small, and averaging sparse, mostly neutral headlines over a week further reduces its effect. This corpus and classifier do not provide evidence of improved timing. During the full 2022 SPY crisis, the neutral engine avoided 10.11 percentage points of the decline and missed 9.42 points of the rebound. The corresponding news values were 10.10 and 9.43 points. The two stock equity paths were exactly equal before the model became eligible, and the first observable difference was March 25, 2019. The primary research submission uses the course scores and its separately selected module.

### From a dated headline to an order

| Weekly or portfolio diagnostic | Development | Validation |
|---|---:|---:|
| Weekly decisions | 261 | 104 |
| Decision windows containing a release | 142 | 93 |
| Decisions where news changed the exposure | 71 | 67 |
| Mean absolute exposure change over all decisions (bp) | 1.09 | 2.20 |
| Largest absolute exposure change (bp) | 16 | 14 |
| Dates with a different stock order quantity | 42 | 37 |
| Stock-symbol and date pairs with a different order quantity | 70 | 70 |
| SPY terminal relative log wealth, news vs neutral (bp) | −0.89 | −2.47 |
| Stock terminal relative log wealth, news vs neutral (bp) | −2.48 | −12.05 |

The engine assigns 0.12 to news *inside the composite risk score*. A weekly sentiment shift of +0.01 raises that score by 0.0012 before rounding. The engine then applies its risk multiplier, volatility scaling and exposure cap. All five other factor scores were equal between the two arms on all 365 decisions. A basis point of exposure equals 0.01 percentage points of invested capital. Terminal relative log wealth is 10,000 times the log of the ratio of final wealth in the news and neutral arms, each indexed to its first close. [Summary for both splits](results/signal_impact.csv) · [Weekly input, exposure and return differences](results/signal_weeks.csv)

The first difference in the stock ledger illustrates the scale. Eight headlines published March 15–21, 2019 yielded a seven-day score of 0.493885 as of March 22. For the March 25 rebalance the engine's target fell from 95.30% to 95.23%. It sold 72 HPQ shares versus 71 in the neutral arm. Positions also carried forward. On June 12, 2023 both arms targeted 100% exposure, but the neutral arm bought 13 AVGO shares and the news arm bought none. That week's stock relative log return was −7.93 bp, followed by +5.71 bp in the week beginning June 20. Individual weeks benefited even though the full validation result was adverse. [Development neutral orders](results/dev/engine/trades.csv) · [Development news orders](results/dev/student/trades.csv) · [Validation neutral orders](results/val/engine/trades.csv) · [Validation news orders](results/val/student/trades.csv)
