"""Fine-tune a constrained GPT-2 answer head using only 2013 financial labels."""
import argparse
import hashlib
import importlib.metadata
import json
import re
import zipfile
from pathlib import Path
from urllib.parse import urljoin

import numpy as np
import pandas as pd
import torch
from bs4 import BeautifulSoup
from safetensors.torch import load_file, save_file
from sklearn.metrics import classification_report, confusion_matrix
from transformers import GPT2Config, GPT2Model, GPT2TokenizerFast

from fetch_inputs import FED_YEAR, MODEL_REV, PHRASE_SHA

BASE_SHA = '7c5d3f4b8b76583b422fcb9189ad6c89d5d97a094541ce8932dce3ecabde1421'
START_SCORING = pd.Timestamp('2019-03-01')
LABELS = ['negative', 'neutral', 'positive']
SEED = 5398
PROMPT_PREFIX = 'Financial news: '
PROMPT_END = '\nSentiment (negative, neutral, positive):'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def financial_labels(cache):
    archive = cache / 'FinancialPhraseBank-v1.0.zip'
    assert sha(archive) == PHRASE_SHA
    with zipfile.ZipFile(archive) as z:
        rows = z.read('FinancialPhraseBank-v1.0/Sentences_AllAgree.txt').decode('cp1252').splitlines()
    labels = pd.DataFrame([x.rsplit('@', 1) for x in rows], columns=['text', 'label'])
    labels['text'] = labels.text.str.strip()
    labels['key'] = labels.text.map(lambda x: re.sub(r'\W+', ' ', x.casefold()).strip())
    # Exact normalized text must carry just one label across this unanimous set.
    unique = labels.groupby('key').label.nunique()
    labels = labels[labels.key.isin(unique.index[unique.eq(1)])].drop_duplicates('key')
    rng = np.random.default_rng(SEED)
    pieces = []
    for label in LABELS:
        group = labels[labels.label == label].sort_values('key')
        chosen = group.iloc[rng.permutation(len(group))[:240]].copy()
        assert len(chosen) == 240
        chosen['split'] = ['train'] * 180 + ['held_out'] * 60
        pieces.append(chosen)
    return pd.concat(pieces, ignore_index=True)


def fed_headlines(cache):
    rows = []
    for year in range(2019, 2024):
        doc = BeautifulSoup((cache / f'{year}.htm').read_bytes(), 'html.parser')
        before = len(rows)
        for time_tag in doc.select('.eventlist__time time'):
            row = time_tag.parent.parent
            link = row.select_one('.eventlist__event p a[href]')
            if not link:
                continue
            day = pd.to_datetime(time_tag.get_text(strip=True), format='%m/%d/%Y')
            assert day.year == year
            if day < START_SCORING:
                continue
            heading = ' '.join(link.stripped_strings)
            href = urljoin(FED_YEAR.format(year), link['href'])
            assert href.startswith('https://')
            rows.append({'date': day, 'headline': ' '.join(heading.split()), 'url': href})
        assert len(rows) - before > 60, f'Unexpectedly sparse archive {year}'
    frame = pd.DataFrame(rows).sort_values(['date', 'url']).drop_duplicates('url')
    return frame.reset_index(drop=True)


def load_gpt(cache):
    weights = cache / 'pytorch_model.bin'
    assert sha(weights) == BASE_SHA
    cfg = GPT2Config.from_json_file(str(cache / 'config.json'))
    model = GPT2Model(cfg)
    state = torch.load(weights, map_location='cpu', weights_only=True)
    current = model.state_dict()
    # The original export serialized twelve causal masks which modern GPT-2 constructs dynamically.
    extras = set(state) - set(current)
    assert extras == {f'h.{i}.attn.bias' for i in range(cfg.n_layer)}
    model.load_state_dict({k: state[k] for k in current}, strict=True)
    model.eval().requires_grad_(False)
    tok = GPT2TokenizerFast(vocab=str(cache / 'vocab.json'), merges=str(cache / 'merges.txt'))
    ids = [tok.encode(' ' + label, add_special_tokens=False) for label in LABELS]
    assert all(len(x) == 1 for x in ids)
    return model, tok, [x[0] for x in ids]


@torch.inference_mode()
def features(texts, model, tokenizer):
    prefix = tokenizer.encode(PROMPT_PREFIX, add_special_tokens=False)
    ending = tokenizer.encode(PROMPT_END, add_special_tokens=False)
    vectors = []
    for start in range(0, len(texts), 16):
        batch = texts[start:start + 16]
        encoded = [prefix + tokenizer.encode(t, add_special_tokens=False)[:72 - len(prefix) - len(ending)] + ending
                   for t in batch]
        lengths = torch.tensor([len(row) for row in encoded])
        size = int(lengths.max())
        ids = torch.tensor([row + [tokenizer.eos_token_id] * (size - len(row)) for row in encoded])
        mask = torch.arange(size)[None, :] < lengths[:, None]
        states = model(input_ids=ids, attention_mask=mask.long(), use_cache=False).last_hidden_state
        vectors.append(states[torch.arange(len(batch)), lengths - 1].clone())
    return torch.cat(vectors)


class AnswerAdapter(torch.nn.Module):
    """Low-rank update to the three answer-token rows of GPT-2's tied LM head."""
    def __init__(self, initial_head):
        super().__init__()
        self.register_buffer('base', initial_head.clone())
        self.down = torch.nn.Linear(initial_head.shape[1], 2, bias=False)
        self.up = torch.nn.Linear(2, 3, bias=False)
        torch.nn.init.normal_(self.down.weight, std=0.02)
        torch.nn.init.zeros_(self.up.weight)

    def forward(self, x):
        return x @ self.base.T + self.up(self.down(x))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cache', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--published-headlines', type=Path, help='Use the saved date, headline and URL snapshot')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(True)
    sample = financial_labels(args.cache)
    if args.published_headlines:
        news = pd.read_csv(args.published_headlines, usecols=['date', 'headline', 'url'], parse_dates=['date'])
        assert not news.url.duplicated().any() and news.date.between(START_SCORING, '2023-12-31').all()
    else:
        news = fed_headlines(args.cache)
    model, tok, answer_ids = load_gpt(args.cache)
    print(f'Encoding {len(sample)} labeled sentences and {len(news)} Federal Reserve headlines.', flush=True)
    # Frozen GPT-2 features permit exact caching. Only the two low-rank head matrices train.
    x = features(sample.text.tolist(), model, tok).clone()
    y = torch.tensor([LABELS.index(lab) for lab in sample.label])
    train = torch.tensor(np.flatnonzero(sample.split.eq('train')))
    hold = torch.tensor(np.flatnonzero(sample.split.eq('held_out')))
    adapter = AnswerAdapter(model.wte.weight.detach()[answer_ids])
    optimizer = torch.optim.AdamW(adapter.parameters(), lr=0.001, weight_decay=0.01)
    raw_predictions = adapter(x[hold]).argmax(1).tolist()
    for epoch in range(24):
        for batch in train[torch.randperm(len(train))].split(36):
            optimizer.zero_grad()
            loss = torch.nn.functional.cross_entropy(adapter(x[batch]), y[batch])
            loss.backward()
            optimizer.step()
    save_file({'down': adapter.down.weight.detach().contiguous(), 'up': adapter.up.weight.detach().contiguous()},
              str(args.out / 'answer_adapter.safetensors'))
    # Reopen the same adapter a downstream user would load and verify its held-out logits.
    saved = load_file(str(args.out / 'answer_adapter.safetensors'))
    restored = AnswerAdapter(model.wte.weight.detach()[answer_ids])
    with torch.no_grad():
        restored.down.weight.copy_(saved['down'])
        restored.up.weight.copy_(saved['up'])
        assert torch.equal(adapter(x[hold]), restored(x[hold]))
        adapter = restored
        predictions = adapter(x[hold]).argmax(1).tolist()
        outputs = torch.softmax(adapter(features(news.headline.tolist(), model, tok)), dim=1).numpy()
    for i, lab in enumerate(LABELS):
        news['p_' + lab] = outputs[:, i]
    news['value'] = news.p_positive + 0.5 * news.p_neutral
    assert np.isfinite(news.value).all() and news.value.between(0, 1).all()
    news.to_csv(args.out / 'headline_scores.csv', index=False)
    # Equal weight within a day. Neutral dates explicitly prevent stale scores. No dates after validation.
    dates = pd.date_range('2017-01-01', '2023-12-31', name='date')
    daily = news.groupby('date').value.mean().reindex(dates, fill_value=0.5).reset_index()
    (args.out / 'student_data').mkdir(exist_ok=True)
    daily.to_parquet(args.out / 'student_data/news_sentiment.parquet', index=False)
    truth = y[hold].tolist()
    evaluated = {'base': raw_predictions, 'fine_tuned': predictions}
    report = {k: {'metrics': classification_report(truth, p, labels=[0, 1, 2], target_names=LABELS,
                                                   output_dict=True, zero_division=0),
                  'confusion_matrix': confusion_matrix(truth, p, labels=[0, 1, 2]).tolist()}
              for k, p in evaluated.items()}
    ids = sample[['label', 'split']].assign(sentence_sha256=sample.text.map(lambda t: hashlib.sha256(t.encode()).hexdigest()))
    ids.to_csv(args.out / 'label_split.csv', index=False)
    software = {p: importlib.metadata.version(p) for p in ['numpy', 'torch', 'transformers', 'tokenizers', 'pandas',
                                                          'pyarrow', 'beautifulsoup4', 'scikit-learn', 'safetensors']}
    metadata = {'model': 'openai-community/gpt2', 'model_revision': MODEL_REV, 'model_sha256': BASE_SHA,
                'phrasebank_zip_sha256': PHRASE_SHA, 'adapter_sha256': sha(args.out / 'answer_adapter.safetensors'),
                'classes': LABELS, 'class_token_ids': answer_ids,
                'first_eligible_release': str(START_SCORING.date()), 'rank': 2, 'seed': SEED, 'epochs': 24,
                'train_n': len(train), 'label_holdout_n': len(hold), 'release_count': len(news),
                'release_days': news.date.nunique(), 'daily_rows': len(daily), 'software': software,
                'archive_sha256': {} if args.published_headlines else {
                    str(y): sha(args.cache / f'{y}.htm') for y in range(2019, 2024)},
                'published_snapshot_sha256': sha(args.published_headlines) if args.published_headlines else None,
                'classification': report}
    (args.out / 'training.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(f'Finished. Held-out macro F1 {report["fine_tuned"]["metrics"]["macro avg"]["f1-score"]:.3f}', flush=True)


if __name__ == '__main__':
    main()
