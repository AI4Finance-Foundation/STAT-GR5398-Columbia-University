"""Development-only matched stock replay for two ways to aggregate sparse news."""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pyarrow.dataset as ds

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / "source_code"
DATA = SOURCE / "data"
ORIGINAL = HERE.parent / "results"
sys.path.insert(0, str(SOURCE))
from portfolio.backtester import BacktestConfig, run_backtest
from selection import MonthlyScores, Parameters
from shared.metrics import performance
from shared.prices import PriceStore
from shared.universe import TradeableUniverse
from timing.engine import exposure_from_history

START = pd.Timestamp("2017-01-03")
END = pd.Timestamp("2021-12-31")
ARMS = ("neutral", "seven_calendar_days", "release_days_only")


def parquet_through_dev(path, key="date"):
    return pd.read_parquet(path, filters=[(key, "<=", END)])


def development_inputs(temp):
    prices_path, scores_path, membership_db = temp / "prices.parquet", temp / "scores.parquet", temp / "members.db"
    parquet_through_dev(DATA / "prices/daily_adjusted.parquet").to_parquet(prices_path, index=False)
    parquet_through_dev(DATA / "selection/monthly_scores.parquet", "month").to_parquet(scores_path, index=False)
    source_uri = (DATA / "fundamentals.db").as_uri() + "?mode=ro"
    with sqlite3.connect(source_uri, uri=True) as src, sqlite3.connect(membership_db) as dst:
        for table, date_key in (("universe_membership", "snapshot_date"), ("symbol_changes", "change_date")):
            frame = pd.read_sql(f"SELECT * FROM {table} WHERE {date_key} <= ?", src, params=[str(END.date())])
            frame.to_sql(table, dst, index=False)
    config = json.loads((SOURCE / "selection/configs/growth.json").read_text())
    universe = TradeableUniverse.from_db_path(str(membership_db), config["model"]["universes"])
    return PriceStore(prices_path), MonthlyScores(scores_path), Parameters(**config["parameters"]), universe


def publication_days():
    dataset = ds.dataset(ORIGINAL / "headline_scores.csv", format="csv")
    articles = dataset.to_table(filter=ds.field("date") <= END.date()).to_pandas()
    articles["date"] = pd.to_datetime(articles.date)
    assert articles.date.min() >= pd.Timestamp("2019-03-01") and articles.url.is_unique
    np.testing.assert_allclose(articles.value, articles.p_positive + 0.5 * articles.p_neutral, atol=1e-7, rtol=0)
    # The original model wrote float32 daily means. Check against its published development input.
    daily = articles.astype({"value": "float32"}).groupby("date").value.agg(["mean", "size"])
    archived = parquet_through_dev(ORIGINAL / "student_data/news_sentiment.parquet").set_index("date").value
    reconstructed = daily["mean"].reindex(archived.index, fill_value=0.5)
    np.testing.assert_allclose(reconstructed, archived, atol=1e-7, rtol=0)
    return daily


def make_schedule(prices):
    daily = publication_days()
    market = parquet_through_dev(DATA / "prices/market_series.parquet")
    macro = {}
    for name in ("T10Y2Y", "BAMLH0A0HYM2"):
        data = parquet_through_dev(DATA / f"macro/{name}.parquet")
        macro[name] = data.set_index("date").value.sort_index()
    sessions = prices.sessions[prices.sessions >= START]
    records = []
    for opening in sessions.to_series().groupby(sessions.to_period("W-SUN")).first():
        close = prices.sessions[prices.sessions.get_loc(opening) - 1]
        releases = daily.loc[(daily.index >= close - pd.Timedelta(days=7)) & (daily.index < close)]
        deviations = releases["mean"].astype(float) - 0.5
        scores = (0.5, 0.5 + deviations.sum() / 7, 0.5 + deviations.mean() if len(releases) else 0.5)
        cached = {}
        row = dict(rebalance=opening, as_of=close, last_release=releases.index.max(),
                   release_days=len(releases), headlines=int(releases["size"].sum()))
        for arm, score in zip(ARMS, scores):
            if score not in cached:
                result = exposure_from_history(market, macro, close, news_sentiment=float(score))
                assert result is not None
                cached[score] = result.exposureMultiplier
            row[f"{arm}_score"] = score
            row[f"{arm}_exposure"] = cached[score]
        records.append(row)
    schedule = pd.DataFrame(records)
    assert schedule.as_of.lt(schedule.rebalance).all()
    has_news = schedule.last_release.notna()
    assert schedule.loc[has_news, "last_release"].lt(schedule.loc[has_news, "as_of"]).all()
    return schedule


def run(out, temp):
    prices, scores, params, universe = development_inputs(temp)
    weekly = make_schedule(prices)
    config = BacktestConfig(start=START.date(), end=END.date(), stops=False, use_exposure_engine=True)
    rows, navs = [], {}
    for arm in ARMS:
        exposures = weekly.set_index("as_of")[f"{arm}_exposure"]

        def exposure(prev_day):
            close = pd.Timestamp(prices.last_session_on_or_before(prev_day))
            return SimpleNamespace(exposureMultiplier=float(exposures.at[close]))

        result = run_backtest(prices, scores, params, universe, config, exposure_fn=exposure)
        if arm != "release_days_only":
            original_arm = "engine" if arm == "neutral" else "student"
            archive = pd.read_csv(ORIGINAL / "dev" / original_arm / "equity.csv", index_col=0, parse_dates=True).equity
            assert pd.DatetimeIndex(result.equity.index).equals(archive.index)
            np.testing.assert_allclose(result.equity, archive, rtol=1e-12, atol=1e-7)
        navs[arm] = result.equity
        traded = result.trades.notional.abs().sum()
        turnover = traded / result.equity.mean() * 252 / len(result.equity)
        delta = (weekly[f"{arm}_exposure"] - weekly.neutral_exposure).abs()
        score_delta = (weekly[f"{arm}_score"] - 0.5).abs()
        with_news = weekly.release_days.gt(0)
        rows.append(dict(period="dev", policy=arm, **performance(result.equity),
                         turnover_per_year=turnover, trades=len(result.trades), weeks=len(weekly),
                         weeks_with_news=int(with_news.sum()), changed_exposure_weeks=int(delta.gt(0).sum()),
                         mean_abs_score_delta=score_delta.mean(), mean_abs_score_delta_with_news=score_delta[with_news].mean(),
                         mean_abs_exposure_delta_bp=delta.mean() * 10000, max_abs_exposure_delta_bp=delta.max() * 10000))
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out / "comparison.csv", index=False)
    weekly.to_csv(out / "weekly_decisions.csv", index=False, date_format="%Y-%m-%d")
    pd.DataFrame(navs).to_csv(out / "daily_nav.csv", index_label="date")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE)
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Run with PYTHONHASHSEED=0 for deterministic course order ties.")
    with TemporaryDirectory(prefix="gr5398-release-pilot-") as temp:
        run(args.out, Path(temp))
