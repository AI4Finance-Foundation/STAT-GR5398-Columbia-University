# Publication-day denominator pilot

This exploratory follow-up asks whether averaging non-publication days as neutral conceals the effect of a sparse news signal. It uses the entire course development period, January 3, 2017 through December 31, 2021. Market warm-up history precedes the period. All three stock portfolios start on the same date with identical cash, rankings, universe, execution rules and costs. The headline model's first eligible date is March 1, 2019, so the earlier decisions give all arms the same neutral score. The earlier project's validation results were already known when this hypothesis was proposed. This pilot uses development observations only.

On each previous-session close, include release dates in the preceding seven calendar days, excluding that close's date. Average headlines within each publication date. The neutral arm always passes 0.5. The original arm averages the seven dates after assigning 0.5 to dates without releases. The publication-day arm averages just the publication dates in that same window and returns 0.5 for an empty window. The 12% positive sentiment weight, remaining five engine inputs, position caps, 5% stock-portfolio cash buffer, whole-share sizing and 6 bp trading cost stay fixed. The stock engine executes at the next weekly open. There is one variant and no tuning.

## Development results

| Policy | Stock total return | Sharpe | Max drawdown | Turnover/year | Trades | Weeks with changed exposure | Mean / max absolute exposure change |
|---|---:|---:|---:|---:|---:|---:|---:|
| Neutral | 127.75% | 0.934 | −20.90% | 10.2254× | 1,344 | 0 | 0 / 0 bp |
| Seven calendar days | 127.70% | 0.934 | −20.90% | 10.2261× | 1,343 | 71 | 1.09 / 16 bp |
| Publication days only | 127.40% | 0.933 | −20.90% | 10.2209× | 1,338 | 76 | 3.23 / 67 bp |

Exposure differences are relative to the neutral engine, averaged across all 261 weekly decisions. A basis point is 0.01 percentage points of target exposure. Among the 142 windows with news, the median was two publication days and the mean absolute score deviation from 0.5 rose from 0.00531 to 0.01540. Measured as 10,000 times the log of terminal wealth relative to the neutral arm, the seven-day arm lost 2.48 bp and the publication-day arm lost 15.36 bp. The change amplified the model's scores and moved position sizes more, but Sharpe and total return edged down. This development replay supplies no evidence that weighting publication dates more strongly improves forecasting. The Sharpe and drawdown columns use the course rounding and first-close normalization. [Stock comparison](comparison.csv) · [Weekly scores, release counts and exposures](weekly_decisions.csv) · [Daily stock NAV](daily_nav.csv)

## Reproduction

Use the course Python environment with its data bundle at `source_code/data`. From the Assignment2 directory run the following command.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 python extensions/fingpt/release_day_pilot/run.py
```

The script selects development inputs, reconstructs publication-day means from the saved FinGPT-method model probabilities and checks those means against the published daily series. It checks the entire neutral and original seven-day daily NAV paths against the existing development results. All three stock replays use 1,259 closing NAVs. The outputs are confined to this directory by default. An alternate `--out` path allows an independent replay. [Reproduction script](run.py)
