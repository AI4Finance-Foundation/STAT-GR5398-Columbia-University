"""Trace the 12% news term and its effects on the two archived evaluation splits."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
LAST = pd.Timestamp('2023-12-31')
ARMS = {'engine': 'neutral', 'student': 'news'}


def check_model_lineage(results, metadata, cache):
    adapter = (results / 'answer_adapter.safetensors').read_bytes()
    assert hashlib.sha256(adapter).hexdigest() == metadata['adapter_sha256']
    length = struct.unpack('<Q', adapter[:8])[0]
    tensors = json.loads(adapter[8:8 + length])
    assert tensors['down']['shape'] == [2, 768] and tensors['up']['shape'] == [3, 2]
    labels = pd.read_csv(results / 'label_split.csv')
    assert labels.sentence_sha256.is_unique
    assert labels.groupby(['split', 'label']).size().to_dict() == {
        (part, label): n for part, n in [('train', 180), ('held_out', 60)]
        for label in ['negative', 'neutral', 'positive']}
    if cache:
        expected = {'pytorch_model.bin': metadata['model_sha256'],
                    'FinancialPhraseBank-v1.0.zip': metadata['phrasebank_zip_sha256']}
        expected.update({f'{year}.htm': sha for year, sha in metadata['archive_sha256'].items()})
        for filename, sha in expected.items():
            with (cache / filename).open('rb') as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha, filename


def checked_daily(results, cache):
    metadata = json.loads((results / 'training.json').read_text())
    check_model_lineage(results, metadata, cache)
    news = pd.read_csv(results / 'headline_scores.csv', parse_dates=['date'])
    daily = pd.read_parquet(results / 'student_data/news_sentiment.parquet').set_index('date').value
    assert daily.index.equals(pd.date_range('2017-01-01', LAST))
    assert news.date.between(pd.Timestamp(metadata['first_eligible_release']), LAST).all()
    assert news.url.is_unique and len(news) == metadata['release_count']
    assert np.allclose(news.p_positive + news.p_neutral + news.p_negative, 1, atol=2e-7, rtol=0)
    assert np.allclose(news.value, news.p_positive + news.p_neutral / 2, atol=1e-7, rtol=0)
    reconstructed = news.groupby('date').value.mean().reindex(daily.index, fill_value=0.5)
    assert np.allclose(daily, reconstructed, atol=1e-7, rtol=0)
    return news, daily


def load_history(source, daily):
    # Apply an upper date predicate before reading values from the distributed bundle.
    cutoff = [('date', '<=', LAST.to_pydatetime())]
    data = source / 'data'
    market = pd.read_parquet(data / 'prices/market_series.parquet', filters=cutoff)
    macro = {}
    for name in ('T10Y2Y', 'BAMLH0A0HYM2'):
        frame = pd.read_parquet(data / 'macro' / f'{name}.parquet', filters=cutoff)
        macro[name] = frame.dropna(subset=['value']).set_index('date').value.sort_index()
    prices = pd.read_parquet(data / 'prices/daily_adjusted.parquet',
                             columns=['date', 'symbol', 'close'], filters=cutoff)
    calendar = pd.DatetimeIndex(prices.dropna(subset=['close']).date.unique()).sort_values()
    spy = prices.loc[prices.symbol.eq('SPY')].groupby('date').close.last().reindex(calendar)
    extra = daily.rename_axis('date').reset_index()

    def extra_frame(name):
        assert name == 'news_sentiment'
        return extra

    bundle = SimpleNamespace(market_frame=market, macro_series=macro, extra_frame=extra_frame)
    return spy, bundle


def stock_evidence(results, period):
    equity, quantities = {}, {}
    for arm, label in ARMS.items():
        folder = results / period / arm
        equity[label] = pd.read_csv(folder / 'equity.csv', index_col=0, parse_dates=True).equity
        ledger = pd.read_csv(folder / 'trades.csv', parse_dates=['date'])
        quantities[label] = ledger.groupby(['date', 'symbol']).qty.sum()
    positions_traded = pd.concat(quantities, axis=1).fillna(0)
    changed = positions_traded.news.ne(positions_traded.neutral)
    return pd.DataFrame(equity), changed.groupby(level='date').sum()


def run(source, results, output, cache):
    sys.path.insert(0, str(source.resolve()))
    from evaluate_timing import simulate
    from shared.data_view import DataView
    from shared.guard import student_call
    from shared.metrics import performance
    from timing.baselines import engine
    from timing.engine import WEIGHT_NEWS_SENTIMENT, exposure_from_history
    from student_timing import exposure

    assert WEIGHT_NEWS_SENTIMENT == 0.12
    news, daily = checked_daily(results, cache)
    spy, bundle = load_history(source, daily)
    sessions = spy.dropna().index
    summaries, weeks = [], []
    for period in ('dev', 'val'):
        stock, changed_tickers = stock_evidence(results, period)
        period_sessions = stock.index
        week_id = period_sessions.to_period('W-SUN')
        first_sessions = period_sessions.to_series().groupby(week_id).first()
        active = []
        for rebalance in first_sessions:
            as_of = sessions[sessions.get_loc(rebalance) - 1]
            assert as_of < rebalance
            window_start = as_of - pd.Timedelta(days=7)
            window = daily.loc[(daily.index >= window_start) & (daily.index < as_of)]
            # A gap before the first stored calendar row contributes neutral probability.
            mean_score = 0.5 + (window.to_numpy(dtype=float) - 0.5).sum() / 7
            publications = news.loc[news.date.between(window_start, as_of, inclusive='left')]
            view = DataView(bundle, as_of)
            with student_call():
                baseline = engine(as_of, view)
                live = exposure(as_of, view)
                neutral = exposure_from_history(view.market_frame(), view.macro_dict(), as_of, news_sentiment=0.5)
                signal = exposure_from_history(view.market_frame(), view.macro_dict(), as_of, news_sentiment=mean_score)
            assert neutral is not None and signal is not None
            assert live == signal.exposureMultiplier and baseline == neutral.exposureMultiplier
            assert neutral.components['news_sentiment_score'] == 0.5
            assert abs(signal.components['news_sentiment_score'] - mean_score) <= 0.000051
            expected_risk_change = WEIGHT_NEWS_SENTIMENT * (mean_score - 0.5)
            assert abs(signal.risk_score - neutral.risk_score - expected_risk_change) <= 0.000101
            for component in neutral.components:
                if component != 'news_sentiment_score':
                    assert neutral.components[component] == signal.components[component]
            active.append({'period': period, 'rebalance': rebalance, 'as_of': as_of,
                           'earliest_eligible_release': window_start, 'last_release_used': publications.date.max(),
                           'release_days': publications.date.nunique(), 'headlines_used': len(publications),
                           'news_score': mean_score, 'risk_score_delta_before_rounding': expected_risk_change,
                           'neutral_exposure': baseline, 'news_exposure': live,
                           'exposure_delta_bp': round(1e4 * (live - baseline), 2)})

        weekly = pd.DataFrame(active).set_index('rebalance')
        equ = {}
        expected = pd.read_csv(results / period / f'timing_eval_{period}.csv').set_index('timing')
        for arm, label in ARMS.items():
            held = weekly[f'{label}_exposure'].reindex(period_sessions, method='ffill')
            equ[label] = simulate(held, spy)
            for key, v in performance(equ[label]).items():
                assert abs(v - expected.at[arm, key]) < 1e-8, (period, arm, key)
        # Sum daily relative log returns for an exactly additive attribution across weeks.
        # Set the first row to zero to match the evaluator's first-close normalization.
        for name, paths in [('spy', pd.DataFrame(equ)), ('stock', stock)]:
            relative_log = np.log(paths.news / paths.neutral).diff().fillna(0)
            weekly[f'{name}_relative_log_bp'] = relative_log.groupby(week_id).sum().to_numpy() * 1e4
        dir_changes = changed_tickers.reindex(period_sessions, fill_value=0)
        weekly['stock_order_days_different'] = dir_changes.gt(0).groupby(week_id).sum().to_numpy()
        weekly['stock_symbol_orders_different'] = dir_changes.groupby(week_id).sum().to_numpy()
        differs = weekly.exposure_delta_bp.ne(0)
        traded = weekly.stock_order_days_different.gt(0)
        assert weekly.loc[weekly.headlines_used.eq(0), 'exposure_delta_bp'].eq(0).all()
        published = weekly.dropna(subset=['last_release_used'])
        assert (published.last_release_used < published.as_of).all()
        summaries.append({'period': period, 'weeks': len(weekly), 'weeks_with_headlines': int(weekly.headlines_used.gt(0).sum()),
                          'weeks_with_exposure_change': int(differs.sum()), 'mean_abs_exposure_delta_bp': weekly.exposure_delta_bp.abs().mean(),
                          'max_abs_exposure_delta_bp': weekly.exposure_delta_bp.abs().max(),
                          'weeks_with_stock_order_differences': int(traded.sum()),
                          'stock_order_days_different': int(weekly.stock_order_days_different.sum()),
                          'stock_symbol_orders_different': int(weekly.stock_symbol_orders_different.sum()),
                          'first_different_order_date': dir_changes.index[dir_changes.gt(0)].min(),
                          'spy_relative_log_bp': weekly.spy_relative_log_bp.sum(),
                          'stock_relative_log_bp': weekly.stock_relative_log_bp.sum(),
                          'stock_log_bp_in_changed_exposure_weeks': weekly.loc[differs, 'stock_relative_log_bp'].sum(),
                          'stock_log_bp_in_equal_exposure_weeks': weekly.loc[~differs, 'stock_relative_log_bp'].sum()})
        weeks.append(weekly.reset_index())
    output.mkdir(exist_ok=True, parents=True)
    pd.concat(weeks).to_csv(output / 'signal_weeks.csv', index=False, float_format='%.10g', date_format='%Y-%m-%d')
    pd.DataFrame(summaries).to_csv(output / 'signal_impact.csv', index=False, float_format='%.10g', date_format='%Y-%m-%d')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--results', type=Path, default=HERE / 'results')
    parser.add_argument('--out', type=Path, default=HERE / 'results')
    parser.add_argument('--cache', type=Path, help='Optionally verify hashes of cached model, corpus and news archives')
    args = parser.parse_args()
    run(args.source, args.results, args.out, args.cache)
