# Which statement was available immediately before each meeting?

For each of the 55 scheduled announcements in the original 2017–2023 corpus, use the preceding public FOMC policy statement in publication-time order. The source inventory covers the final scheduled announcement of 2016 and all calendar items explicitly labelled “Statement” that announce or reaffirm a numerical federal funds target, including a target reiterated in the Committee's own domestic policy directive within that release. The original 55 scheduled releases are the only scored events. The chronology contains five additional releases that supply history. [Original corpus and sources](../statement_comparison/SOURCES.md) · [All 55 dated pairs and their official URLs](pairs.csv) · [Five supplementary source texts and timestamps](predecessor_statements.jsonl)

| Public release (Eastern) | Role in the chronology | Official release |
|---|---|---|
| Dec 14, 2016, 2 p.m. EST | Final regular decision before the first 2017 meeting. Target raised to 0.50–0.75%. | [Decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20161214a.htm) |
| Oct 11, 2019, 11 a.m. EDT | Committee implementation announcement. Its inline Desk directive retained 1.75–2.00%. The Committee explicitly described its bill purchases and repo operations as technical. This is the predecessor for Oct 30. | [Implementation statement and directive](https://www.federalreserve.gov/newsevents/pressreleases/monetary20191011a.htm) |
| Mar 3, 2020, 10 a.m. EST | First emergency cut, to 1.00–1.25%. The meeting was Mar 2, and the decision became public the following morning. | [Decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20200303a.htm) |
| Mar 15, 2020, 5 p.m. EDT | Emergency cut to 0–0.25%. One dissent favored 0.50–0.75%. The majority decision governs the extracted rate. | [Decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20200315a.htm) |
| Mar 23, 2020, 8 a.m. EDT | Asset-purchase statement approved by notation vote. The inline directive retained 0–0.25%. This is the latest comparable target record before Apr 29. | [Statement and directive](https://www.federalreserve.gov/newsevents/pressreleases/monetary20200323a.htm) |

The October 2019 and March 23, 2020 records carry the type `supplemental_directive`. The numerical target in the directive is usable. Replacing a normal outlook statement with a technical or purchases-only statement can create spurious additions or deletions of guidance phrases. The scoring rule therefore treats the wording comparison with those two predecessors as unavailable. In validation, every 2022–2023 scheduled meeting has an ordinary rate-decision predecessor. The first, January 26, 2022, compares with December 15, 2021.

The 2017 and 2018 calendars list eight regular policy statements each. The 2019 calendar also links the October technical announcement. The 2020 calendar marks the March 17–18 meeting cancelled. The March 19 and 31 votes addressed swap lines and a repo facility, respectively, while August 27 revised the longer-run strategy. None set or restated a numerical funds target. The July 28, 2020 lending-facility extension came from the Board. The July 29 meeting decision compares with June 10. The 2021–2023 calendars each list eight regular rate decisions. Separate implementation notes, minutes, projections, press conferences, strategy documents and facility releases do not create extra meeting events. [2017 calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2017.htm) · [2018](https://www.federalreserve.gov/monetarypolicy/fomchistorical2018.htm) · [2019](https://www.federalreserve.gov/monetarypolicy/fomchistorical2019.htm) · [2020](https://www.federalreserve.gov/monetarypolicy/fomchistorical2020.htm) · [July 28 Board release](https://www.federalreserve.gov/newsevents/pressreleases/monetary20200728a.htm) · [2021–2023 calendars](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)

The Board's target history counts eleven hikes during 2022–2023. Its table uses effective dates, while this study uses the earlier public statement timestamps. The historical October 11, 2019 webpage displays an October 15 update, preceding the October 30 decision used here. The four other supplemental pages show their release date as their last update. The texts come from retrospective official archives. [Target history](https://www.federalreserve.gov/monetarypolicy/openmarket.htm) · [2016 calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2016.htm)

## Rebuild or verify

Run from this directory. The first command validates the saved snapshots, text hashes and chronological pairing without a network connection. The second enumerates the calendar-linked statements, reuses the original scheduled corpus and reconstructs all five extra texts and the pairing map in a separate directory.

```sh
python build_pairs.py
python build_pairs.py --fetch /tmp/gr5398-stance-html --out /tmp/gr5398-stance-sources
```

The SHA-256 of `predecessor_statements.jsonl` is `052066d27cf9503dfe5a3605ebdcf87f250f8d5d944168596ec1d609d1c0c942`. The SHA-256 of `pairs.csv` is `ead6106db3cae7f4ca1247d5a08f49dcf009afb0182a6dcdca146281b149718b`.
