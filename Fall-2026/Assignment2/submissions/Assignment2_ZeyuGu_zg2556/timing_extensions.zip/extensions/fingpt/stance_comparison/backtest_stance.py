"""Compare two meeting signals in the same after-cost weekly stock portfolio."""
import argparse
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from statement_comparison import backtest as paired

REFERENCE = HERE.parent / "statement_comparison"
POLICIES = ("neutral", "body", "stance")


def read_signals(path, body_meetings):
    signals = pd.read_csv(path, parse_dates=["date", "previous_date"]).set_index("date").sort_index()
    assert signals.index.is_unique and signals.index.max() <= paired.LAST
    signals = signals.loc[signals.index >= body_meetings.date.min()]
    assert signals.index.equals(pd.DatetimeIndex(body_meetings.date))
    assert np.array_equal(signals.source_url, body_meetings.source_url)
    assert list(pd.to_datetime(signals.published_at_utc, utc=True)) == list(body_meetings.release_utc)
    assert (signals.previous_date < signals.index).all()
    assert signals.stance_score.between(0, 1).all()
    return signals


def weekly_schedule(prices, market, macro, period, body_meetings, stance_meetings):
    # Reuse the original release-vintage gate, publication window and rebalance calendar.
    dates, weekly = paired.weekly_decisions(prices.sessions, body_meetings, market, macro, period)
    weekly = weekly.drop(columns=["title_score", "title_exposure"])
    baseline = pd.read_csv(REFERENCE / "results/weekly_decisions.csv", parse_dates=["rebalance"],
                           converters={field: float for field in ("neutral_exposure", "body_score", "body_exposure")}
                           ).set_index("rebalance").loc[weekly.index]
    for field in ("meetings", "neutral_exposure", "body_score", "body_exposure"):
        np.testing.assert_array_equal(weekly[field], baseline[field])
    weekly["previous_meeting_date"] = ""
    weekly["stance_score"] = 0.5
    weekly["stance_exposure"] = weekly.neutral_exposure
    event = weekly.meetings.gt(0)
    assert weekly.loc[event, "meetings"].eq(1).all()
    for rebalance, row in weekly.loc[event].iterrows():
        release = stance_meetings.loc[pd.Timestamp(row.meeting_dates)]
        assert pd.Timestamp(release.published_at_utc) < row.as_of.tz_localize("America/New_York")
        stance = paired.exposure_from_history(market, macro, row.as_of, news_sentiment=release.stance_score)
        neutral = paired.exposure_from_history(market, macro, row.as_of, news_sentiment=0.5)
        for component, value in neutral.components.items():
            if component != "news_sentiment_score":
                assert stance.components[component] == value
        assert abs(stance.risk_score - neutral.risk_score - 0.12 * (release.stance_score - 0.5)) <= 0.000101
        weekly.at[rebalance, "previous_meeting_date"] = release.previous_date.date().isoformat()
        weekly.at[rebalance, "stance_score"] = release.stance_score
        weekly.at[rebalance, "stance_exposure"] = stance.exposureMultiplier
    weekly["stance_minus_body_exposure_bp"] = (weekly.stance_exposure - weekly.body_exposure) * 10000
    assert weekly.loc[~event, "stance_minus_body_exposure_bp"].eq(0).all()
    return dates, weekly


def replay(score_path, out, temp):
    assert paired.WEIGHT_NEWS_SENTIMENT == 0.12
    body_meetings = paired.read_scores(REFERENCE / "meeting_scores.csv", REFERENCE / "statements.jsonl")
    stance_meetings = read_signals(score_path, body_meetings)
    prices, monthly_scores, params, universe = paired.portfolio_inputs(temp)
    market = paired.historical_parquet("prices/market_series.parquet")
    macro = {key: paired.historical_parquet(f"macro/{key}.parquet").set_index("date").value.sort_index()
             for key in ("T10Y2Y", "BAMLH0A0HYM2")}
    archived = pd.read_csv(REFERENCE / "results/daily_nav.csv", index_col="date", parse_dates=True,
                           converters={"stocks_neutral": float, "stocks_body": float})
    summaries, differences, navs, decisions = [], [], [], []
    for period in paired.PERIOD_NAMES:
        start, end = paired.PERIODS[period]
        assert pd.Timestamp(end) <= paired.LAST
        cfg = paired.BacktestConfig(start=start, end=end, stops=False, use_exposure_engine=True)
        dates, weekly = weekly_schedule(prices, market, macro, period, body_meetings, stance_meetings)
        event = weekly.meetings.gt(0)
        curves, orders = {}, {}
        for arm in POLICIES:
            exposures = pd.Series(weekly[f"{arm}_exposure"].to_numpy(), index=weekly.as_of)

            def exposure(prev_day):
                close = pd.Timestamp(prices.last_session_on_or_before(prev_day))
                return SimpleNamespace(exposureMultiplier=float(exposures.at[close]))

            stock = paired.run_backtest(prices, monthly_scores, params, universe, cfg, exposure_fn=exposure)
            nav = stock.equity
            assert nav.index.equals(dates)
            assert all(t["model_cutoff"] < t["date"] for t in stock.weekly_targets)
            if arm in ("body", "neutral"):
                np.testing.assert_array_equal(nav, archived.loc[dates, f"stocks_{arm}"])
            orders[arm] = stock.trades.groupby(["date", "symbol"]).qty.sum()
            curves[arm] = nav
            drawdown = nav.div(nav.cummax()) - 1
            trough = drawdown.idxmin()
            traded = stock.trades.notional.abs().sum()
            summaries.append(dict(period=period, policy=arm, days=len(nav), **paired.performance(nav),
                                  max_drawdown_peak=nav.loc[:trough].idxmax(), max_drawdown_trough=trough,
                                  trades=len(stock.trades), turnover_per_year=traded / nav.mean() * 252 / len(nav),
                                  estimated_commission_slippage_usd=traded * (cfg.commission + cfg.slippage),
                                  mean_abs_score_from_neutral_meeting_weeks=(weekly.loc[event, f"{arm}_score"] - 0.5).abs().mean(),
                                  mean_abs_exposure_from_neutral_bp_meeting_weeks=10000 * (weekly.loc[event, f"{arm}_exposure"] - weekly.loc[event, "neutral_exposure"]).abs().mean()))
        ledger = pd.concat(orders, axis=1).fillna(0)
        changed = ledger.stance.ne(ledger.body).groupby(level="date").sum()
        changed.index = pd.DatetimeIndex(changed.index)
        weekly["different_stock_orders_stance_vs_body"] = changed.reindex(weekly.index, fill_value=0)
        change = weekly.stance_minus_body_exposure_bp
        stance_return, stance_drawdown = paired.exact_metrics(curves["stance"])
        body_return, body_drawdown = paired.exact_metrics(curves["body"])
        differences.append(dict(period=period, eligible_meetings=int(weekly.meetings.sum()), decision_weeks=len(weekly),
                                different_exposure_weeks=int(change.ne(0).sum()),
                                higher_exposure_weeks=int(change.gt(0).sum()), lower_exposure_weeks=int(change.lt(0).sum()),
                                mean_abs_exposure_difference_bp_meeting_weeks=change[event].abs().mean(),
                                max_abs_exposure_difference_bp=change.abs().max(),
                                different_stock_order_dates=int(changed.gt(0).sum()),
                                return_stance_minus_body_pp=stance_return - body_return,
                                max_drawdown_stance_minus_body_pp=stance_drawdown - body_drawdown))
        navs.append(pd.DataFrame(curves).assign(period=period).rename_axis("date").reset_index())
        decisions.append(weekly.reset_index())
    out.mkdir(parents=True, exist_ok=True)
    for table, name in ((pd.DataFrame(summaries), "comparison"), (pd.DataFrame(differences), "stance_vs_body"),
                        (pd.concat(navs), "daily_nav"), (pd.concat(decisions), "weekly_decisions")):
        table.to_csv(out / f"{name}.csv", index=False, date_format="%Y-%m-%d")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scores", type=Path, default=HERE / "meeting_scores.csv")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Set PYTHONHASHSEED=0 to reproduce tie ordering in course stock orders.")
    with TemporaryDirectory(prefix="gr5398-fomc-stance-") as temp:
        replay(args.scores, args.out, Path(temp))
