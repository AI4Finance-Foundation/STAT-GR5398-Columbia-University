"""Check validation rate decisions against the Board's OMO table and split NAV by year."""
import argparse
import csv
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
# The Board lists the effective date of a change; FOMC releases precede it by one day
# for these eleven actions. Source: https://www.federalreserve.gov/monetarypolicy/openmarket.htm
EFFECTIVE_CHANGES_BP = {
    "2022-03-17": 25, "2022-05-05": 50, "2022-06-16": 75, "2022-07-28": 75,
    "2022-09-22": 75, "2022-11-03": 75, "2022-12-15": 50,
    "2023-02-02": 25, "2023-03-23": 25, "2023-05-04": 25, "2023-07-27": 25,
}


def read_rows(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def verify_decisions(events):
    validation = [r for r in events if "2022" <= r["date"][:4] <= "2023"]
    changes = {}
    for row in validation:
        effective = (date.fromisoformat(row["date"]) + timedelta(days=1)).isoformat()
        amount = float(row["rate_change_bp"])
        if amount:
            changes[effective] = amount
    if len({r["date"] for r in validation}) != 16 or changes != EFFECTIVE_CHANGES_BP:
        raise ValueError("Validation rate decisions do not match the Board's historical changes.")


def annual_returns(navs):
    validation = [r for r in navs if r["period"] == "val"]
    if not validation or [r["date"] for r in validation] != sorted({r["date"] for r in validation}):
        raise ValueError("Expected a chronological validation NAV series.")
    start = validation[0]
    for year in ("2022", "2023"):
        end = [r for r in validation if r["date"][:4] == year][-1]
        returns = {arm: 100 * (float(end[arm]) / float(start[arm]) - 1)
                   for arm in ("neutral", "body", "stance")}
        yield {"year": year, "start_close": start["date"], "end_close": end["date"],
               **{arm + "_return_pct": value for arm, value in returns.items()},
               "stance_minus_body_pp": returns["stance"] - returns["body"]}
        start = end


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", type=Path, default=HERE / "meeting_scores.csv")
    parser.add_argument("--results", type=Path, default=HERE / "results")
    args = parser.parse_args()
    verify_decisions(read_rows(args.events))
    annual = list(annual_returns(read_rows(args.results / "daily_nav.csv")))
    with (args.results / "validation_years.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(annual[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(annual)
