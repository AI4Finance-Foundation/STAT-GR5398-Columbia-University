"""Compare each scheduled FOMC decision with its immediately preceding statement."""
import argparse
import csv
from datetime import datetime
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
from typing import NamedTuple

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / "statement_comparison"
DASHES = str.maketrans({dash: "-" for dash in "‐‑‒–—−"})
NUMBER = r"\d+(?:-\d+/\d+|/\d+|\.\d+)?"
BOUNDS = rf"(?P<low>{NUMBER}) to (?P<high>{NUMBER}) percent\b"
RATE_DECISION = re.compile(
    r"decided (?:today )?to (?P<action>raise|maintain|keep|lower) the target range for the federal funds rate "
    r"(?:by [^,;.]+,\s*)?(?:at|to) " + BOUNDS, re.I)
DIRECTIVE = re.compile(r"maintain the federal funds rate in a target range of " + BOUNDS, re.I)

# The patterns recognize prospective rate language, not mentions of inflation, borrowing
# costs or completed actions. Put limited forecasts before more general forecasts.
GUIDANCE_RULES = [
    ("limited_rate_increases", 1, r"(?:only|some further) gradual increases in the (?:target range|federal funds rate)"),
    ("conditional_firming", 1, r"(?:anticipates|expects|judges) that (?:some )?(?:additional|further) (?:policy (?:firming|tightening)|(?:rate )?increases) may be appropriate"),
    ("planned_rate_increases", 2, r"(?:ongoing increases in the target range will be appropriate|(?:further )?gradual increases in the (?:target range|federal funds rate))"),
    ("upcoming_hike", 2, r"(?:expects|anticipates) (?:that )?it will (?:soon )?be appropriate to raise the target range"),
    ("lower_bound_commitment", -2, r"expects (?:it will be appropriate )?to maintain (?:this|the current) target range until"),
    ("conditional_support", -1, r"will act as appropriate to sustain the expansion"),
    ("conditional_easing", -1, r"(?:anticipates|expects|judges) that (?:some )?(?:additional|further) (?:policy easing|rate cuts) may be appropriate"),
    ("planned_easing", -2, r"(?:ongoing (?:reductions|decreases) in the target range will be appropriate|(?:expects|anticipates) (?:that )?it will (?:soon )?be appropriate to lower the target range)"),
]
OPEN_PATTERNS = [
    ("assess_further_firming", r"in determining the extent (?:to which (?:any )?additional policy firming may be appropriate|of (?:any )?additional policy firming that may be appropriate)"),
    ("patient", r"will be patient as it determines what future adjustments"),
    ("present_stance_appropriate", r"current stance of monetary policy is appropriate"),
    ("assess_path", r"as it assesses the appropriate path of the target range"),
]
NEGATION = re.compile(r"\b(?:not|never|unlikely|no longer)\b", re.I)


class Policy(NamedTuple):
    lower: Fraction
    upper: Fraction
    action: str
    rate_phrase: str
    guidance: int | None
    rule: str
    guidance_phrase: str


def load(path):
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    for row in records:
        if hashlib.sha256(row["body"].encode()).hexdigest() != row["body_sha256"]:
            raise ValueError(f"Body hash mismatch on {row['date']}")
    return records


def as_fraction(value):
    return sum((Fraction(part) for part in value.split("-")), start=Fraction())


def wording(majority, upper):
    sentences = re.split(r"(?<=[.!?])\s+", majority)
    for name, level, pattern in GUIDANCE_RULES:
        if name == "lower_bound_commitment" and upper > Fraction(1, 4):
            continue
        for sentence in sentences:
            match = re.search(pattern, sentence, re.I)
            if match:
                # A negated prediction is not a positive commitment. In this small
                # corpus, abstain rather than reverse an unrecognized construction.
                clause_start = max(sentence.rfind(";", 0, match.start()), sentence.rfind(".", 0, match.start())) + 1
                if not NEGATION.search(sentence[clause_start:match.start()]):
                    return level, name, sentence
    for name, pattern in OPEN_PATTERNS:
        for sentence in sentences:
            if re.search(pattern, sentence, re.I):
                return 0, name, sentence
    return 0, "no_recognized_path", ""


def parse_policy(row):
    text = row["body"].translate(DASHES)
    # A dissenter can explicitly request a *different* numerical target. The
    # appended directive is consulted only for releases devoted to implementation.
    majority = re.split(r"\bVoting (?:for|against)\b", text, maxsplit=1, flags=re.I)[0]
    supplemental = row.get("statement_type") == "supplemental_directive"
    match = DIRECTIVE.search(text) if supplemental else RATE_DECISION.search(majority)
    if match is None:
        raise ValueError(f"No adopted target range in {row['date']}")
    lower, upper = map(as_fraction, match.group("low", "high"))
    if lower < 0 or upper - lower != Fraction(1, 4):
        raise ValueError(f"Unexpected target range, check published text on {row['date']}")
    if supplemental:
        return Policy(lower, upper, "maintain", match.group(), None, "supplemental_directive", "")
    guidance, rule, phrase = wording(" ".join(majority.split()), upper)
    return Policy(lower, upper, match.group("action").lower(), match.group(), guidance, rule, phrase)


def sign(value):
    return int(value > 0) - int(value < 0)


def score(scheduled, supplemental, pairs):
    timeline = sorted(scheduled + supplemental, key=lambda row: row["published_at_utc"])
    schedule = {row["date"] for row in scheduled}
    time = [datetime.fromisoformat(row["published_at_utc"]) for row in timeline]
    if time != sorted(set(time)) or len({row["date"] for row in timeline}) != len(timeline):
        raise ValueError("Expected chronologically unique official decision dates")
    policies = [parse_policy(row) for row in timeline]
    results = []
    for previous, current, old, new in zip(timeline, timeline[1:], policies, policies[1:]):
        day = current["date"]
        if day not in schedule:
            continue
        if previous["date"] != pairs[day]:
            raise ValueError(f"The calendar predecessor disagrees on {day}")
        change = 100 * (new.lower + new.upper - old.lower - old.upper) / 2
        rate = sign(change)
        expected = {"raise": 1, "lower": -1, "maintain": 0, "keep": 0}[new.action]
        if expected != rate:
            raise ValueError(f"Range change contradicts the decision verb on {day}")
        comparable = new.guidance is not None and old.guidance is not None
        wording_vote = sign(new.guidance - old.guidance) if comparable else 0
        net = rate + wording_vote
        results.append(dict(date=day, previous_date=previous["date"], published_at_et=current["published_at_et"],
                            published_at_utc=current["published_at_utc"], source_url=current["source_url"],
                            previous_published_at_utc=previous["published_at_utc"], previous_source_url=previous["source_url"],
                            target_lower_pct=float(new.lower), target_upper_pct=float(new.upper),
                            previous_lower_pct=float(old.lower), previous_upper_pct=float(old.upper),
                            rate_change_bp=float(change), rate_component=rate,
                            guidance_level=new.guidance, previous_guidance_level=old.guidance,
                            comparable_guidance=comparable, wording_component=wording_vote,
                            stance_label={-1:"dovish",0:"neutral",1:"hawkish"}[sign(net)],
                            stance_score=0.5 - 0.25 * net,
                            rate_phrase=new.rate_phrase, previous_rate_phrase=old.rate_phrase, guidance_rule=new.rule,
                            previous_guidance_rule=old.rule, guidance_phrase=new.guidance_phrase,
                            previous_guidance_phrase=old.guidance_phrase))
    if {r["date"] for r in results} != schedule:
        raise ValueError("Missing a scheduled meeting or predecessor")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE / "meeting_scores.csv")
    args = parser.parse_args()
    with (HERE / "pairs.csv").open(encoding="utf-8") as handle:
        pairs = {row["event_date"]: row["prior_date"] for row in csv.DictReader(handle)}
    rows = score(load(ORIGINAL / "statements.jsonl"), load(HERE / "predecessor_statements.jsonl"), pairs)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"Paired {len(rows)} scheduled statements with their latest official predecessor.")


if __name__ == "__main__":
    main()
