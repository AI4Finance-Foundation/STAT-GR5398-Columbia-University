# A change in the policy rate and its forward guidance

This historical experiment defines one rule before replaying the paired portfolios. The policy text and historical formulations were available during design, and earlier research had already examined these markets. The rule is hand-coded, with no model fitting or return-based search. It has no public preregistration.

For each scheduled decision, compare its target-range midpoint with the midpoint in the immediately preceding official policy statement. A hike contributes +1, a hold 0 and a cut −1. Record both bounds and the move in basis points. A smaller hike still raises the policy rate. This component measures the actual rate change, which can differ from what investors expected.

Read the majority's rate-path guidance in both documents. Exclude votes, dissents, and the appended implementation directive when reading forward guidance. Recognize these ordered categories.

| Level | Wording |
|---:|---|
| +2 | Explicit expectation of an upcoming hike, or projected repeated increases in the policy rate. |
| +1 | Qualified or limited tightening: for example, only gradual increases, some further gradual increases, or an explicit expectation that some further tightening may be appropriate. |
| 0 | Open-ended assessment or no recognized directional commitment. “Patient” and language assessing *whether or to what extent* further firming may be appropriate fall here. |
| −1 | Conditional commitment to act to sustain the expansion, or a qualified indication of future rate cuts. |
| −2 | Explicit guidance to hold rates at the effective lower bound until economic conditions are met, or a firm expectation of future cuts. |

Match specific forward-looking phrases in the majority text. The rate decision's past-tense action, present descriptions of the policy stance, inflation commentary, and announcements about asset holdings alone do not set a guidance level. An unchanged phrase retains the same level. The wording component equals the sign of the current level minus the previous level. A technical or asset-purchase-only predecessor has a genuine date and target range but lacks comparable forward rate guidance. Record that comparison as unavailable and give its wording component zero. The later scheduled statement remains eligible.

Add the two signed components. Positive sums classify the change as hawkish, negative sums as dovish and zero as flat or offsetting. Feed `0.5 − 0.25 × (rate component + wording component)` to the existing 12% news input. Thus a hawkish change lowers target equity exposure and a dovish change raises it before the engine's scaling and caps. Equal weights, five possible signal values and the direction were fixed before computing portfolio outcomes. An unchanged or offsetting decision is neutral. The generic full-body model has a narrower historical score range, so the portfolio comparison includes the different signal amplitudes as well as their directions.

The rule measures the committee's rate action and explicit forward guidance. It only makes a trading decision at the same weekly rebalance as the full-body experiment. It does not measure the surprise versus a futures-implied distribution. Fine shades of macro commentary, the economic significance of asset purchases, and some changes in conditional wording fall outside the phrase rules.

## Signal checks

All 55 scheduled releases have an earlier, dated policy statement. The full-body model's eligibility cutoff leaves 38 common dates. Over the 22 development decisions the rule gives 18 neutral and four dovish signals. The 16 validation decisions give ten hawkish and six neutral signals. Validation contains 11 hikes and five holds. Its tightening cycle gives no validation observation of a dovish portfolio decision.

| Decision | Target-rate move | Change in majority rate guidance | Trading score |
|---|---:|---|---:|
| January 26, 2022 | Hold | From maintaining the low target until employment conditions were met to expecting an increase soon | 0.25 |
| February 1, 2023 | +25 bp | Repeats the preceding meeting's commitment to ongoing increases | 0.25 |
| March 22, 2023 | +25 bp | Softens that commitment to an expectation that some additional firming may be appropriate | 0.50 |
| May 3, 2023 | +25 bp | Moves from expecting some additional firming to assessing its potential extent | 0.50 |

March and May combine a hawkish rate move with a dovish change in forward wording. October 30, 2019 and April 29, 2020 follow supplemental directives and therefore receive a zero wording component. All current and previous timestamps, target intervals, numerical components, matched clauses and links to the original releases are in the [event ledger](meeting_scores.csv). The [scoring code](score_policy.py) rebuilds the ledger offline with the Python standard library.
