"""Verify the chronological FOMC predecessor pairs; optionally rebuild them from Board pages."""
import argparse
import csv
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import re
import sys
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
SCHEDULED = HERE.parent / "statement_comparison"
sys.path.insert(0, str(SCHEDULED))
from fetch_statements import BASE, CALENDAR, DECISION_LINK, EASTERN, clean, match, page, validate

FIRST = "20161214"
EXTRA_TYPES = {
    "20161214": "rate_decision",
    "20191011": "supplemental_directive",
    "20200303": "rate_decision",
    "20200315": "rate_decision",
    "20200323": "supplemental_directive",
}


def calendar_entries(year, cache):
    """Enumerate every calendar link explicitly labelled as the monetary policy Statement."""
    if year >= 2021:
        html = page(CALENDAR, cache)
        panel = re.search(rf">{year} FOMC Meetings</a></h4>(.*?)(?:\d{{4}} FOMC Meetings</a></h4>|$)", html, re.S)
        if panel:
            blocks = re.split(r'<div class="[^"]*\brow fomc-meeting"[^>]*>', panel[1])[1:]
            rows = []
            for block in blocks:
                statement = re.search(r"<strong>Statement:</strong>.*?href=\"" + DECISION_LINK + r'">\s*HTML\s*</a>', block, re.S)
                if statement:
                    rows.append((urljoin(BASE, statement[1]), CALENDAR, ""))
            return rows
    calendar = BASE + f"/monetarypolicy/fomchistorical{year}.htm"
    rows = []
    for block in re.split(r"<h5\b[^>]*>", page(calendar, cache))[1:]:
        heading, _, details = block.partition("</h5>")
        for stmt in re.finditer(r'href="' + DECISION_LINK + r'">\s*Statement\s*</a>', details):
            if stmt[2] >= FIRST:
                rows.append((urljoin(BASE, stmt[1]), calendar, clean(heading)))
    return rows


def release_record(html, url, calendar, label):
    article = match(r'<div id="article">(.*?)<div id="lastUpdate"', html)
    day = datetime.strptime(clean(match(r'<p class="article__time">(.*?)</p>', article)), "%B %d, %Y")
    stamp_text = clean(match(r'<p class="releaseTime">([^<]+)', article))
    clock = re.fullmatch(r"For release at (\d{1,2}:\d{2}) ([ap])\.m\. (EDT|EST)", stamp_text)
    if not clock:
        raise ValueError(f"Unrecognized publication time on {url}")
    time = datetime.strptime(clock[1] + clock[2].upper() + "M", "%I:%M%p").time()
    stamp = datetime.combine(day.date(), time, EASTERN)
    if day.strftime("%Y%m%d") not in url or stamp.tzname() != clock[3]:
        raise ValueError(f"Publication time does not match URL or timezone: {url}")
    category = EXTRA_TYPES[day.strftime("%Y%m%d")]
    section = match(r'<div class="col-xs-12 col-sm-8 col-md-8">(.*?)</div>', article)
    # Technical releases print the Committee's directive in the same article after its announcement.
    if category == "supplemental_directive":
        head, end, _ = section.partition("</blockquote>")
        if not end:
            raise ValueError(f"Missing inline domestic policy directive on {url}")
        section = head
    paragraphs = []
    for _, content in re.findall(r"<(p|li)\b[^>]*>(.*?)</\1>", section, re.I | re.S):
        para = clean(content)
        if not para or para.startswith("In a related set of actions"):
            continue
        paragraphs.append(para)
        if category == "rate_decision" and para.startswith("Voting for"):
            break
    body = "\n\n".join(paragraphs)
    if category == "rate_decision" and not paragraphs[-1].startswith("Voting for"):
        raise ValueError(f"Missing majority vote on {url}")
    if category == "supplemental_directive" and "the federal funds rate in a target range of" not in body:
        raise ValueError(f"Missing target from Committee directive on {url}")
    return dict(date=day.date().isoformat(), published_at_et=stamp.isoformat(),
                published_at_utc=stamp.astimezone(timezone.utc).isoformat(), release_label=stamp_text,
                headline=clean(match(r'<h3 class="title">(.*?)</h3>', article)), body=body, source_url=url,
                calendar_url=calendar, meeting_label=label, statement_type=category,
                body_sha256=sha256(body.encode()).hexdigest())


def load_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def pairs_table(scheduled, extra):
    validate(scheduled)
    if {row["date"].replace("-", ""): row["statement_type"] for row in extra} != EXTRA_TYPES:
        raise ValueError("Unexpected predecessor set")
    scheduled_dates = {row["date"] for row in scheduled}
    ordered = sorted(scheduled + extra, key=lambda row: datetime.fromisoformat(row["published_at_utc"]))
    if len({r["source_url"] for r in ordered}) != len(ordered) or len({r["date"] for r in ordered}) != len(ordered):
        raise ValueError("Duplicate source or date")
    data = io.StringIO()
    writer = csv.writer(data, lineterminator="\n")
    writer.writerow(("event_date", "prior_date", "prior_statement_type", "current_source_url", "prior_source_url",
                     "current_published_at_utc", "prior_published_at_utc"))
    for row in ordered:
        if sha256(row["body"].encode()).hexdigest() != row["body_sha256"]:
            raise ValueError(f"Corrupt text on {row['date']}")
    for previous, current in zip(ordered, ordered[1:]):
        if current["date"] in scheduled_dates:
            writer.writerow((current["date"], previous["date"], previous.get("statement_type", "rate_decision"),
                             current["source_url"], previous["source_url"], current["published_at_utc"],
                             previous["published_at_utc"]))
    return data.getvalue()


def rebuild(cache, scheduled):
    cache.mkdir(parents=True, exist_ok=True)
    items = [row for year in range(2016, 2024) for row in calendar_entries(year, cache)]
    issued = {row["source_url"] for row in scheduled}
    if len({url for url, _, _ in items}) != len(items) or len(items) != len(scheduled) + len(EXTRA_TYPES):
        raise ValueError("Official calendar inventory changed; check all source links.")
    if not issued <= {url for url, _, _ in items}:
        raise ValueError("The calendar no longer includes one or more original scheduled decisions.")
    return [release_record(page(url, cache), url, calendar, label) for url, calendar, label in items if url not in issued]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch", type=Path, metavar="HTML_CACHE", help="Rebuild using official Board web pages.")
    parser.add_argument("--out", type=Path, default=HERE)
    args = parser.parse_args()
    scheduled = load_jsonl(SCHEDULED / "statements.jsonl")
    extra_path = args.out / "predecessor_statements.jsonl"
    pairs_path = args.out / "pairs.csv"
    if args.fetch:
        extra = rebuild(args.fetch, scheduled)
        table = pairs_table(scheduled, extra)
        args.out.mkdir(exist_ok=True, parents=True)
        extra_path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in extra), encoding="utf-8")
        pairs_path.write_text(table, encoding="utf-8")
    else:
        table = pairs_table(scheduled, load_jsonl(extra_path))
        if table != pairs_path.read_text(encoding="utf-8"):
            raise ValueError("Saved predecessor map differs from the chronological source inventory.")
    print(f"{len(scheduled)} event/predecessor pairs verified using {len(scheduled)+len(EXTRA_TYPES)} distinct releases.")
