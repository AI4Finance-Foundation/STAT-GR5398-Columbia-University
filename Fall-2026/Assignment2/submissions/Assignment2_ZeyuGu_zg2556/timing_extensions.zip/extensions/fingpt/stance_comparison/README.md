# Trading the change in FOMC policy

At each scheduled FOMC release, compare the new target rate and majority forward guidance with the preceding published decision. Test whether that information yields better weekly stock timing than the existing GPT-2 full-statement sentiment score. The principal endpoints are cumulative after-cost stock return and daily maximum drawdown over January 3, 2022 to December 29, 2023.

## What changes at a meeting?

The rate vote is +1 for a hike, 0 for a hold and −1 for a cut. Compare the majority’s forward guidance with its previous category on a five-level scale, from a strong easing commitment to a strong tightening commitment. A stronger category gives another +1, a softer category −1, and an unchanged category zero. Where a technical predecessor lacks comparable guidance, its wording vote is zero. Sum the votes and subtract one quarter of the sum from 0.5. A hawkish change sends a lower exposure input to the existing timing engine. Equal and opposite votes leave it neutral. The signed basis-point move and both wording levels are available for each release. [Signal rules](SIGNAL.md)

The existing full-text arm uses the frozen GPT-2 sentiment adapter and complete current statement. Its scores and weekly exposure targets come from the prior paired study. Both signals enter the same 12% news term at the same rebalance, using only statements released before the previous trading session. An empty weekly window carries a neutral score. The portfolios share the supplied course stock rankings, allocation rules, initial capital, and commission plus slippage of 6 bp per dollar traded. The retrained selection bonus remains a separate six-month study. [Prior full-statement experiment](../statement_comparison/README.md)

The code evaluates 38 scheduled releases at the same vintage cutoff as the full-body model. The rule reads policy documents and uses a fixed dictionary, with no fit to stock returns. This comparison was designed after earlier studies of the same validation market. The official valuation holdout starts in 2024 and is outside the comparison. The rule captures explicit guidance and observed rate changes. Investors may already have priced either into equities before publication.

## Validation results

| News input | Stock return | Maximum drawdown depth | Sharpe | Annual turnover |
|---|---:|---:|---:|---:|
| Neutral (0.5) | 3.786% | 27.696% | 0.194 | 7.88× |
| Full-statement sentiment | 3.765% | 27.697% | 0.193 | 7.88× |
| Change in rate and guidance | 3.298% | 27.981% | 0.181 | 7.87× |

The rule reduced cumulative return by **0.466 percentage points** relative to the full-text model and deepened maximum drawdown by **0.284 points**. All arms reached their worst drawdown on December 28, 2022, from their January 3 peak. The annual return gap was −0.300 points in 2022 and −0.058 points in 2023. The corresponding development comparison over 2017–2021 had a 0.305-point higher return but a 0.014-point deeper drawdown. [Portfolio metrics](results/comparison.csv) · [Differences from full text](results/stance_vs_body.csv) · [Validation return by year](results/validation_years.csv) · [Daily stock NAV](results/daily_nav.csv)

Of the 16 validation decisions, the rule classified 10 as hawkish and six as neutral or offsetting. No decision received a net dovish signal. The 11 hikes and five holds agree with the Board’s separate policy-rate record. For example, both February 1 and March 22, 2023 raised rates by 25 bp. February retained the expectation of successive increases. March softened that commitment, which offset the hike and moved the rule’s input from 0.25 to 0.50. [February decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20230201a.htm) · [March decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20230322a.htm) · [Federal Reserve target-rate table](https://www.federalreserve.gov/monetarypolicy/openmarket.htm)

The rule produced lower target equity exposure than full text at 11 meetings and higher exposure at two. At the other three, exposure targets matched. At the February 6, 2023 open, for example, the rule targeted 70.27% exposure and full text 72.32%. Across the 16 event weeks the rule’s mean absolute distance from the neutral portfolio was 0.854 percentage points of target exposure, compared with 0.067 points for full text. The experiment jointly changes the direction and strength of trades. This tightening-heavy sample provides little evidence about performance during easing. [Weekly exposures](results/weekly_decisions.csv) · [Every meeting, both source statements and phrase evidence](meeting_scores.csv)

## Reproduce the comparison

Run the following from the course Assignment2 directory, using the course Python environment and data bundle. The included statement snapshots, previous full-text scores and timing inputs allow an offline replay. `validation_detail.py` checks the eleven effective-date changes against the Board’s published table, verifies the five holds and writes the two validation years separately. Each arm carries its own December 2022 equity into 2023.

```sh
python extensions/fingpt/stance_comparison/build_pairs.py
python extensions/fingpt/stance_comparison/score_policy.py
PYTHONHASHSEED=0 python extensions/fingpt/stance_comparison/backtest_stance.py
python extensions/fingpt/stance_comparison/validation_detail.py
```
