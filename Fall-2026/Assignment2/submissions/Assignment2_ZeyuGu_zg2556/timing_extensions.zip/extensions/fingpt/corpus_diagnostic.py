"""Describe the fixed Fed headline archive. Run with the course pandas environment."""
import argparse
from pathlib import Path
import re
from urllib.parse import urlsplit

import pandas as pd


HERE = Path(__file__).resolve().parent
EXACT_TITLE = "Federal Reserve issues FOMC statement"
BOARD_URL = re.compile(r"/newsevents/pressreleases/(bcreg|enforcement|monetary|orders|other)\d{8}[a-z]\.htm")
REGIONAL_HOSTS = {"www.bostonfed.org", "www.dallasfed.org", "www.chicagofed.org", "www.kansascityfed.org"}
TOPICS = ["bcreg", "enforcement", "monetary", "orders", "other", "regional_fed_link"]
CALENDAR_URL = "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
CALENDAR_CHECKED = "2026-11-22"
# Pinned transcription of the Statement > HTML links for scheduled 2022 and
# 2023 meetings. The separate implementation notes, projections and minutes are
# different releases. Keep the exact path suffix even when the dates coincide.
STATEMENT_PATHS = {
    "2022-01-26": "monetary20220126a.htm",
    "2022-03-16": "monetary20220316a.htm",
    "2022-05-04": "monetary20220504a.htm",
    "2022-06-15": "monetary20220615a.htm",
    "2022-07-27": "monetary20220727a.htm",
    "2022-09-21": "monetary20220921a.htm",
    "2022-11-02": "monetary20221102a.htm",
    "2022-12-14": "monetary20221214a.htm",
    "2023-02-01": "monetary20230201a.htm",
    "2023-03-22": "monetary20230322a.htm",
    "2023-05-03": "monetary20230503a.htm",
    "2023-06-14": "monetary20230614a.htm",
    "2023-07-26": "monetary20230726a.htm",
    "2023-09-20": "monetary20230920a.htm",
    "2023-11-01": "monetary20231101a.htm",
    "2023-12-13": "monetary20231213a.htm",
}


def url_key(url):
    parts = urlsplit(url)
    return parts.hostname.lower(), parts.path


def calendar_coverage(news):
    archived_urls = set(news.url.map(url_key))
    rows = []
    for date, filename in STATEMENT_PATHS.items():
        url = f"https://www.federalreserve.gov/newsevents/pressreleases/{filename}"
        same_day = news.loc[news.date.eq(pd.Timestamp(date)), "url"]
        rows.append({"year": int(date[:4]), "statement_date": date, "statement_url": url,
                     "matched_statement_url": url_key(url) in archived_urls,
                     "same_date_archive_count": len(same_day), "same_date_archive_urls": " ".join(same_day),
                     "calendar_url": CALENDAR_URL, "calendar_checked": CALENDAR_CHECKED})
    return pd.DataFrame(rows)


def topic_for(url):
    parsed = urlsplit(url)
    if parsed.hostname == "www.federalreserve.gov":
        match = BOARD_URL.fullmatch(parsed.path)
        if match:
            return match.group(1)
    if parsed.hostname in REGIONAL_HOSTS:
        return "regional_fed_link"
    raise ValueError(f"Unclassified archive link: {url}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=HERE / "results/headline_scores.csv")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    news = pd.read_csv(args.input, parse_dates=["date"])
    if not news.date.between("2017-01-01", "2023-12-31").all() or not news.url.is_unique:
        raise ValueError("Expected unique release URLs within the archived dev/validation dates")
    news["topic"] = news.url.map(topic_for)
    news["exact_fomc_title"] = news.headline.eq(EXACT_TITLE)
    news["minutes_title"] = news.headline.str.contains(r"\bminutes of\b", case=False, regex=True)
    news["abs_from_neutral"] = news.value.sub(0.5).abs()
    news["period"] = news.date.lt("2022-01-01").map({True: "dev", False: "val"})
    rows = []
    for split, section in [("dev", news[news.period.eq("dev")]),
                           ("val", news[news.period.eq("val")]), ("pooled", news)]:
        for topic in TOPICS:
            group = section.loc[section.topic.eq(topic)]
            rows.append({
                "period": split, "url_topic": topic, "headlines": len(group),
                "split_headlines": len(section), "share_of_split": len(group) / len(section),
                "release_days": group.date.nunique(), "mean_score": group.value.mean(),
                "score_sd": group.value.std(), "median_abs_from_0_5": group.abs_from_neutral.median(),
                "exact_fomc_title": int(group.exact_fomc_title.sum()),
                "titles_containing_minutes_of": int(group.minutes_title.sum()),
            })
    summary = pd.DataFrame(rows)
    assert (summary.groupby("period").headlines.sum() == summary.groupby("period").split_headlines.first()).all()
    args.out.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.out / "corpus_topics.csv", index=False, float_format="%.10g")
    columns = ["period", "date", "headline", "url", "p_negative", "p_neutral", "p_positive", "value"]
    news.loc[news.exact_fomc_title, columns].sort_values("date").to_csv(
        args.out / "corpus_repeated_fomc.csv", index=False, date_format="%Y-%m-%d")
    calendar_coverage(news).to_csv(args.out / "corpus_calendar_coverage.csv", index=False)


if __name__ == "__main__":
    main()
