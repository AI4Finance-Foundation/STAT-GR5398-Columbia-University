"""Fit one exposure multiplier on scheduled meeting weeks in development."""
import argparse
import csv
from datetime import date, datetime
import hashlib
import json
from math import fsum, isclose
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
WEEKLY = HERE.parent / "stance_comparison/results/weekly_decisions.csv"
STATEMENTS = HERE.parent / "statement_comparison/statements.jsonl"
START = date(2017, 1, 3)
END = date(2021, 12, 31)
ELIGIBLE = date(2019, 3, 1)
BP = 10_000
EASTERN = ZoneInfo("America/New_York")
FIELDS = ("rebalance", "as_of", "meetings", "meeting_dates", "published_at_utc",
          "neutral_exposure", "body_exposure", "stance_exposure")


def calibrated_target(neutral, stance, scale):
    return neutral + scale * (stance - neutral)


def development_weeks(weekly_path):
    selected = []
    with weekly_path.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row["period"] != "dev":
                continue
            selected.append({field: row[field] for field in FIELDS})
    return selected


def eligible_release_times(path):
    eligible = {}
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            item = json.loads(line)
            day = date.fromisoformat(item["date"])
            if ELIGIBLE <= day <= END:
                eligible[day] = datetime.fromisoformat(item["published_at_utc"])
    return eligible


def fit(weeks, eligible):
    dates = [date.fromisoformat(row["rebalance"]) for row in weeks]
    if len(dates) != 261 or dates != sorted(set(dates)) or dates[0] != START or dates[-1] != date(2021,12,27):
        raise ValueError("Expected all 261 dated rebalances in the original development period.")
    events = []
    target_triples = []
    for row, day in zip(weeks, dates):
        cutoff = date.fromisoformat(row["as_of"])
        neutral, body, stance = (float(row[key]) for key in ("neutral_exposure", "body_exposure", "stance_exposure"))
        if cutoff >= day or any(not 0 <= value <= 1 for value in (neutral, body, stance)):
            raise ValueError(f"Invalid target or decision date for {day}.")
        if row["meetings"] == "0":
            if body != neutral or stance != neutral or row["meeting_dates"] or row["published_at_utc"]:
                raise ValueError(f"Unexpected policy tilt or event on a non-meeting week: {day}.")
            continue
        if row["meetings"] != "1":
            raise ValueError(f"Expected one eligible meeting in this window: {day}.")
        event = date.fromisoformat(row["meeting_dates"])
        timestamp = datetime.fromisoformat(row["published_at_utc"])
        if (timestamp != eligible.get(event) or timestamp.astimezone(EASTERN).date() != event
                or not 1 <= (cutoff - event).days <= 7):
            raise ValueError(f"Meeting timestamp outside the original timing window for {day}.")
        events.append(event)
        target_triples.append((neutral, body, stance))
    if len(events) != 22 or events != sorted(eligible):
        raise ValueError("Expected each of the 22 eligible development meetings exactly once.")
    sum_body = fsum(abs(body - neutral) for neutral, body, _ in target_triples)
    sum_stance = fsum(abs(stance - neutral) for neutral, _, stance in target_triples)
    if not 0 < sum_body < sum_stance:
        raise ValueError("The development tilts do not admit the requested contraction.")
    scale = sum_body / sum_stance
    calibrated = [calibrated_target(neutral, stance, scale) for neutral, _, stance in target_triples]
    sum_calibrated = fsum(abs(scaled - neutral) for scaled, (neutral, _, _) in zip(calibrated, target_triples))
    if not isclose(sum_body, sum_calibrated, rel_tol=1e-12, abs_tol=1e-15):
        raise ValueError("The calibrated target sizes differ from the development full-text average.")
    for scaled, (neutral, _, stance) in zip(calibrated, target_triples):
        if not min(neutral, stance) <= scaled <= max(neutral, stance) or (stance != neutral and scaled == neutral):
            raise ValueError("Calibration did not preserve a weekly target's direction.")
    digest = hashlib.sha256(json.dumps(weeks, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {
        "scale": scale,
        "formula": "neutral_exposure + scale * (stance_exposure - neutral_exposure)",
        "development": {
            "weeks": len(weeks), "event_weeks": len(events),
            "first_event": events[0].isoformat(), "last_event": events[-1].isoformat(),
            "body_mean_abs_target_shift_bp": BP * sum_body / len(events),
            "stance_mean_abs_target_shift_bp": BP * sum_stance / len(events),
            "calibrated_mean_abs_target_shift_bp": BP * sum_calibrated / len(events),
            "projected_weekly_inputs_sha256": digest,
        },
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weekly", type=Path, default=WEEKLY)
    parser.add_argument("--statements", type=Path, default=STATEMENTS)
    parser.add_argument("--out", type=Path, default=HERE / "calibration.json")
    args = parser.parse_args()
    result = fit(development_weeks(args.weekly), eligible_release_times(args.statements))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Development scale {result['scale']:.8f} from {result['development']['event_weeks']} meetings.")
