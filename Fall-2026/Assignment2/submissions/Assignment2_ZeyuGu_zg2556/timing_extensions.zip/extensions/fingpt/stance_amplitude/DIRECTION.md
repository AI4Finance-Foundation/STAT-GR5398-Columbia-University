# Did the exposure change point the right way?

A weekly reduction in equity exposure helps relative to zero-yield cash if the stock basket falls between the execution open and the following rebalance open. An increase helps if the basket rises. This diagnostic checks that sign on the basket selected by the neutral portfolio at the same time. Trade sizes and the resulting after-cost NAVs are reported separately in the portfolio comparison.

## Validation observations

| 2022–2023 | Meetings |
|---|---:|
| Eligible meetings with a complete opening-price window | 16 |
| Actual reductions in the rule’s target relative to neutral | 9 |
| Reductions followed by a fall in the basket | 4 |
| Reductions followed by a rise in the basket | 5 |
| Neutral or offsetting policy scores | 6 |
| Hawkish score with the same capped target as neutral | 1 |

All nine actionable risk reductions have the same sign under the raw and scaled rule. Over these nine windows the tradable basket gained 1.920% on average. Exposure was reduced ahead of more rising weeks than falling ones, and the average move also went against reducing risk. Nine reductions during one tightening cycle give limited information about forecasting skill in other periods. There were no actionable increases in this validation sample. In development there were two actionable increases in 22 eligible meetings, one followed by a gain and one by a loss. Matching a mean exposure shift over that development period consequently draws on few active raw-rule observations.

## Observation and accounting conventions

1. Reconstruct the neutral portfolio from its original signed share fills, adjusted execution prices, $100,000 opening cash, and 6 bp per dollar traded. Its daily closing equity, including carried marks, matches the prior neutral archive to within $0.000001 in both periods. All archived fills occurred at weekly rebalances. The starting weights for a given window are the neutral shares held just after trading at its first open, weighted by that open’s adjusted prices.
2. Restrict the basket to stocks with a quoted positive opening price on the entry date. Hold those quantities fixed until the next weekly opening price, before new fills. Cash is excluded from both the numerator and denominator. Every one of the 38 eligible meetings has a complete window of four or five trading sessions. Every included position had a positive, observed exit-opening price. Returns use status and holdings known at entry; the exit price is used only as an outcome.
3. The course portfolio carried 235 DISCK shares at a stale closing mark after April 2022. In 14 of the 16 validation event windows DISCK had no executable entry open and was excluded from this *tradable basket* diagnostic. All 16 validation windows still contain ten tradable stocks each. The reported portfolio NAVs follow the original course accounting for the held position. The event file identifies the excluded name on every affected row.
4. Define the direction by the raw rule’s **implemented target minus the neutral engine’s target**, after caps. All scaled nonzero shifts have the same sign. Unchanged targets abstain. If the forward basket return is exactly flat within numerical tolerance, it is recorded separately. Correctness is measured against the neutral basket and zero-yield cash; full-body sentiment is a comparator with its own target.
5. For each arm, multiply its target deviation from neutral by the fractional basket return to obtain a gross directional proxy. Summing this over validation gives −24.64 bp for the original rule, −8.35 bp for the scaled rule and +0.61 bp for the body model. These are unweighted sums of weekly contributions in basis points of starting capital for each window. They omit the 5% cash buffer, whole-share trading, position carryover, execution costs and compounding. Use the daily replay for realized strategy returns and drawdowns.

[Per-meeting baskets and outcomes](results/direction_events.csv) · [Counts and gross directional proxy](results/direction_summary.csv) · [Reproduction code](direction.py)

From the course Assignment2 directory, run the following after generating the amplitude replay’s weekly decisions. Use the same course Python environment and its local price bundle.

```sh
python extensions/fingpt/stance_amplitude/direction.py
```
