"""Replay the three archived timing targets and a development-scaled stance target."""
import argparse
import json
import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd
import calibrate

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from statement_comparison import backtest as course

PREVIOUS = HERE.parent / "stance_comparison" / "results"
ORIGINAL = ("neutral", "body", "stance")
POLICIES = (*ORIGINAL, "scaled")
CONTRASTS = (("scaled", "body"), ("scaled", "stance"), ("scaled", "neutral"),
             ("stance", "body"), ("stance", "neutral"), ("body", "neutral"))


def schedules(sessions, calibration):
    scale = calibration["scale"]
    if not 0 < scale < 1:
        raise ValueError("This experiment requires a positive shrinkage coefficient below one.")
    weekly = pd.read_csv(PREVIOUS / "weekly_decisions.csv", parse_dates=["rebalance", "as_of"],
                         converters={f"{arm}_exposure": float for arm in ORIGINAL}).set_index("rebalance")
    dev = weekly.loc[weekly.period == "dev"]
    val = weekly.loc[weekly.period == "val"]
    assert dev.index.max() < val.as_of.min() and val.index.max() <= course.LAST
    assert pd.Timestamp(calibration["development"]["last_event"]) < val.as_of.min()
    event = weekly.meetings.eq(1)
    assert weekly.meetings.isin([0, 1]).all() and weekly.index.is_unique
    assert (pd.to_datetime(weekly.loc[event, "published_at_utc"], utc=True)
            < weekly.loc[event, "as_of"].dt.tz_localize("America/New_York")).all()
    assert (weekly.loc[event, "previous_meeting_date"] < weekly.loc[event, "meeting_dates"]).all()
    assert weekly.loc[event, "meeting_dates"].is_unique
    assert (weekly.as_of < weekly.index).all() and weekly.as_of.is_unique
    np.testing.assert_array_equal(weekly.as_of, sessions[sessions.get_indexer(weekly.index) - 1])
    # Interpolate already capped final target exposures. No second rounding or clipping.
    weekly["scaled_exposure"] = calibrate.calibrated_target(weekly.neutral_exposure, weekly.stance_exposure, scale)
    for arm in POLICIES:
        assert weekly[f"{arm}_exposure"].between(0, 1).all()
        np.testing.assert_array_equal(weekly.loc[~event, f"{arm}_exposure"], weekly.loc[~event, "neutral_exposure"])
    shift = weekly.scaled_exposure - weekly.neutral_exposure
    np.testing.assert_array_equal(np.sign(shift), np.sign(weekly.stance_exposure - weekly.neutral_exposure))
    fit = (weekly.period == "dev") & event
    assert fit.sum() == calibration["development"]["event_weeks"] == 22
    assert len(dev) == calibration["development"]["weeks"]
    np.testing.assert_allclose(shift.loc[fit].abs().mean(),
                               (weekly.body_exposure - weekly.neutral_exposure).loc[fit].abs().mean(),
                               rtol=0, atol=1e-12)
    return weekly.drop(columns=["different_stock_orders_stance_vs_body", "stance_minus_body_exposure_bp"])


def replay(calibration_file, out, scratch):
    calibration = json.loads(calibration_file.read_text())
    if calibration != calibrate.fit(calibrate.development_weeks(calibrate.WEEKLY),
                                     calibrate.eligible_release_times(calibrate.STATEMENTS)):
        raise ValueError("Frozen scale and its provenance must match the development-only calibration.")
    prices, scores, params, universe = course.portfolio_inputs(scratch)
    weekly = schedules(prices.sessions, calibration)
    reference = pd.read_csv(PREVIOUS / "daily_nav.csv", parse_dates=["date"],
                            converters={arm: float for arm in ORIGINAL}).set_index("date")
    summaries, comparisons, daily = [], [], []
    for period in ("dev", "val"):
        start, end = course.PERIODS[period]
        assert pd.Timestamp(end) <= course.LAST
        decisions = weekly.loc[weekly.period == period]
        meeting = decisions.meetings.eq(1)
        targets = decisions.set_index("as_of")
        cfg = course.BacktestConfig(start=start, end=end, stops=False, use_exposure_engine=True)
        assert np.isclose(cfg.commission + cfg.slippage, 0.0006)
        curves, summary = {}, {}
        for arm in POLICIES:
            def exposure(prev_day):
                cutoff = pd.Timestamp(prices.last_session_on_or_before(prev_day))
                return SimpleNamespace(exposureMultiplier=float(targets.at[cutoff, f"{arm}_exposure"]))

            result = course.run_backtest(prices, scores, params, universe, cfg, exposure_fn=exposure)
            nav = result.equity
            archived = reference.loc[reference.period == period]
            assert nav.index.equals(archived.index)
            assert all(t["model_cutoff"] < t["date"] for t in result.weekly_targets)
            if arm in ORIGINAL:
                np.testing.assert_array_equal(nav, archived[arm])
            if arm == "neutral":
                orders = pd.read_csv(HERE.parent / "results" / period / "engine/trades.csv")
                fields = ["date", "symbol", "qty", "price", "notional", "reason"]
                actual = result.trades[fields].assign(date=result.trades.date.astype(str)).sort_values(fields)
                pd.testing.assert_frame_equal(actual.reset_index(drop=True),
                                              orders[fields].sort_values(fields).reset_index(drop=True))

            curves[arm] = nav
            total, mdd = course.exact_metrics(nav)
            trough = (nav / nav.cummax()).idxmin()
            returns = nav.pct_change().dropna()
            traded = result.trades.notional.abs().sum()
            shifts = (decisions[f"{arm}_exposure"] - decisions.neutral_exposure).loc[meeting]
            summary[arm] = dict(period=period, policy=arm, sessions=len(nav), meetings=int(meeting.sum()),
                                total_return_pct=total, max_drawdown_pct=mdd,
                                sharpe=returns.mean() * np.sqrt(252) / returns.std(),
                                max_drawdown_peak=nav.loc[:trough].idxmax(), max_drawdown_trough=trough,
                                trades=len(result.trades), turnover_per_year=traded / nav.mean() * 252 / len(nav),
                                mean_abs_target_shift_bp=shifts.abs().mean() * 10000)
        summaries.extend(summary.values())
        daily.append(pd.DataFrame(curves).assign(period=period).rename_axis("date").reset_index())
        for arm, anchor in CONTRASTS:
            primary, control = summary[arm], summary[anchor]
            change = (decisions[f"{arm}_exposure"] - decisions[f"{anchor}_exposure"]).loc[meeting]
            comparisons.append(dict(period=period, policy=arm, reference=anchor,
                                    return_diff_pp=primary["total_return_pct"] - control["total_return_pct"],
                                    max_drawdown_diff_pp=primary["max_drawdown_pct"] - control["max_drawdown_pct"],
                                    sharpe_diff=primary["sharpe"] - control["sharpe"],
                                    different_target_weeks=int(change.ne(0).sum()),
                                    mean_abs_target_difference_bp=change.abs().mean() * 10000))
    out.mkdir(exist_ok=True, parents=True)
    for name, frame in (("comparison", pd.DataFrame(summaries)), ("paired_differences", pd.DataFrame(comparisons)),
                        ("daily_nav", pd.concat(daily)), ("weekly_decisions", weekly.reset_index())):
        frame.to_csv(out / f"{name}.csv", index=False, date_format="%Y-%m-%d")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--calibration", type=Path, default=HERE / "calibration.json")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Run with PYTHONHASHSEED=0 for reproducible order tie sorting.")
    with TemporaryDirectory(prefix="gr5398-amplitude-") as temp:
        replay(args.calibration, args.out, Path(temp))
