# Does reducing the policy trade size improve validation results?

Keep the hawkish or dovish signal, its trading dates and the neutral timing engine from the preceding study. For each meeting, measure the policy rule’s target equity exposure minus the neutral engine’s target. Multiply that difference by a single development-period coefficient, then add it back to the same week’s neutral target. For example, if the raw rule calls for cutting exposure by 1 percentage point, the calibrated rule cuts it by 0.339 points. The five other timing inputs still set the underlying neutral target.

The 22 eligible development meetings had a combined absolute exposure difference from neutral of 124 basis points for full-text sentiment and 366 for the policy rule. The coefficient is 124 divided by 366, or 0.338798. The matched development mean is 5.64 basis points per meeting, including zero shifts. All development price outcomes and all validation observations are excluded from the fit. The subsequent replay uses the common course stock rankings, weekly fills at the open, whole shares, cash buffer and costs of 6 basis points per dollar traded. Previously studied validation dates are reused for this historical comparison. [Calibration protocol](CALIBRATION.md) · [Coefficient and development inputs digest](calibration.json)

## Validation outcomes

| Weekly timing policy | Mean absolute shift from neutral on meeting weeks | After-cost return | Maximum drawdown depth | Sharpe |
|---|---:|---:|---:|---:|
| Neutral input | 0.000 bp | 3.786% | 27.696% | 0.194 |
| Full-statement sentiment | 6.688 bp | 3.765% | 27.697% | 0.193 |
| Original policy rule | 85.375 bp | 3.298% | 27.981% | 0.181 |
| Scaled policy rule | 28.925 bp | 3.675% | 27.712% | 0.191 |

Shrinking the same nine cuts raised cumulative validation return by 0.377 percentage points and reduced maximum drawdown depth by 0.269 points. Relative to the full-text model, the return shortfall fell from 0.466 to 0.090 points, and excess drawdown fell from 0.284 to 0.014 points. This recovered 81% of the original return gap and 95% of the drawdown gap in this replay. Prices, share rounding, order thresholds and positions carried between weeks determine the net outcome. [Portfolio comparison](results/comparison.csv) · [Unrounded differences](results/paired_differences.csv) · [Daily stock equity](results/daily_nav.csv)

Only two of the 22 development meetings changed the policy rule’s target relative to neutral, both increases. The 16 validation meetings instead produced nine actual cuts and seven unchanged targets. The calibration therefore delivered a validation tilt 4.33 times as large as full-text sentiment’s. Four cuts preceded a decline in the tradable neutral equity basket. Five preceded a rise. The basket gained an average of 1.92% over these nine open-to-open windows. Reducing size helped; the event returns provide little support for the decision to cut risk. The remaining gap also includes differences in sizing and portfolio execution. [Direction check, coverage and limitations](DIRECTION.md) · [Each entry and exit](results/direction_events.csv) · [Weekly targets](results/weekly_decisions.csv)

## Offline reproduction

From the course Assignment2 directory, use the course data and Python environment. The first command fits the coefficient, the second runs the four stock portfolios, and the third measures basket direction at actionable meetings.

```sh
python extensions/fingpt/stance_amplitude/calibrate.py
PYTHONHASHSEED=0 python extensions/fingpt/stance_amplitude/backtest.py
python extensions/fingpt/stance_amplitude/direction.py
```
