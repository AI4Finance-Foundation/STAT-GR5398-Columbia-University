"""Score the sign of meeting-week exposure changes against the tradable neutral stock basket."""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
FINGPT = HERE.parent
PRICES = HERE.parents[2] / "source_code/data/prices/daily_adjusted.parquet"
SIGN_TOLERANCE = 1e-12


def reconstruct_neutral(period, prices):
    archive = FINGPT / "results" / period / "engine"
    fills = pd.read_csv(archive / "trades.csv", parse_dates=["date"])
    curve = pd.read_csv(archive / "equity.csv", index_col=0, parse_dates=True).equity
    assert fills.reason.eq("rebalance").all()
    share_changes = fills.pivot_table(index="date", columns="symbol", values="qty", aggfunc="sum", fill_value=0)
    holdings = share_changes.reindex(curve.index, fill_value=0).cumsum()
    assert (holdings >= 0).all().all()
    selected = prices.loc[prices.symbol.isin(holdings.columns)]
    opens = selected.pivot(index="date", columns="symbol", values="open").reindex_like(holdings)
    closes = selected.pivot(index="date", columns="symbol", values="close").ffill().reindex_like(holdings)
    official_prices = opens.stack().reindex(pd.MultiIndex.from_frame(fills[["date", "symbol"]]))
    assert official_prices.notna().all()
    notionals = fills.qty * official_prices.to_numpy()
    changes = (-notionals - notionals.abs() * 0.0006).groupby(fills.date).sum()
    cash = 100000 + changes.reindex(curve.index, fill_value=0).cumsum()
    assert (closes.notna() | holdings.eq(0)).all().all()
    reconstructed = cash + holdings.mul(closes).sum(axis=1)
    np.testing.assert_allclose(reconstructed, curve, atol=1e-6, rtol=0)
    return holdings, opens, fills


def direction_rows(period, weekly, prices):
    holdings, opens, fills = reconstruct_neutral(period, prices)
    dates = weekly.rebalance.reset_index(drop=True)
    assert dates.is_monotonic_increasing and dates.is_unique
    assert fills.date.isin(dates).all(), "An intraweek fill would change the opening basket."
    next_open = dict(zip(dates.iloc[:-1], dates.iloc[1:]))
    records = []
    for row in weekly.loc[weekly.meetings.gt(0)].itertuples(index=False):
        assert row.meetings == 1 and pd.Timestamp(row.meeting_dates) < row.as_of < row.rebalance
        entry = row.rebalance
        if entry not in next_open:
            raise ValueError(f"Missing same-period exit open for {row.meeting_dates}.")
        exit_date = next_open[entry]
        shares = holdings.loc[entry]
        held = shares[shares.gt(0) & opens.loc[entry].gt(0)]
        excluded = shares.index[shares.gt(0) & ~shares.index.isin(held.index)]
        entry_prices, exit_prices = opens.loc[entry, held.index], opens.loc[exit_date, held.index]
        if len(held) == 0 or not exit_prices.gt(0).all():
            raise ValueError(f"Missing traded-stock opening value for {row.meeting_dates}.")
        entry_value, exit_value = float(held @ entry_prices), float(held @ exit_prices)
        stock_return = exit_value / entry_value - 1.0
        shifts = {arm: getattr(row, arm + "_exposure") - row.neutral_exposure for arm in ("body", "stance", "scaled")}
        direction = int(np.sign(shifts["stance"])) if abs(shifts["stance"]) > SIGN_TOLERANCE else 0
        assert (abs(shifts["scaled"]) > SIGN_TOLERANCE) == bool(direction)
        if direction:
            assert np.sign(shifts["scaled"]) == direction
        signed = direction * stock_return
        outcome = "abstain"
        if direction:
            outcome = "flat_return" if abs(signed) <= SIGN_TOLERANCE else ("right" if signed > 0 else "wrong")
        omission = ""
        if not direction:
            omission = "neutral or offsetting policy signal" if row.stance_score == 0.5 else "no target change after scaling/cap"
        records.append(dict(period=period, meeting_date=row.meeting_dates, entry_open=entry, exit_open=exit_date,
                            trading_sessions=holdings.index.get_loc(exit_date) - holdings.index.get_loc(entry),
                            tradable_held_names=len(held), excluded_at_entry="|".join(excluded),
                            entry_stock_value=entry_value, exit_stock_value=exit_value,
                            neutral_basket_return_pct=stock_return * 100, direction=direction,
                            **{arm + "_shift_bp": delta * 10000 for arm, delta in shifts.items()},
                            outcome=outcome, abstention_reason=omission,
                            signed_basket_return_pct=signed * 100 if direction else np.nan,
                            **{arm + "_gross_proxy_bp": delta * stock_return * 10000 for arm, delta in shifts.items()}))
    return records


def summarize(events):
    rows = []
    for period, group in events.groupby("period", sort=False):
        active = group.loc[group.direction.ne(0)]
        rows.append(dict(period=period, eligible_meetings=len(group), actionable_meetings=len(active),
                         right=int(active.outcome.eq("right").sum()), wrong=int(active.outcome.eq("wrong").sum()),
                         flat_return=int(active.outcome.eq("flat_return").sum()), abstentions=len(group) - len(active),
                         reductions=int(active.direction.lt(0).sum()), increases=int(active.direction.gt(0).sum()),
                         mean_signed_basket_return_pct=active.signed_basket_return_pct.mean(),
                         min_horizon_sessions=int(group.trading_sessions.min()),
                         max_horizon_sessions=int(group.trading_sessions.max()),
                         **{arm + "_sum_gross_proxy_bp": group[arm + "_gross_proxy_bp"].sum()
                            for arm in ("body", "stance", "scaled")}))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--results", type=Path, default=HERE / "results",
                     help="Directory of the portfolio replay, including weekly_decisions.csv.")
    args = cli.parse_args()
    schedule = pd.read_csv(args.results / "weekly_decisions.csv", parse_dates=["rebalance", "as_of"])
    prices = pd.read_parquet(PRICES, columns=["date", "symbol", "open", "close"],
                            filters=[("date", ">=", pd.Timestamp("2017-01-03")), ("date", "<=", pd.Timestamp("2023-12-31"))])
    events = pd.DataFrame([row for period in ("dev", "val")
                           for row in direction_rows(period, schedule.loc[schedule.period.eq(period)], prices)])
    assert events.meeting_date.is_unique and events.iloc[0].meeting_date >= "2019-03-01"
    events.to_csv(args.results / "direction_events.csv", index=False, date_format="%Y-%m-%d")
    summarize(events).to_csv(args.results / "direction_summary.csv", index=False)
