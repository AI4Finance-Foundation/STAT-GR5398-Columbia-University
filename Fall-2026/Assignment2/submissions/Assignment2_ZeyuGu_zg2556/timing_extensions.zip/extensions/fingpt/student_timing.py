"""Timing extension. Keep the course engine and replace only its 12% news input."""
from datetime import timedelta

import pandas as pd

from timing.engine import exposure_from_history


def exposure(as_of, data) -> float:
    day = pd.Timestamp(as_of)
    rows = data.extra('news_sentiment')
    # Archive dates identify publication days, with no reliable clock time. The exclusive
    # upper bound gives every item a full overnight availability lag before a decision.
    window = rows.loc[(rows.date >= day - timedelta(days=7)) & (rows.date < day), 'value']
    # Non-publication days are neutral. Missing source dates also contribute neutral mass.
    news = float(0.5 + (window - 0.5).sum() / 7)
    result = exposure_from_history(data.market_frame(), data.macro_dict(), as_of, news_sentiment=news)
    return float(result.exposureMultiplier) if result is not None else 1.0
