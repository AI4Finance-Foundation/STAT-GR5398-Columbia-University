# Do FOMC statement bodies improve weekly stock timing?

The primary comparison changes what the classifier reads at each scheduled meeting. The title arm reads the official release headline. The body arm reads the complete official statement, including the vote. Both arms use the same meetings, release times, frozen GPT-2 answer adapter and seven-calendar-day lookback. A third arm sends the neutral value 0.5 to the same timing engine. No branch receives minutes, press conferences or news from other dates.

## Comparison design

- **Population.** Use published scheduled FOMC decision statements from 2017 through 2023. The portfolio can use an inference only from March 1, 2019, the first eligible date under the original GPT-2 vintage rule. Both text arms receive 0.5 before that date and in weeks with no eligible release.
- **Signal.** Score text as the probability of a positive label plus half the probability of a neutral label using the previously trained financial-news classifier. Average the eligible meeting scores in the window. Feed this value to the existing 12% news term. A positive label describes the model's reading of the text. The model was trained on sentence sentiment and has no policy-stance or future-return labels.
- **Execution.** For each weekly rebalance, calculate exposure using the prior session's information and execute stock orders at the next weekly open. Use the existing timing study's course stock scores, stock allocation, price history, cash buffer and 6 bp cost per dollar traded in each arm. The six-month retrained selector remains a separate experiment.
- **Outcomes.** Compare cumulative after-cost stock return and the worst daily peak-to-trough decline within each period. Calculate both from closing portfolio equity. Report Sharpe, target exposures and the comparable SPY timing replay as supporting evidence. Use the same inputs and parameters throughout.
- **Interpretation.** The 2017–2021 development and 2022–2023 validation markets had already been examined when this follow-up was proposed. This is a historical paired comparison. The formal valuation holdout begins in 2024 and falls outside this study.

## What changed

The body arm earned 0.537 percentage points more than the headline arm in development, with a 0.013-point smaller maximum drawdown. On the 2022–2023 validation portfolio, the body arm earned 0.010 points less and experienced a 0.005-point deeper maximum drawdown. All three validation portfolios reached their worst drawdown on December 28, 2022, from their January 3 peak.

| Period | Eligible meetings | News input | Stock return | Maximum drawdown | Sharpe |
|---|---:|---|---:|---:|---:|
| 2017–2021 | 22 | Neutral | 127.75% | −20.90% | 0.934 |
| 2017–2021 | 22 | Headline | 127.43% | −20.89% | 0.933 |
| 2017–2021 | 22 | Full statement | 127.97% | −20.88% | 0.935 |
| 2022–2023 | 16 | Neutral | 3.79% | −27.70% | 0.194 |
| 2022–2023 | 16 | Headline | 3.77% | −27.69% | 0.193 |
| 2022–2023 | 16 | Full statement | 3.76% | −27.70% | 0.193 |

All 38 eligible releases had the same headline and title score (0.44046). The headline arm therefore applies a fixed score on scheduled meeting weeks. Body scores ranged from 0.47304 to 0.54448. For the May 1, 2019 hold, the full text scored 0.50226. For the July 31 cut it scored 0.50139. These two scores sit close to the neutral value of 0.5. The stock experiment found a development gain but no validation gain from trading the richer text with this model.

The two text arms set different exposure targets at 12 of 22 eligible development meetings and 13 of 16 validation meetings. Across the 16 validation meetings, their absolute target difference averaged 0.35 percentage points. The secondary SPY simulation showed small improvements in validation relative to titles (+0.053 points of cumulative return and a 0.011-point shallower drawdown). SPY uses fractional exposure to one index. The stock portfolio trades whole shares across multiple names and pays per dollar traded. [Portfolio metrics](results/comparison.csv) · [Unrounded paired differences](results/body_vs_title.csv) · [Weekly target exposures](results/weekly_decisions.csv) · [Daily equity](results/daily_nav.csv)

## Replay

From the course Assignment2 directory, use the course Python environment with its issued data bundle to verify the offline corpus and replay stored scores.

```sh
python extensions/fingpt/statement_comparison/fetch_statements.py
PYTHONHASHSEED=0 python extensions/fingpt/statement_comparison/backtest.py --out /tmp/gr5398-statement-replay
```

To recompute scores, use the separate NLP environment in the parent FinGPT README. Populate the pinned model cache with `python extensions/fingpt/fetch_inputs.py ./download_cache`, then run the following command. The classifier splits each complete text into successive blocks of up to 58 content tokens and averages the three class probabilities with weights proportional to block length. An identical short title stays in a single block. The seven overlapping original title scores agreed within 0.00000002.

```sh
python extensions/fingpt/statement_comparison/score_statements.py ./download_cache --out /tmp/gr5398-statement-scores
```

The stock replay accepts `--scores /tmp/gr5398-statement-scores/meeting_scores.csv` to run directly from regenerated scores. Each eligible release is used once, respects its Eastern publication time and precedes the previous-session cutoff. The replay checks the full neutral stock equity paths and the neutral SPY metrics against the earlier experiment. [Source manifest and fetch instructions](SOURCES.md) · [Complete statement snapshot](statements.jsonl) · [Meeting scores and token counts](meeting_scores.csv) · [Scoring hashes](scoring_audit.json)
