"""Apply the original frozen financial sentiment model to paired FOMC titles and bodies."""
import argparse
import csv
import importlib.metadata
import json
import sys
from datetime import date, datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import torch
from safetensors.torch import load_file

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from train_sentiment import (AnswerAdapter, LABELS, PROMPT_END, PROMPT_PREFIX, SEED,
                             START_SCORING, load_gpt, sha)

MAX_PROMPT_TOKENS = 72  # The limit used to fit the original adapter.


def read_snapshot(path):
    with path.open(encoding="utf-8") as handle:
        source = [json.loads(line) for line in handle if line.strip()]
    days = [date.fromisoformat(row["date"]) for row in source]
    if not days or days != sorted(set(days)) or days[-1] > date(2023, 12, 31):
        raise ValueError("Expected distinct chronological statement dates ending by 2023.")
    eligible = []
    for day, row in zip(days, source):
        eastern = datetime.fromisoformat(row["published_at_et"])
        utc = datetime.fromisoformat(row["published_at_utc"].replace("Z", "+00:00"))
        if (eastern.tzinfo is None or utc.tzinfo is None or utc.utcoffset() != timezone.utc.utcoffset(utc)
                or eastern != utc or eastern.date() != day
                or eastern.utcoffset() != utc.astimezone(ZoneInfo("America/New_York")).utcoffset()):
            raise ValueError(f"Conflicting publication timestamps for {day}.")
        if day >= START_SCORING.date():
            eligible.append(row)
    if not eligible:
        raise ValueError("No statements issued during the model's eligible period.")
    return eligible


def encode_documents(rows, tokenizer, width):
    documents, unique_chunks = {}, {}
    for i, row in enumerate(rows):
        for arm, field in (("title", "headline"), ("body", "body")):
            # Normalize layout whitespace identically and partition the *single* encoding.
            # Keeping the token IDs intact avoids added or dropped tokens at chunk boundaries.
            text = " ".join(row[field].split())
            tokens = tokenizer.encode(text, add_special_tokens=False)
            if not tokens:
                raise ValueError(f"Empty {arm} for {row['date']}")
            pieces = [tuple(tokens[offset:offset + width]) for offset in range(0, len(tokens), width)]
            assert [token for piece in pieces for token in piece] == tokens
            documents[i, arm] = pieces
            unique_chunks.update(dict.fromkeys(pieces))
    return documents, list(unique_chunks)


@torch.inference_mode()
def score_chunks(chunks, prefix, ending, eos_id, model, adapter):
    by_chunk = {}
    for start in range(0, len(chunks), 16):
        batch = chunks[start:start + 16]
        prompts = [prefix + list(piece) + ending for piece in batch]
        lengths = torch.tensor([len(prompt) for prompt in prompts])
        size = int(lengths.max())
        assert size <= MAX_PROMPT_TOKENS
        ids = torch.tensor([row + [eos_id] * (size - len(row)) for row in prompts])
        mask = torch.arange(size)[None, :] < lengths[:, None]
        states = model(input_ids=ids, attention_mask=mask.long(), use_cache=False).last_hidden_state
        logits = adapter(states[torch.arange(len(batch)), lengths - 1])
        probabilities = torch.softmax(logits, dim=1).double().numpy()
        assert np.isfinite(probabilities).all() and np.allclose(probabilities.sum(axis=1), 1.0)
        by_chunk.update(zip(batch, probabilities))
    return by_chunk


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cache", type=Path, help="Directory populated by ../fetch_inputs.py.")
    parser.add_argument("--statements", type=Path, default=HERE / "statements.jsonl")
    parser.add_argument("--out", type=Path, default=HERE, help="Directory for scores and scoring audit.")
    args = parser.parse_args()
    source_digest = sha(args.statements)
    rows = read_snapshot(args.statements)
    previous = HERE.parent / "results"
    training = json.loads((previous / "training.json").read_text())
    weights = previous / "answer_adapter.safetensors"
    if sha(weights) != training["adapter_sha256"]:
        raise ValueError("The saved adapter differs from the original fine-tuning record.")
    torch.set_num_threads(4)
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(True)
    model, tokenizer, answer_ids = load_gpt(args.cache)
    assert training["class_token_ids"] == answer_ids and training["classes"] == LABELS
    adapter = AnswerAdapter(model.wte.weight.detach()[answer_ids]).eval().requires_grad_(False)
    saved = load_file(str(weights))
    adapter.down.weight.copy_(saved["down"])
    adapter.up.weight.copy_(saved["up"])

    prefix = tokenizer.encode(PROMPT_PREFIX, add_special_tokens=False)
    ending = tokenizer.encode(PROMPT_END, add_special_tokens=False)
    width = MAX_PROMPT_TOKENS - len(prefix) - len(ending)
    documents, chunks = encode_documents(rows, tokenizer, width)
    by_chunk = score_chunks(chunks, prefix, ending, tokenizer.eos_token_id, model, adapter)
    output = []
    for i, row in enumerate(rows):
        entry = {k: row[k] for k in ("date", "published_at_et", "published_at_utc", "source_url")}
        entry["neutral_score"] = 0.5
        for arm in ("title", "body"):
            pieces = documents[i, arm]
            counts = [len(piece) for piece in pieces]
            p = np.average([by_chunk[piece] for piece in pieces], axis=0, weights=counts)
            entry.update({f"{arm}_p_{label}": prob for label, prob in zip(LABELS, p)})
            entry[f"{arm}_score"] = p[2] + 0.5 * p[1]
            entry[f"{arm}_tokens"] = sum(counts)
            entry[f"{arm}_chunks"] = len(pieces)
        output.append(entry)

    # Independent cross-check against the original 810-headline experiment wherever
    # the source URL and the text both match. Batch padding may cause small float32 drift.
    with (previous / "headline_scores.csv").open(encoding="utf-8") as handle:
        published = {(r["url"], r["headline"]): float(r["value"]) for r in csv.DictReader(handle)}
    deltas = [abs(out["title_score"] - published[key]) for row, out in zip(rows, output)
              if (key := (row["source_url"], row["headline"])) in published]
    if not deltas or max(deltas) > 0.0001:
        raise ValueError("Replayed title scores differ from scores on identical archived releases.")
    if sha(args.statements) != source_digest:
        raise RuntimeError("The statement snapshot changed during inference. Retry with the finalized input.")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "meeting_scores.csv"
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(output)
    summary = {
        "eligible_from": training["first_eligible_release"], "first_meeting": rows[0]["date"],
        "last_meeting": rows[-1]["date"], "eligible_meetings": len(rows),
        "classes": LABELS, "score": "P(positive) + 0.5 * P(neutral)",
        "body_input": "Official body alone, including voting paragraph; title arm is official title alone.",
        "chunking": "Normalize whitespace; partition token IDs into non-overlapping contiguous blocks. "
                    "Weight each block's three answer probabilities by its count of content tokens.",
        "max_prompt_tokens": MAX_PROMPT_TOKENS, "max_content_tokens_per_chunk": width,
        "archived_overlapping_titles_checked": len(deltas), "max_abs_archived_title_score_delta": max(deltas),
        "input_files_sha256": {name: sha(args.cache / name) for name in
                               ("pytorch_model.bin", "vocab.json", "merges.txt", "config.json")},
        "adapter_sha256": sha(weights), "statements_sha256": source_digest, "scores_sha256": sha(destination),
        "software": {package: importlib.metadata.version(package) for package in training["software"]}
    }
    (args.out / "scoring_audit.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"Scored {len(output)} paired meetings using {len(chunks)} distinct chunks.")


if __name__ == "__main__":
    main()
