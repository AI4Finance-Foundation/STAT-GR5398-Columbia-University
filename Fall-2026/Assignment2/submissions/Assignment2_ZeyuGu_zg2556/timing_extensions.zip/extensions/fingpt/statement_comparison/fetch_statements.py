"""Rebuild or verify the 2017–23 paired FOMC statement corpus."""

import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import urljoin, urlsplit
from zoneinfo import ZoneInfo


HERE = Path(__file__).resolve().parent
BASE = "https://www.federalreserve.gov"
CALENDAR = BASE + "/monetarypolicy/fomccalendars.htm"
EXPECTED = {year: (7 if year == 2020 else 8) for year in range(2017, 2024)}
EASTERN = ZoneInfo("America/New_York")
DECISION_LINK = r'(/newsevents/pressreleases/monetary(\d{8})[a-z]\.htm)'


class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, content):
        self.parts.append(content)

    def handle_starttag(self, tag, attrs):
        if tag == "br":
            self.parts.append(" ")


def clean(fragment):
    parser = VisibleText()
    parser.feed(fragment)
    return " ".join("".join(parser.parts).split())


def match(pattern, html):
    found = re.search(pattern, html, re.I | re.S)
    if not found:
        raise ValueError(f"Missing page element: {pattern}")
    return found.group(1)


def page(url, cache):
    if urlsplit(url).netloc != "www.federalreserve.gov":
        raise ValueError(f"Unexpected site: {url}")
    local = cache / Path(urlsplit(url).path).name
    if not local.is_file():
        fetched = subprocess.run(
            ["curl", "--fail", "--silent", "--show-error", "--location",
             "--max-time", "35", "--retry", "2", url],
            check=True, capture_output=True,
        ).stdout
        if b"</html>" not in fetched.lower():
            raise ValueError(f"Incomplete HTML from {url}")
        local.write_bytes(fetched)
    return local.read_text(encoding="utf-8-sig")


def historical_calendar(html):
    rows = []
    for block in re.split(r'<h5\b[^>]*>', html, flags=re.I)[1:]:
        heading, _, details = block.partition("</h5>")
        label = clean(heading)
        if " Meeting - " not in label or "(" in label:
            continue
        path = match(r'href="' + DECISION_LINK + r'">\s*Statement\s*</a>', details)
        rows.append((label, path))
    return rows


def current_calendar(html, year):
    target = re.search(rf">{year} FOMC Meetings</a></h4>(.*?)(?:\d{{4}} FOMC Meetings</a></h4>|$)", html, re.S)
    if not target:
        return []
    rows = []
    for block in re.split(r'<div class="[^"]*\brow fomc-meeting"[^>]*>', target[1])[1:]:
        month = clean(match(r'class="[^"]*\bfomc-meeting__month[^"]*">(.*?)</div>', block))
        days = clean(match(r'class="fomc-meeting__date[^"]*">(.*?)</div>', block))
        if not re.fullmatch(r"\d+-\d+\*?", days):
            continue
        path = match(r'<strong>Statement:</strong>.*?href="' + DECISION_LINK + r'">\s*HTML\s*</a>', block)
        rows.append((f"{month} {days.rstrip('*')} Meeting - {year}", path))
    return rows


def parse_release(html, url, calendar, label):
    article = match(r'<div id="article">(.*?)<div id="lastUpdate"', html)
    day = datetime.strptime(clean(match(r'<p class="article__time">(.*?)</p>', article)), "%B %d, %Y")
    headline = clean(match(r'<h3 class="title">(.*?)</h3>', article))
    time_text = clean(match(r'<p class="releaseTime">([^<]+)', article))
    tokens = re.fullmatch(r'For release at (\d{1,2}:\d{2}) ([ap])\.m\. (EST|EDT)', time_text, re.I)
    if not tokens:
        raise ValueError(f"Unknown release time: {time_text}")
    hhmm = datetime.strptime(tokens[1] + tokens[2].upper() + "M", "%I:%M%p").time()
    stamp = datetime.combine(day.date(), hhmm, EASTERN)
    if stamp.tzname() != tokens[3].upper() or stamp.strftime("%Y%m%d") not in url:
        raise ValueError(f"Calendar, time-zone label or date disagrees for {url}")
    section = match(r'<div class="col-xs-12 col-sm-8 col-md-8">(.*?)</div>', article)
    paras = [clean(p) for p in re.findall(r'<p\b[^>]*>(.*?)</p>', section, re.I | re.S)]
    paragraphs = []
    for para in paras:
        if para.startswith(("Implementation Note", "For media inquiries")):
            break
        if para:
            paragraphs.append(para)
    body = "\n\n".join(paragraphs)
    if "federal funds rate" not in body or "Voting for" not in body or len(paragraphs) < 3:
        raise ValueError(f"Incomplete statement: {url}")
    if not paragraphs[-1].startswith(("Voting for", "Voting against")):
        raise ValueError(f"Check end of statement: {url}")
    return dict(date=day.date().isoformat(), published_at_et=stamp.isoformat(),
                published_at_utc=stamp.astimezone(timezone.utc).isoformat(),
                release_label=time_text, headline=headline, body=body, source_url=url,
                calendar_url=calendar, meeting_label=label, body_sha256=sha256(body.encode()).hexdigest())


def validate(records):
    if Counter(int(r["date"][:4]) for r in records) != EXPECTED:
        raise ValueError("Scheduled meeting coverage differs from calendar counts")
    dates = [r["date"] for r in records]
    if dates != sorted(set(dates)) or len({r["source_url"] for r in records}) != len(dates):
        raise ValueError("Duplicate or unordered statements")
    for row in records:
        stamp = datetime.fromisoformat(row["published_at_et"])
        if (stamp.date().isoformat() != row["date"] or stamp.strftime("%H:%M") != "14:00"
                or stamp != datetime.fromisoformat(row["published_at_utc"])
                or sha256(row["body"].encode()).hexdigest() != row["body_sha256"]
                or "FOMC statement" not in row["headline"]):
            raise ValueError(f"Unverified statement: {row['date']}")


def fetch(cache):
    cache.mkdir(parents=True, exist_ok=True)
    records = []
    for year in EXPECTED:
        calendar = CALENDAR
        meetings = current_calendar(page(calendar, cache), year) if year >= 2021 else []
        if not meetings:
            calendar = BASE + f"/monetarypolicy/fomchistorical{year}.htm"
            meetings = historical_calendar(page(calendar, cache))
        for label, path in meetings:
            url = urljoin(BASE, path)
            records.append(parse_release(page(url, cache), url, calendar, label))
    return records


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--fetch", type=Path, metavar="HTML_CACHE",
                     help="Download official HTML into this cache and rebuild the JSONL")
    cli.add_argument("--output", type=Path, default=HERE / "statements.jsonl")
    args = cli.parse_args()
    if args.fetch:
        corpus = fetch(args.fetch)
        validate(corpus)
        args.output.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in corpus), encoding="utf-8")
    else:
        corpus = [json.loads(line) for line in args.output.read_text(encoding="utf-8").splitlines()]
        validate(corpus)
    print(f"{len(corpus)} scheduled statements verified, {corpus[0]['date']} to {corpus[-1]['date']}.")
