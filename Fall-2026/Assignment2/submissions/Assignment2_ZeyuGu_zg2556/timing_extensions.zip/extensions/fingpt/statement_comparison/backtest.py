"""Matched stock and SPY replays using official, scheduled FOMC statements."""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / "source_code"
DATA = SOURCE / "data"
ARCHIVE = HERE.parent / "results"
sys.path.insert(0, str(SOURCE))

from evaluate_timing import simulate
from portfolio.backtester import BacktestConfig, run_backtest
from selection import MonthlyScores, Parameters
from shared.metrics import performance
from shared.periods import PERIODS
from shared.prices import PriceStore
from shared.universe import TradeableUniverse
from timing.engine import WEIGHT_NEWS_SENTIMENT, exposure_from_history

PERIOD_NAMES = ("dev", "val")
ARMS = ("neutral", "title", "body")
LAST = pd.Timestamp(PERIODS["val"][1])


def historical_parquet(path, date_key="date"):
    return pd.read_parquet(DATA / path, filters=[(date_key, "<=", LAST)])


def portfolio_inputs(temp):
    # PriceStore and MonthlyScores take paths; hand them bounded snapshots.
    prices_file = temp / "prices.parquet"
    historical_parquet("prices/daily_adjusted.parquet").to_parquet(prices_file, index=False)
    scores_file = temp / "scores.parquet"
    historical_parquet("selection/monthly_scores.parquet", "month").to_parquet(scores_file, index=False)
    members_file = temp / "membership.db"
    with sqlite3.connect((DATA / "fundamentals.db").as_uri() + "?mode=ro", uri=True) as src, sqlite3.connect(members_file) as dst:
        for table, key in (("universe_membership", "snapshot_date"), ("symbol_changes", "change_date")):
            rows = pd.read_sql(f"SELECT * FROM {table} WHERE {key} <= ?", src, params=[str(LAST.date())])
            rows.to_sql(table, dst, index=False)
    config = json.loads((SOURCE / "selection/configs/growth.json").read_text())
    universe = TradeableUniverse.from_db_path(str(members_file), config["model"]["universes"])
    return PriceStore(prices_file), MonthlyScores(scores_file), Parameters(**config["parameters"]), universe


def read_scores(path, statements_path):
    scores = pd.read_csv(path, parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    assert len(scores) and scores.date.is_unique and scores.source_url.is_unique
    assert scores.date.between(pd.Timestamp("2019-03-01"), LAST).all()
    scores["release_utc"] = pd.to_datetime(scores.published_at_utc, utc=True)
    assert scores.release_utc.equals(pd.to_datetime(scores.published_at_et, utc=True))
    dates_et = scores.release_utc.dt.tz_convert("America/New_York").dt.tz_localize(None).dt.normalize()
    assert dates_et.equals(scores.date)
    assert scores.neutral_score.eq(0.5).all()
    assert all(scores[f"{arm}_score"].between(0, 1).all() for arm in ARMS)
    records = pd.DataFrame([json.loads(line) for line in statements_path.read_text().splitlines()])
    records["date"] = pd.to_datetime(records.date)
    eligible = records.loc[records.date.between(pd.Timestamp("2019-03-01"), LAST)].sort_values("date")
    assert list(zip(scores.date, scores.source_url)) == list(zip(eligible.date, eligible.source_url))
    assert list(scores.release_utc) == list(pd.to_datetime(eligible.published_at_utc, utc=True))
    return scores


def weekly_decisions(sessions, meetings, market, macro, period):
    start, end = PERIODS[period]
    dates = sessions[(sessions >= pd.Timestamp(start)) & (sessions <= pd.Timestamp(end))]
    records, applied = [], []
    for rebalance in dates.to_series().groupby(dates.to_period("W-SUN")).first():
        cutoff = sessions[sessions.get_loc(rebalance) - 1]
        # Give even the close on a release date an overnight buffer, as in the earlier pilot.
        # The exclusive timestamp is midnight at the start of the previous session in New York.
        cutoff_utc = cutoff.tz_localize("America/New_York").tz_convert("UTC")
        lower_utc = (cutoff - pd.Timedelta(days=7)).tz_localize("America/New_York").tz_convert("UTC")
        events = meetings.loc[meetings.release_utc.ge(lower_utc) & meetings.release_utc.lt(cutoff_utc)]
        applied.extend(events.date)
        row = dict(period=period, rebalance=rebalance, as_of=cutoff, meetings=len(events),
                   meeting_dates="|".join(events.date.dt.strftime("%Y-%m-%d")),
                   published_at_utc="|".join(events.published_at_utc), source_urls="|".join(events.source_url))
        cached = {}
        for arm in ARMS:
            score = float(events[f"{arm}_score"].mean()) if len(events) else 0.5
            if score not in cached:
                cached[score] = exposure_from_history(market, macro, cutoff, news_sentiment=score)
            result = cached[score]
            assert result is not None and 0 <= result.exposureMultiplier <= 1
            neutral = cached[0.5]
            for key in neutral.components:
                if key != "news_sentiment_score":
                    assert result.components[key] == neutral.components[key]
            assert abs(result.risk_score - neutral.risk_score - WEIGHT_NEWS_SENTIMENT * (score - 0.5)) <= 0.000101
            row[f"{arm}_score"] = score
            row[f"{arm}_exposure"] = result.exposureMultiplier
        records.append(row)
    # The observed calendar maps each eligible scheduled release to exactly one weekly decision.
    expected = meetings.loc[meetings.date.between(pd.Timestamp(start), pd.Timestamp(end)), "date"]
    assert list(expected) == applied, (period, expected.tolist(), applied)
    return dates, pd.DataFrame(records).set_index("rebalance")


def exact_metrics(equity):
    return (100 * (equity.iloc[-1] / equity.iloc[0] - 1),
            100 * (equity / equity.cummax() - 1).min())


def replay(out, temp, score_file, statements_file):
    assert WEIGHT_NEWS_SENTIMENT == 0.12
    meetings = read_scores(score_file, statements_file)
    prices, stock_scores, params, universe = portfolio_inputs(temp)
    market = historical_parquet("prices/market_series.parquet")
    macro = {}
    for key in ("T10Y2Y", "BAMLH0A0HYM2"):
        macro[key] = historical_parquet(f"macro/{key}.parquet").set_index("date").value.sort_index()
    summary, comparisons, nav_tables, schedules = [], [], [], []
    for period in PERIOD_NAMES:
        dates, weekly = weekly_decisions(prices.sessions, meetings, market, macro, period)
        start, end = PERIODS[period]
        cfg = BacktestConfig(start=start, end=end, stops=False, use_exposure_engine=True)
        per_asset = {"stocks": {}, "SPY": {}}
        orders = {}
        for arm in ARMS:
            weekly_exposure = weekly[f"{arm}_exposure"]
            lookup = pd.Series(weekly_exposure.to_numpy(), index=weekly.as_of)

            def exposure(prev_day):
                close = pd.Timestamp(prices.last_session_on_or_before(prev_day))
                return SimpleNamespace(exposureMultiplier=float(lookup.at[close]))

            stocks = run_backtest(prices, stock_scores, params, universe, cfg, exposure_fn=exposure)
            assert pd.DatetimeIndex(stocks.equity.index).equals(dates)
            assert all(pd.Timestamp(t["model_cutoff"]) < pd.Timestamp(t["date"]) for t in stocks.weekly_targets)
            orders[arm] = stocks.trades.groupby(["date", "symbol"]).qty.sum()
            per_asset["stocks"][arm] = stocks.equity
            held = weekly_exposure.reindex(dates, method="ffill")
            per_asset["SPY"][arm] = simulate(held, prices.close["SPY"])
            traded = stocks.trades.notional.abs().sum()
            for asset, paths in per_asset.items():
                equity = paths[arm]
                row = dict(period=period, asset=asset, policy=arm, days=len(equity), **performance(equity))
                drawdown = equity / equity.cummax() - 1
                trough = drawdown.idxmin()
                row.update(max_drawdown_peak=equity.loc[:trough].idxmax(), max_drawdown_trough=trough)
                if asset == "stocks":
                    row.update(trades=len(stocks.trades), turnover_per_year=traded / equity.mean() * 252 / len(equity),
                               estimated_commission_slippage_usd=traded * (cfg.commission + cfg.slippage))
                summary.append(row)

        archived_stock = pd.read_csv(ARCHIVE / period / "engine/equity.csv", index_col=0, parse_dates=True).equity
        assert pd.DatetimeIndex(archived_stock.index).equals(dates)
        np.testing.assert_allclose(per_asset["stocks"]["neutral"], archived_stock, rtol=1e-12, atol=1e-7)
        archived_spy = pd.read_csv(ARCHIVE / period / f"timing_eval_{period}.csv").set_index("timing").loc["engine"]
        for metric, value in performance(per_asset["SPY"]["neutral"]).items():
            np.testing.assert_allclose(value, archived_spy[metric], rtol=0, atol=1e-10)

        event = weekly.meetings.gt(0)
        ledger = pd.concat(orders, axis=1).fillna(0)
        different = ledger.body.ne(ledger.title)
        by_date = different.groupby(level="date").sum()
        by_date.index = pd.DatetimeIndex(by_date.index)
        weekly["different_stock_orders_body_vs_title"] = by_date.reindex(weekly.index, fill_value=0)
        delta_bp = 10000 * (weekly.body_exposure - weekly.title_exposure)
        weekly["body_minus_title_exposure_bp"] = delta_bp
        assert delta_bp.loc[~event].eq(0).all()
        wide = {}
        for asset, paths in per_asset.items():
            title_return, title_dd = exact_metrics(paths["title"])
            body_return, body_dd = exact_metrics(paths["body"])
            relative = np.log(paths["body"] / paths["title"])
            weekly[f"{asset}_body_vs_title_log_wealth_change_bp"] = (
                relative.diff().fillna(0).groupby(dates.to_period("W-SUN")).sum().to_numpy() * 10000)
            comparisons.append(dict(period=period, asset=asset,
                                    eligible_meetings=int(weekly.meetings.sum()), meeting_weeks=int(event.sum()),
                                    decision_weeks=len(weekly), different_exposure_weeks=int(delta_bp.ne(0).sum()),
                                    mean_abs_exposure_difference_bp_meeting_weeks=delta_bp[event].abs().mean(),
                                    max_abs_exposure_difference_bp=delta_bp.abs().max(),
                                    different_stock_order_dates=int(by_date.gt(0).sum()) if asset == "stocks" else None,
                                    different_stock_order_dates_meeting_weeks=int((weekly.different_stock_orders_body_vs_title.gt(0) & event).sum()) if asset == "stocks" else None,
                                    return_body_minus_title_pp=body_return-title_return,
                                    max_drawdown_body_minus_title_pp=body_dd-title_dd,
                                    terminal_relative_log_wealth_bp=10000 * (relative.iloc[-1] - relative.iloc[0])))
            for arm in ARMS:
                wide[f"{asset}_{arm}"] = paths[arm]
        nav_tables.append(pd.DataFrame(wide).assign(period=period).rename_axis("date").reset_index())
        schedules.append(weekly.reset_index())
    out.mkdir(exist_ok=True, parents=True)
    for table, name in ((pd.DataFrame(summary), "comparison"), (pd.DataFrame(comparisons), "body_vs_title"),
                        (pd.concat(nav_tables), "daily_nav"), (pd.concat(schedules), "weekly_decisions")):
        table.to_csv(out / f"{name}.csv", index=False, date_format="%Y-%m-%d")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scores", type=Path, default=HERE / "meeting_scores.csv")
    parser.add_argument("--statements", type=Path, default=HERE / "statements.jsonl")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "0":
        parser.error("Run with PYTHONHASHSEED=0 for deterministic course order ties.")
    with TemporaryDirectory(prefix="gr5398-fomc-") as tmp:
        replay(args.out, Path(tmp), args.scores, args.statements)
