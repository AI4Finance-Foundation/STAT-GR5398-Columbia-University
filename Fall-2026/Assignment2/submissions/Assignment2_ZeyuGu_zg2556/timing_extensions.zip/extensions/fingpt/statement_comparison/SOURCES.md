# FOMC statement corpus

`statements.jsonl` is the offline source snapshot. Each line records the official headline, the full decision text including any dissent, the calendar and press-release URLs, meeting label, exact local and UTC release times, and a SHA-256 digest of the normalized body. The file contains 55 distinct bodies, from 290 to 614 whitespace-delimited words, and one common headline. Its SHA-256 is `c1af5a4c4984c48748e64f85bd310e2801c04f58afafcf3a1bbe32d3596bb650`.

| Year | Scheduled statements | Calendar |
| --- | ---: | --- |
| 2017 | 8 | [Federal Reserve historical calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2017.htm) |
| 2018 | 8 | [Federal Reserve historical calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2018.htm) |
| 2019 | 8 | [Federal Reserve historical calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2019.htm) |
| 2020 | 7 | [Federal Reserve historical calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2020.htm) |
| 2021 | 8 | [Federal Reserve meeting calendar](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm) |
| 2022 | 8 | [Federal Reserve meeting calendar](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm) |
| 2023 | 8 | [Federal Reserve meeting calendar](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm) |

The March 17–18, 2020 scheduled meeting was cancelled. The March 2 and March 15 unscheduled meetings and separate notation votes fall outside this sample. Regular meetings contribute their policy decision as published. Meeting minutes, press conferences, linked implementation notes, media contacts and navigation are excluded. Original paragraph boundaries are retained, including the distinct dissent paragraph on September 16, 2020. [2020 calendar](https://www.federalreserve.gov/monetarypolicy/fomchistorical2020.htm) · [September decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20200916a.htm)

Every press release specifies 2:00 p.m. Eastern, with 39 EDT and 16 EST labels. The fetcher reads the clock and time-zone label from each release and checks them against the local calendar date, URL date and time-zone rules. For all 38 releases eligible under the March 2019 model-vintage cutoff, the statement page's displayed last-update date equals the publication date. January 31, 2018 is the sole earlier record carrying a next-day update label. It predates model eligibility. The source is the Board's retrospective archive, so matching dates alone cannot establish a contemporaneous, timestamped snapshot of every web revision. [January 2018 decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20180131a.htm)

## Reproduction

Run these commands from the folder containing this file. Verification is offline. The second command reconstructs a separate JSONL from the Board's website, preserving raw downloads in the specified cache.

```sh
python fetch_statements.py
python fetch_statements.py --fetch /tmp/gr5398-fomc-html --output /tmp/gr5398-fomc-rebuilt.jsonl
```
