"""Run the course SPY and portfolio evaluators on two otherwise identical engines."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import pandas as pd

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--results', required=True, type=Path, help='Directory produced by train_sentiment.py')
    args = parser.parse_args()
    values = []
    sources = args.source.resolve()
    destination = args.results.resolve()
    with tempfile.TemporaryDirectory(prefix='gr5398-fingpt-eval-') as d:
        isolated = Path(d) / 'source_code'
        shutil.copytree(sources, isolated, ignore=shutil.ignore_patterns('output', 'data', 'student_data',
                                                                         '.git', '__pycache__', '*.pyc'))
        (isolated / 'data').symlink_to(sources / 'data', target_is_directory=True)
        shutil.copytree(destination / 'student_data', isolated / 'student_data')
        shutil.copy2(HERE / 'student_timing.py', isolated / 'timing/student_timing.py')
        for period in ('dev', 'val'):
            output = isolated / 'output'
            result = destination / period
            result.mkdir(exist_ok=True)
            # Explicit limited period choices keep the holdout untouched.
            subprocess.run([sys.executable, 'evaluate_timing.py', '--period', period, '--timing', 'engine', 'student'],
                           cwd=isolated, check=True)
            spy_stats = pd.read_csv(output / f'timing_eval_{period}.csv')
            for name in ('engine', 'student'):
                row = spy_stats[spy_stats.timing == name].iloc[0].dropna().to_dict()
                values.append(dict(period=period, portfolio='SPY', arm=name, **row))
                subprocess.run([sys.executable, 'run_portfolio.py', '--period', period, '--timing', name],
                               cwd=isolated, check=True)
                run = output / f'{period}_timing_{name}'
                stats = json.loads((run / 'stats.json').read_text())
                shutil.copytree(run, result / name, dirs_exist_ok=True)
                values.append(dict(period=period, portfolio='stocks', arm=name, **stats))
            for prefix in ('timing_eval', 'timing_crises'):
                shutil.copy2(output / f'{prefix}_{period}.csv', result)
    pd.DataFrame(values).to_csv(destination / 'paired_comparison.csv', index=False)


if __name__ == '__main__':
    main()
