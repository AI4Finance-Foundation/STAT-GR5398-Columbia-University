"""Download published model inputs and official Federal Reserve press-release indexes."""
import argparse
import hashlib
import subprocess
from pathlib import Path

MODEL_REV = '703af3447380a4fdf35eb5c2c13b281dc3fd2cad'  # February 18, 2019
PHRASE_REV = 'eadad06a324e9580384760ad3fc7b99b1604b75b'
PHRASE_SHA = '0e1a06c4900fdae46091d031068601e3773ba067c7cecb5b0da1dcba5ce989a6'
FED_YEAR = 'https://www.federalreserve.gov/newsevents/pressreleases/{}-press.htm'


def fetch(url, path):
    if not path.is_file():
        tmp = path.with_suffix(path.suffix + '.part')
        subprocess.run(['curl', '--fail', '--silent', '--show-error', '--location', '--retry', '2',
                        url, '-o', str(tmp)], check=True)
        tmp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cache', type=Path)
    cache = parser.parse_args().cache
    cache.mkdir(parents=True, exist_ok=True)
    for name in ('config.json', 'vocab.json', 'merges.txt', 'pytorch_model.bin'):
        fetch(f'https://huggingface.co/openai-community/gpt2/resolve/{MODEL_REV}/{name}', cache / name)
    fp = cache / 'FinancialPhraseBank-v1.0.zip'
    fetch(f'https://huggingface.co/datasets/takala/financial_phrasebank/resolve/{PHRASE_REV}/data/{fp.name}', fp)
    assert hashlib.sha256(fp.read_bytes()).hexdigest() == PHRASE_SHA
    for year in range(2019, 2024):
        fetch(FED_YEAR.format(year), cache / f'{year}.htm')


if __name__ == '__main__':
    main()
