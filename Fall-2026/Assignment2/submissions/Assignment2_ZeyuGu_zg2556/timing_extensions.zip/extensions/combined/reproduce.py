"""Run the frozen FinRobot and FinRL modules together on dev and val."""
import csv
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MODULES = {
    "valuation/student_valuation.py": (
        ROOT / "submissions/Assignment2_ZeyuGu_zg2556/student_valuation.py",
        "1f0a88bee29957c1ad33338120ff3c3017758c243a5540bce97db3a23ea7bf14",
    ),
    "timing/student_timing.py": (
        ROOT / "extensions/finrl/student_timing.py",
        "3556df8f9800a658aaf3e92d2d1c2878314100f0cfdaa05221bfe3ebe6283e16",
    ),
}
RUNS = {"A": "A_selection", "B": "B_valuation", "C": "C_timing_student", "D": "D_both_student"}
METRICS = ("total_return_pct", "sharpe", "max_drawdown_pct", "turnover_per_year")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_rows(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def main():
    source = ROOT / "source_code"
    with (HERE / "standalone_reference.csv").open() as stream:
        references = {(r["period"], r["group"]): r for r in csv.DictReader(stream)}
    with tempfile.TemporaryDirectory() as tmp:
        course = Path(tmp) / "source_code"
        shutil.copytree(source, course, ignore=shutil.ignore_patterns("data", "output", "__pycache__"))
        (course / "data").symlink_to(source / "data", target_is_directory=True)
        for dest, (original, expected) in MODULES.items():
            if digest(original) != expected:
                raise ValueError(f"Archived model has changed: {original.name}")
            shutil.copy2(original, course / dest)

        def evaluate(period):
            subprocess.run([sys.executable, "run_portfolio.py", "--period", period, "--ablation",
                            "--timing", "student"], cwd=course,
                           env=dict(os.environ, PYTHONHASHSEED="0"), check=True)

        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(evaluate, ("dev", "val")))

        out = course / "output"
        ablation, contrasts, checks = [], [], []
        for period in ("dev", "val"):
            stats = {}
            for group, name in RUNS.items():
                directory = out / f"{period}_{name}"
                stats[group] = json.loads((directory / "stats.json").read_text())
                row = stats[group]
                ablation.append({"period": period, "group": group,
                                 **{metric: row[metric] for metric in METRICS},
                                 "cagr_pct": row["cagr_pct"], "volatility_pct": row["volatility_pct"],
                                 "calmar": row["calmar"], "trades": row["trades"]})
                if (period, group) in references:
                    reference = references[period, group]
                    for kind in ("equity", "trades"):
                        actual = digest(directory / f"{kind}.csv")
                        if actual != reference[f"{kind}_sha256"]:
                            raise ValueError(f"{period} {group} differs from {reference['source']} {kind}")
                        checks.append({"period": period, "group": group, "source": reference["source"],
                                       "file": f"{kind}.csv", "match": True, "sha256": actual})

            for metric in METRICS:
                a, b, c, d = (stats[group][metric] for group in RUNS)
                contrasts.append({"period": period, "metric": metric, "B_minus_A": round(b-a, 3),
                                  "C_minus_A": round(c-a, 3), "D_minus_A": round(d-a, 3),
                                  "D_minus_C": round(d-c, 3), "D_minus_B": round(d-b, 3),
                                  "D_minus_B_minus_C_plus_A": round(d-b-c+a, 3)})
        write_rows(out / "ablation.csv", ablation)
        write_rows(out / "contrasts.csv", contrasts)
        write_rows(out / "standalone_checks.csv", checks)
        shutil.copytree(out, HERE / "results", dirs_exist_ok=True)


if __name__ == "__main__":
    main()
