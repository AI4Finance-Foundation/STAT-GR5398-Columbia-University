"""Reproduce the FinRL timing design, input audit and parameter selection.

The three eligible risk budgets are 12%, 16% and 20%. Maximize validation
SPY Sharpe rounded to 3 decimals by the course evaluator. On ties prefer
the budget nearest 16%, then the lower budget. The 16% no-credit run is a
fixed, ineligible diagnostic. The protocol uses only dev and val.

Run from source_code with this file and student_timing.py side by side,
or supply their paths with --course-dir and --module.
"""
import argparse
from datetime import timedelta
import importlib.util
from pathlib import Path
import sys

import numpy as np
import pandas as pd


CANDIDATES = ((0.12, 0.25), (0.16, 0.25), (0.20, 0.25), (0.16, 0.00))


def audit(view, as_of, etfs):
    """Reconstruct the stock engine's readiness and the student input rules."""
    market = view.market_frame()
    history = market.dropna(subset=["close"]).groupby("symbol").size()
    engine_ready = history.get("SPY", 0) >= 200
    sector_count = int((history.reindex(etfs, fill_value=0) >= 200).sum())
    spy = view.close(["SPY"], lookback=100)["SPY"]
    eligible_spy = spy.notna() & np.isfinite(spy) & (spy > 0)
    raw = view.macro("BAA10Y").loc[:pd.Timestamp(as_of - timedelta(days=2))].dropna().tail(252)
    credit = raw[np.isfinite(raw)]
    lag = (as_of - credit.index[-1].date()).days if len(credit) else np.nan
    credit_ready = len(credit) >= 126 and lag <= 7
    high_yield = view.macro("BAMLH0A0HYM2")
    term = view.macro("T10Y2Y")
    return {
        "engine_history_200": engine_ready,
        "engine_vix_available": engine_ready and history.get("^VIX", 0) >= 50,
        "engine_term_available": engine_ready and len(term) > 0,
        "engine_high_yield_available": engine_ready and len(high_yield) > 0,
        "engine_momentum_available": engine_ready,
        "engine_breadth_available": engine_ready and sector_count > 0,
        "engine_news_observed": False,
        "engine_full_sector_panel": engine_ready and sector_count == len(etfs),
        "student_rv_available": bool(len(spy) >= 21 and eligible_spy.tail(21).all()),
        "student_trend_available": bool(len(spy) == 100 and eligible_spy.all()),
        "student_credit_available": credit_ready,
        "baa_date": credit.index[-1].date() if len(credit) else None,
        "baa_age_days": lag,
        "breadth_etfs": sector_count,
    }


def summarize_audit(rows):
    records = []
    for period, group in rows.groupby("period", sort=False):
        for factor in (c for c in group if c.startswith(("engine_", "student_"))):
            observed = group.loc[group[factor]]
            records.append({
                "period": period, "factor": factor, "weekly_decisions": len(group),
                "observed_weeks": len(observed), "observed_pct": round(100 * len(observed) / len(group), 2),
                "first_decision_as_of": observed["as_of"].min() if len(observed) else None,
                "last_decision_as_of": observed["as_of"].max() if len(observed) else None,
            })
    return pd.DataFrame(records)


def run(course_dir, module_path, output_dir):
    sys.path.insert(0, str(course_dir.resolve()))
    from evaluate_timing import simulate
    from shared.data_view import DataBundle, DataView
    from shared.guard import student_call
    from shared.metrics import performance
    from shared.periods import PERIODS
    from timing.engine import SECTOR_ETFS

    spec = importlib.util.spec_from_file_location("candidate_timing", module_path)
    model = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(model)
    bundle = DataBundle.load()
    rows, weekly = [], []
    for period in ("dev", "val"):
        start, end = map(pd.Timestamp, PERIODS[period])
        calendar = bundle.prices.sessions
        sessions = calendar[(calendar >= start) & (calendar <= end)]
        starts = sessions.to_series().groupby(sessions.to_period("W-SUN")).first()
        signals = []
        for day in starts:
            as_of = bundle.prices.last_session_on_or_before(day.date() - timedelta(days=1))
            view = DataView(bundle, as_of)
            with student_call():
                vol, trend, credit = model.risk_inputs(as_of, view)
            signals.append((vol, trend, credit))
            weekly.append({"period": period, "first_session": day.date(), "as_of": as_of,
                           "annual_vol": vol, "trend_stress": trend, "credit_stress": credit,
                           **audit(view, as_of, SECTOR_ETFS)})

        # Include the previous close to match the course SPY simulator's first-day return.
        prior = bundle.prices.last_session_on_or_before(start.date() - timedelta(days=1))
        prices = bundle.prices.close.loc[pd.Timestamp(prior):end, "SPY"]
        for target, weight in CANDIDATES:
            values = [model.size_position(*signal, target_vol=target, credit_weight=weight)
                      for signal in signals]
            exposure = pd.Series(values, index=pd.DatetimeIndex(starts)).reindex(sessions, method="ffill")
            equity = simulate(exposure, prices)
            delta = exposure.diff().abs()
            traded = delta.fillna(exposure.iloc[0]).sum()
            rows.append({"period": period, "target_vol": target, "credit_weight": weight,
                         "eligible": weight == 0.25, **performance(equity),
                         "avg_exposure": round(exposure.mean(), 3),
                         "time_in_market_pct": round((exposure > 0.5).mean() * 100, 1),
                         "exposure_changes": int((delta > 1e-9).sum()),
                         "one_way_exposure_traded_nav": round(traded, 4)})

    metrics = pd.DataFrame(rows)
    candidates = metrics[(metrics["period"] == "val") & metrics["eligible"]].copy()
    candidates["distance_from_16"] = (candidates["target_vol"] - 0.16).abs().round(3)
    winner = candidates.sort_values(["sharpe", "distance_from_16", "target_vol"],
                                    ascending=[False, True, True]).iloc[0]
    metrics["selected"] = metrics["eligible"] & metrics["target_vol"].eq(winner.target_vol)
    audit_rows = pd.DataFrame(weekly)
    output_dir.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(output_dir / "timing_sensitivity.csv", index=False)
    audit_rows.to_csv(output_dir / "factor_audit_weekly.csv", index=False)
    summarize_audit(audit_rows).to_csv(output_dir / "factor_coverage.csv", index=False)
    print(metrics.to_string(index=False))
    print(f"Selected target {winner.target_vol:.0%} at validation Sharpe {winner.sharpe:.3f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--course-dir", type=Path, default=Path.cwd())
    parser.add_argument("--module", type=Path, default=Path(__file__).with_name("student_timing.py"))
    parser.add_argument("--out", type=Path, default=Path("output"))
    args = parser.parse_args()
    run(args.course_dir, args.module, args.out)
