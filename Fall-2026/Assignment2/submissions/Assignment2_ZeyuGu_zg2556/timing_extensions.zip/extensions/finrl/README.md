# Weekly exposure control with a fixed volatility budget

The 20% volatility-target rule reduced the growth portfolio's validation maximum drawdown from 42.52% to 34.37%. Its cumulative return fell from −6.24% to −8.66% and its annualized turnover rose from 9.71× to 10.55×. The course engine had the smallest validation drawdown among the four benchmarks and rules compared. [Validation portfolio results](results/stock_baselines_val.csv)

## Fixed rule and selection

At the close preceding each weekly rebalance, SPY's last 20 daily percentage returns give sample volatility, annualized by √252. The base exposure is the lesser of one and the volatility target divided by realized volatility. Zero observed volatility allows a base of one. A missing volatility estimate sets the final exposure to the 15% floor.

Two signals can each reduce the base by up to one quarter. The trend stress falls linearly from one to zero as SPY moves from 5% below to 5% above its 100-session mean. Credit stress rises linearly from zero to one as the current BAA10Y spread moves from its 75th to 95th trailing percentile. The spread uses up to 252 observations, requires at least 126 and assigns half weight to ties in the percentile rank. The input must be at least two and at most seven calendar days old. The two-day lag allows time for publication. A date-stamped course observation can still reflect a later revision.

The model multiplies the base by `1 − 0.25 × trend stress − 0.25 × credit stress` and clips the result to [0.15, 1.00]. An unavailable trend or credit reading contributes 0.5 to its stress score. The continuous transition avoids an all-or-cash switch around a single moving-average crossing. The floor retains some exposure to a rebound. The stock backtester then applies its 95% invested cap before timing, whole-share sizing and 6 bp execution charge. The standalone SPY simulation charges 6 bp per unit change in exposure.

The three eligible volatility targets span the engine's 16% target by ±4 percentage points. The selection rule uses the highest three-decimal validation SPY Sharpe, with ties broken by proximity to 16% and then by the lower target. A separate no-credit check isolates the effect of the credit signal at 16%. These choices precede the comparison.

| Target | Credit weight | Dev Sharpe | Dev MDD | Val Sharpe | Val MDD |
|---|---:|---:|---:|---:|---:|
| 12% | 25% | 1.096 | −14.15% | 0.224 | −12.61% |
| 16% | 25% | 1.083 | −16.19% | 0.247 | −15.92% |
| **20%, selected** | **25%** | **1.113** | **−16.58%** | **0.305** | **−17.11%** |
| 16%, diagnostic only | 0% | 1.076 | −17.37% | 0.281 | −15.07% |

Higher exposure helped validation Sharpe at the cost of a deeper drawdown. At the fixed 16% target the credit signal improved dev Sharpe by 0.007 and reduced validation Sharpe by 0.034. [Parameter sensitivity and changes in exposure](results/timing_sensitivity.csv)

## Fixed-rule performance in the course simulator

Development covers 2017–2021, validation covers 2022–2023. MDD is the largest peak-to-trough loss. Turnover is annualized traded notional divided by portfolio value. For SPY the initial allocation counts as traded notional. Exposure expresses the average timing multiplier before any stock-portfolio cash buffer.

| SPY | CAGR | Volatility | Sharpe | MDD | Calmar | Exposure | Changes | Turnover/yr |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Dev · full | 18.20% | 18.86% | 0.982 | −33.72% | 0.540 | 100.0% | 0 | 0.20× |
| Dev · SMA200 | 13.73% | 12.74% | 1.074 | −15.86% | 0.866 | 89.4% | 10 | 2.20× |
| Dev · engine | 12.85% | 10.78% | 1.175 | −13.73% | 0.935 | 83.0% | 122 | 2.52× |
| Dev · student | 14.00% | 12.48% | 1.113 | −16.58% | 0.844 | 88.5% | 183 | 2.19× |
| Val · full | 3.39% | 19.46% | 0.268 | −23.93% | 0.142 | 100.0% | 0 | 0.50× |
| Val · SMA200 | 5.16% | 16.80% | 0.383 | −21.31% | 0.242 | 87.4% | 6 | 3.52× |
| Val · engine | 2.38% | 10.29% | 0.280 | −14.41% | 0.165 | 63.3% | 89 | 3.06× |
| Val · student | 2.74% | 10.77% | 0.305 | −17.11% | 0.160 | 50.3% | 53 | 7.44× |

The SPY rules had 261 scheduled weekly decisions in development and 104 in validation. The change count includes weeks where the new multiplier differed from the previous one. The higher validation turnover for the student model coincided with gaps in the volatility input. [Dev SPY results](results/timing_eval_dev.csv) · [Validation SPY results](results/timing_eval_val.csv)

| Stocks | CAGR | Volatility | Sharpe | MDD | Calmar | Exposure | Trades | Turnover/yr |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Dev · full | 26.71% | 28.26% | 0.980 | −32.99% | 0.810 | 100.0% | 1,092 | 10.48× |
| Dev · SMA200 | 17.17% | 22.40% | 0.820 | −39.17% | 0.438 | 89.3% | 948 | 10.84× |
| Dev · engine | 17.93% | 19.74% | 0.934 | −20.90% | 0.858 | 82.9% | 1,344 | 10.23× |
| Dev · student | 18.49% | 21.74% | 0.889 | −25.03% | 0.739 | 88.4% | 1,268 | 10.27× |
| Val · full | −3.20% | 28.44% | 0.028 | −42.52% | −0.075 | 100.0% | 303 | 9.71× |
| Val · SMA200 | 3.26% | 24.59% | 0.253 | −35.66% | 0.091 | 87.5% | 352 | 11.70× |
| Val · engine | 1.89% | 18.24% | 0.194 | −27.70% | 0.068 | 63.3% | 403 | 7.88× |
| Val · student | −4.46% | 19.20% | −0.142 | −34.37% | −0.130 | 51.0% | 451 | 10.55× |

The full portfolio and SMA200 both earned higher validation Sharpe than the student rule. In the timing-only ablation the valuation hook retains all candidates. A and B therefore have identical daily NAVs, as do C and D. The timing contribution C−A was −0.091 Sharpe in development and −0.170 in validation. The analogous improvements in MDD were 7.96 and 8.15 percentage points. The extension contains zero holdout runs. [Dev stock comparisons](results/stock_baselines_dev.csv) · [Validation stock comparisons](results/stock_baselines_val.csv) · [Dev ablation](results/ablation_dev.csv) · [Validation ablation](results/ablation_val.csv)

## Declines avoided and rebounds missed

Entries are differences in percentage points against buy-and-hold SPY for the SPY simulation and against portfolio A for the stock simulation. A positive first number means the rule lost less during the decline. A positive second number means it earned less during the rebound.

| Fall and rebound window | SPY decline avoided | SPY rebound missed | Stock decline avoided | Stock rebound missed |
|---|---:|---:|---:|---:|
| Sep 20–Dec 24, 2018, then to Apr 30, 2019 | 5.52 | 11.75 | 5.54 | 16.00 |
| Feb 19–Mar 23, 2020, then to Aug 31, 2020 | 17.13 | 36.57 | 13.38 | 47.14 |
| Jan 3–Oct 12, 2022, then to Mar 31, 2023 | 8.01 | 1.50 | 8.16 | 2.37 |

The 2020 stock rebound was especially costly. The full selection portfolio gained 74.41% from the trough and the student-timed portfolio gained 27.27%. In the 2022 event the flatter exposure profile retained more of the rebound. Three specified events give limited evidence for generalizing either effect. [SPY dev crises](results/timing_crises_dev.csv) · [SPY validation crisis](results/timing_crises_val.csv) · [Stock dev crises](results/stock_crises_dev.csv) · [Stock validation crisis](results/stock_crises_val.csv)

## Data coverage and simulation limits

- The engine's VIX, term spread, momentum and sector breadth had usable inputs on all 365 weekly decisions. Its high-yield series covered zero of 261 dev weeks and 15 of 104 validation weeks. The engine uses a neutral 0.5 in its absence. Historical news stays at 0.5 throughout. Breadth uses the sectors with enough history, with all 11 ETFs available in 143 dev weeks and every validation week. The extension's lagged BAA10Y spread was available in every week. [Weekly factor coverage](results/factor_coverage.csv)
- The stock backtester uses trading sessions with a SPY close. The wider price matrix used to construct lookback windows and daily SPY returns includes 11 additional VIX-only dates in validation. Requiring a complete 21-observation SPY window produced usable volatility on 63 of 104 weekly decisions. The 100-observation trend window was usable on 22. The rule hit its 15% floor on 202 of 501 validation rows. Gaps mechanically reduced exposure, limiting how much of the observed protection can be attributed to economic signals. The SPY full simulation compounds returns produced by the course percentage-change and missing-value rules. This yielded 6.83% total in validation, while the direct SPY price-endpoint return was 2.65%. A further experiment would rebuild signals on observed SPY trading dates and compare the same validation windows. [Weekly input diagnostics](results/factor_audit_weekly.csv) · [Daily validation paths](results/spy_paths_val.csv) · [SPY validation benchmarks](results/timing_eval_val.csv)
- The student hook uses only closes and lagged macro observations through the decision-date DataView. The course guard and repeatability checks pass on six dates. The fixed rule uses deterministic market and macro inputs. [Automated check](results/check_timing.txt)

## Reproduction

From the Assignment2 directory, install the course packages in Python 3.11 or newer and put the course bundle in `source_code/data/`. Run the extension with the same interpreter used for installation.

```sh
python -m pip install -r source_code/requirements.txt
python extensions/finrl/reproduce.py
```

This command regenerates the fixed-rule results for development and validation in `extensions/finrl/results/`, using a temporary copy of the course source, a pass-through valuation filter and deterministic tie ordering. [Reproduction script](reproduce.py) · [Timing hook](student_timing.py) · [Input audit and parameter selection](research_dev.py) · [Timing evaluation](study_timing.py)
