"""Weekly volatility budget with gradual trend and credit adjustments."""
from __future__ import annotations

import math
from datetime import timedelta

import numpy as np
import pandas as pd


TARGET_VOL = 0.20
MIN_EXPOSURE = 0.15


def _unit(x):
    return float(np.clip(x, 0.0, 1.0))


def risk_inputs(as_of, data):
    """Return realized volatility, trend stress and credit stress at the decision close."""
    as_of = pd.Timestamp(as_of).date()
    price = data.close(["SPY"], lookback=100)["SPY"]
    price = price.where(np.isfinite(price) & (price > 0))
    annual_vol = np.nan
    if len(price) >= 21 and price.tail(21).notna().all():
        returns = price.tail(21).pct_change(fill_method=None).iloc[1:]
        annual_vol = float(returns.std(ddof=1) * math.sqrt(252))

    trend = 0.5
    if len(price) == 100 and price.notna().all():
        distance = price.iloc[-1] / price.mean() - 1.0
        trend = _unit((0.05 - distance) / 0.10)

    # FRED observation dates can precede publication. Discard the latest two
    # calendar days and decline to use observations more than one week old.
    credit = data.macro("BAA10Y").loc[:pd.Timestamp(as_of - timedelta(days=2))].dropna().tail(252)
    credit = credit[np.isfinite(credit)]
    credit_stress = 0.5
    if len(credit) >= 126 and (as_of - credit.index[-1].date()).days <= 7:
        latest = credit.iloc[-1]
        rank = ((credit < latest).sum() + 0.5 * (credit == latest).sum()) / len(credit)
        credit_stress = _unit((rank - 0.75) / 0.20)
    return annual_vol, trend, credit_stress


def size_position(annual_vol, trend, credit, target_vol, credit_weight=0.25):
    """Budget volatility first, then reduce exposure when stress is elevated."""
    if not np.isfinite(annual_vol):
        return MIN_EXPOSURE
    base = min(1.0, target_vol / annual_vol) if annual_vol > 0 else 1.0
    return float(np.clip(base * (1.0 - 0.25 * trend - credit_weight * credit), MIN_EXPOSURE, 1.0))


def exposure(as_of, data) -> float:
    return size_position(*risk_inputs(as_of, data), target_vol=TARGET_VOL)
