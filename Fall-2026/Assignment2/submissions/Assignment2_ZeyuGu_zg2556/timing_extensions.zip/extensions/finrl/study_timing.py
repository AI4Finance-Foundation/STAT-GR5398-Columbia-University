"""Run one pre-specified timing evaluation batch from the course source_code directory."""
import argparse
import os
from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path.cwd()))
from evaluate_timing import COST, exposure_path, simulate
from run_portfolio import CONFIG, run_one, timing_function
from selection import MonthlyScores
from selection.config import load
from shared.data_view import DataBundle
from shared.metrics import crisis_table, performance
from shared.periods import PERIODS, record_test_run

OUT = Path('output')
RULES = ('student', 'full', 'sma200', 'engine')


def run_spy(period, bundle, sessions):
    prices = bundle.prices.close['SPY'].loc[:sessions[-1]]
    benchmark = prices.reindex(sessions) / prices.loc[sessions[0]]
    rows, crises, paths = [], [], pd.DataFrame(index=sessions)
    for name in RULES:
        path = exposure_path(timing_function(name), bundle, sessions)
        equity = simulate(path, prices)
        change = path.diff().abs().fillna(path.iloc[0])
        rows.append(dict(timing=name, **performance(equity), avg_exposure=round(path.mean(), 3),
                         time_in_market_pct=round((path > 0.5).mean()*100, 1),
                         exposure_changes=int((path.diff().abs() > 1e-9).sum()),
                         turnover_per_year=change.sum()*252/len(path),
                         scheduled_rebalances=len(set(sessions.to_period('W-SUN'))),
                         cost_rate=COST))
        event = crisis_table(equity, benchmark)
        if len(event):
            crises.append(event.assign(timing=name))
        paths[name+'_equity'] = equity
        paths[name+'_exposure'] = path
    rows.append(dict(timing='SPY buy & hold', **performance(benchmark), avg_exposure=1.0))
    pd.DataFrame(rows).to_csv(OUT/f'timing_eval_{period}.csv', index=False)
    paths.to_csv(OUT/f'spy_paths_{period}.csv', index_label='date')
    if crises:
        pd.concat(crises).sort_values(['crisis', 'timing']).to_csv(OUT/f'timing_crises_{period}.csv', index=False)


def run_stocks(period, start, end, ctx):
    designs = [('A_selection', False, 'none'), ('B_valuation', True, 'none'),
               ('C_timing_student', False, 'student'), ('D_both_student', True, 'student'),
               ('timing_sma200', False, 'sma200'), ('timing_engine', False, 'engine')]
    rows, curves, events = [], {}, []
    for label, val, timing in designs:
        run = f'{period}_{label}'
        print(f'Running {run}', flush=True)
        row = run_one(run, start, end, valuation=val, timing=timing, stops=False, ctx=ctx)
        equity = pd.read_csv(OUT/run/'equity.csv', index_col=0, parse_dates=True)['equity']
        trades = pd.read_csv(OUT/run/'trades.csv')
        curves[label] = equity
        row['scheduled_rebalances'] = len(set(equity.index.to_period('W-SUN')))
        row['sessions_with_trades'] = trades.date.nunique()
        row['avg_target_multiplier'] = row.get('avg_exposure', 1.0)
        rows.append(row)
        ct = crisis_table(equity, curves['A_selection'])
        if len(ct):
            events.append(ct.assign(run=run))
    frame = pd.DataFrame(rows).set_index('run')
    frame.iloc[:4].to_csv(OUT/f'ablation_{period}.csv')
    frame.to_csv(OUT/f'stock_baselines_{period}.csv')
    if events:
        pd.concat(events).to_csv(OUT/f'stock_crises_{period}.csv', index=False)
    for first, second in ((0, 1), (2, 3)):
        pd.testing.assert_series_equal(curves[designs[first][0]], curves[designs[second][0]], check_exact=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--period', required=True, choices=['dev', 'val'])
    args = parser.parse_args()
    if os.environ.get('PYTHONHASHSEED') != '0':
        raise SystemExit('Run with PYTHONHASHSEED=0 for deterministic ordering of ties in the course execution engine.')
    period = args.period
    start, end = PERIODS[period]
    OUT.mkdir(exist_ok=True)
    record_test_run('study_timing.py', sys.argv[1:], start, end)
    _, options, params, prices, _, universe = load(CONFIG)
    bundle = DataBundle.load(prices=prices)
    sessions = prices.sessions[(prices.sessions >= pd.Timestamp(start)) & (prices.sessions <= pd.Timestamp(end))]
    ctx = dict(options=options, params=params, prices=prices, universe=universe,
               scores=MonthlyScores(), bundle=bundle)
    run_spy(period, bundle, sessions)
    run_stocks(period, start, end, ctx)


if __name__ == '__main__':
    main()
