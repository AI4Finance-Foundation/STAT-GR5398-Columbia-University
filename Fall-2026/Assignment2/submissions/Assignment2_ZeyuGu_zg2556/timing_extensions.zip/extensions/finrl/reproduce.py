"""Reproduce the stand-alone timing extension in an isolated course checkout."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
COURSE = HERE.parents[1] / 'source_code'
RESULTS = HERE / 'results'

def main():
    RESULTS.mkdir(exist_ok=True)
    env = dict(os.environ, PYTHONHASHSEED='0')
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / 'source_code'
        shutil.copytree(COURSE, src, ignore=shutil.ignore_patterns('data', 'output', '__pycache__'))
        (src/'data').symlink_to(COURSE/'data', target_is_directory=True)
        shutil.copy2(HERE/'student_timing.py', src/'timing/student_timing.py')
        (src/'valuation/student_valuation.py').write_text('def filter_candidates(as_of, candidates, data):\n    return candidates\n')
        def run(*args):
            subprocess.run([sys.executable, *map(str, args)], cwd=src, check=True, env=env)
        run(HERE/'research_dev.py', '--out', RESULTS)
        for period in ('dev', 'val'):
            run(HERE/'study_timing.py', '--period', period)
        with (RESULTS/'check_timing.txt').open('w') as f:
            subprocess.run([sys.executable, 'check_submission.py', '--timing'], cwd=src, check=True, env=env, stdout=f)
        shutil.copytree(src/'output', RESULTS, dirs_exist_ok=True)

if __name__ == '__main__':
    main()
