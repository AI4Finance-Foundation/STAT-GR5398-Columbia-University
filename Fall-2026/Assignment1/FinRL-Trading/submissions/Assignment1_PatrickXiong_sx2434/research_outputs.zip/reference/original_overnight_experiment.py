"""Bounded, resumable research run. Original course files remain untouched."""
import argparse
import hashlib
import json
import os
import sqlite3
import sys
import time
import traceback
import warnings
from pathlib import Path

os.environ.setdefault('OMP_NUM_THREADS', '4')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '4')
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
warnings.filterwarnings('ignore', message='X does not have valid feature names')

HERE = Path(__file__).resolve().parent
OUT = HERE / 'finrl_results'
OUT.mkdir(exist_ok=True)


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, default=str, allow_nan=False))
    tmp.replace(path)


def progress(stage, **kwargs):
    state = dict(stage=stage, updated_at=pd.Timestamp.now(tz='America/New_York').isoformat(), **kwargs)
    write_json(OUT / 'status.json', state)
    print(json.dumps(state, default=str), flush=True)


def load_inputs(cache):
    raw_path = cache / 'fundamental_data_full.csv'
    f = pd.read_csv(raw_path)
    assert not f.duplicated(['ticker', 'datadate']).any()
    for c in ['datadate', 'filing_date', 'accepted_date', 'actual_tradedate']:
        f[c] = pd.to_datetime(f[c], errors='coerce')
    f = f.sort_values(['ticker', 'datadate']).reset_index(drop=True)
    nxt = f.groupby('ticker')['trade_price'].shift(-1)
    expected = np.log(nxt / f.trade_price)
    bad_labels = int(((expected - f.y_return).abs() > 1e-4).sum())
    assert bad_labels == 0, 'Raw target differs from next trade-price log return'
    f['label_end'] = f.groupby('ticker')['actual_tradedate'].shift(-1)
    nominal = ((f.datadate.dt.to_period('Q') + 1).dt.start_time
               + pd.DateOffset(months=2))
    # Published timestamps are unreliable for some fiscal/calendar mappings.
    # Delay ALL rows until the course's conservative quarter+2-month schedule.
    # Late recorded filings delay availability further by one business day.
    pub = f[['filing_date', 'accepted_date']].max(axis=1) + pd.offsets.BDay(1)
    f['available'] = pd.concat([nominal.rename('nominal'), pub.rename('pub')], axis=1).max(axis=1)
    f['decision_date'] = nominal
    metadata = {'id', 'ticker', 'datadate', 'gsector', 'y_return', 'created_at',
                'filing_date', 'accepted_date', 'tradedate', 'actual_tradedate',
                'trade_price', 'label_end', 'available', 'decision_date'}
    features = [c for c in f if c not in metadata and pd.api.types.is_numeric_dtype(f[c])]
    f[features] = f[features].replace([np.inf, -np.inf], np.nan)
    m = pd.read_csv(cache / 'sp500_historical_constituents.csv', parse_dates=['date']).sort_values('date')
    membership_dates = m.date.to_numpy()
    membership_sets = [set(s.split(',')) for s in m.tickers]

    def member(tic, date):
        pos = membership_dates.searchsorted(np.datetime64(date), side='right') - 1
        return pos >= 0 and tic in membership_sets[pos]

    keep = [member(t, d) for t, d in zip(f.ticker, f.decision_date)]
    audit = dict(raw_rows=len(f), feature_count=len(features), features=features,
                 membership_removed=int((~np.asarray(keep)).sum()),
                 filing_before_calendar_quarter=int((f.filing_date < f.datadate).sum()),
                 missing_filing=int(f.filing_date.isna().sum()), zero_targets=int((f.y_return == 0).sum()),
                 label_mismatches=bad_labels,
                 assumptions=['Availability delayed to calendar quarter end + two months + one day.',
                              'Retrospective database; original feature vintages and restatements remain unverified.',
                              'Missing filing timestamps use the conservative nominal schedule, not verified disclosure.',
                              'Zero targets excluded pending stale-price audit.'],
                 input_sha256=hashlib.sha256(raw_path.read_bytes()).hexdigest())
    write_json(OUT / 'data_audit.json', audit)
    f = f.loc[keep].copy()
    prices = pd.read_csv(cache / 'prepared' / 'daily.csv', usecols=['tic', 'datadate', 'adj_close'], parse_dates=['datadate'])
    px = prices.pivot(index='datadate', columns='tic', values='adj_close').sort_index()
    return f, features, px, member


def cv_splits(data):
    quarters = sorted(data.datadate.unique())
    n = len(quarters)
    splits = []
    for k in [int(n * .5), int(n * .67), int(n * .83)]:
        if k < 4 or k >= n:
            continue
        start = pd.Timestamp(quarters[k])
        cutoff = data.loc[data.datadate == start, 'decision_date'].min()
        train = np.flatnonzero(((data.datadate < start) & (data.label_end < cutoff) & (data.available <= cutoff)).to_numpy())
        stop = pd.Timestamp(quarters[min(n - 1, k + 2)])
        test = np.flatnonzero(((data.datadate >= start) & (data.datadate <= stop)).to_numpy())
        if len(train) >= 20 and len(test) >= 5:
            splits.append((train, test))
    return splits


def model_specs():
    return {
        'rf': (RandomForestRegressor(random_state=42, n_jobs=4),
               {'model__n_estimators': [150, 300], 'model__min_samples_leaf': [.05, .1], 'model__max_features': ['sqrt']}),
        'xgb': (XGBRegressor(random_state=42, n_jobs=4, tree_method='hist', max_depth=3),
                {'model__learning_rate': [.03, .1], 'model__n_estimators': [150, 300]}),
        'gbm': (LGBMRegressor(random_state=42, n_jobs=4, verbosity=-1, num_leaves=15),
                {'model__learning_rate': [.03, .1], 'model__n_estimators': [150, 300]}),
    }


def train(f, features, end, smoke=False):
    groups = list(f.groupby('gsector', sort=True))
    if smoke:
        groups = groups[:1]
    for sector_i, (sector, frame) in enumerate(groups):
        dest = OUT / 'windows' / sector.replace(' ', '_')
        dest.mkdir(parents=True, exist_ok=True)
        qs = [q for q in sorted(frame.datadate.unique()) if pd.Timestamp(q) >= pd.Timestamp('2020-03-31')]
        if smoke:
            qs = qs[:1]
        all_q = sorted(frame.datadate.unique())
        for q in qs:
            q = pd.Timestamp(q)
            infer = frame.loc[frame.datadate == q].copy()
            decision = infer.decision_date.min()
            if decision >= end:
                continue
            dest_file = dest / (q.strftime('%Y-%m-%d') + '.csv')
            if dest_file.exists():
                continue
            known = frame.loc[(frame.datadate < q) & (frame.available <= decision)
                              & (frame.label_end < decision) & frame.y_return.notna()
                              & (frame.y_return != 0)].copy()
            i = all_q.index(q.to_datetime64())
            split_q = pd.Timestamp(all_q[max(0, i - 4)])
            training = known.loc[known.datadate < split_q].reset_index(drop=True)
            validation = known.loc[known.datadate >= split_q].reset_index(drop=True)
            infer = infer.loc[infer.available <= decision].copy()
            splits = cv_splits(training)
            if len(training) < 40 or len(validation) < 10 or infer.empty or len(splits) < 2:
                progress('skip_window', sector=sector, quarter=q, reason='Insufficient known train/validation data')
                continue
            scores, preds, params, importances = {}, {}, {}, []
            for name, (model, grid) in model_specs().items():
                progress('training', sector=sector, sector_number=sector_i + 1, quarter=q,
                         model=name, train_rows=len(training), validation_rows=len(validation), inference_rows=len(infer))
                pipe = Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)), ('model', model)])
                search = GridSearchCV(pipe, grid, cv=splits, scoring='neg_mean_squared_error', n_jobs=1, error_score='raise')
                search.fit(training[features], training.y_return)
                selected = search.best_estimator_
                scores[name] = float(mean_squared_error(validation.y_return, selected.predict(validation[features])))
                preds[name] = selected.predict(infer[features])
                params[name] = search.best_params_
                vals = selected.named_steps['model'].feature_importances_
                importances.extend([dict(feature=c, importance=float(v), model=name, sector=sector, quarter=str(q.date()))
                                    for c, v in zip(features, vals)])
            winner = min(scores, key=scores.get)
            records = infer[['ticker', 'datadate', 'decision_date', 'available', 'gsector']].reset_index(drop=True)
            for name, p in preds.items():
                records[name] = p
            records['best'] = preds[winner]
            records['winner'] = winner
            write_json(dest_file.with_suffix('.json'), dict(scores=scores, params=params, train_rows=len(training), validation_rows=len(validation)))
            pd.DataFrame(importances).to_csv(dest_file.with_name(dest_file.stem + '_importance.csv'), index=False)
            records.to_csv(dest_file, index=False)
    files = [p for p in (OUT / 'windows').glob('*/*.csv') if not p.stem.endswith('_importance')]
    if not files:
        raise RuntimeError('No training windows completed')
    pred = pd.concat([pd.read_csv(p, parse_dates=['datadate', 'decision_date', 'available']) for p in files], ignore_index=True)
    pred.to_csv(OUT / 'predictions.csv', index=False)
    importance_files = list((OUT / 'windows').glob('*/*_importance.csv'))
    imp = pd.concat([pd.read_csv(p) for p in importance_files], ignore_index=True)
    imp.groupby(['model', 'feature']).importance.mean().sort_values(ascending=False).to_csv(OUT / 'feature_importance.csv')
    return pred


def metrics(returns):
    nav = (1 + returns).cumprod()
    years = (returns.index[-1] - returns.index[0]).days / 365.25
    sd = returns.std(ddof=1)
    return dict(cumulative=float(nav.iloc[-1] - 1), cagr=float(nav.iloc[-1] ** (1 / years) - 1),
                volatility=float(sd * np.sqrt(252)), sharpe_rf0=float(returns.mean() / sd * np.sqrt(252)) if sd > 0 else 0.,
                max_drawdown=float((nav / nav.cummax().clip(lower=1) - 1).min()))


def backtest(pred, px, member, cache):
    # Three predeclared variants; do not select the best using the test period.
    dates = px.index[px.index >= pred.decision_date.min()]
    if len(dates) < 2:
        raise RuntimeError('No available price-backed test window')
    pred = pred.loc[pred.decision_date <= px.index[-1]].copy()
    variants = {'top25_equal': (.25, False), 'top10_equal': (.10, False), 'top25_sector_equal': (.25, True)}
    navs, summaries, missing_all, excluded_all = {}, [], [], []
    px = px.loc[:, sorted(set(pred.ticker) & set(px.columns))]
    marked = px.ffill()
    ret = marked.pct_change(fill_method=None)
    for name, (frac, sector_equal) in variants.items():
        holdings = pd.Series(0., index=px.columns)
        records = []
        decisions = {}
        for date, rows in pred.groupby('decision_date'):
            idx = dates.searchsorted(date)
            if idx < len(dates):
                decisions[dates[idx]] = rows
        for date in dates:
            live = holdings > 1e-12
            missing = live & px.loc[date].isna()
            if missing.any():
                missing_all.extend([dict(strategy=name, date=str(date.date()), ticker=t, weight=float(holdings[t])) for t in holdings.index[missing]])
            rr = ret.loc[date].fillna(0)
            gross = float((holdings * rr).sum())
            drifted = holdings * (1 + rr) / (1 + gross)
            turnover = 0.
            if date in decisions:
                rows = decisions[date].copy()
                eligible = [t in px.columns and pd.notna(px.at[date, t]) and member(t, date) for t in rows.ticker]
                excluded_all.extend([dict(strategy=name, date=str(date.date()), ticker=t) for t in rows.loc[~np.asarray(eligible), 'ticker']])
                rows = rows.loc[eligible].sort_values('best', ascending=False)
                if not rows.empty:
                    target = pd.Series(0., index=px.columns)
                    if sector_equal:
                        sectors = list(rows.groupby('gsector'))
                        for sector, sub in sectors:
                            chosen = sub.head(max(1, int(np.ceil(len(sub) * frac))))
                            target.loc[chosen.ticker] = 1 / len(sectors) / len(chosen)
                    else:
                        chosen = rows.head(max(1, int(np.ceil(len(rows) * frac))))
                        target.loc[chosen.ticker] = 1 / len(chosen)
                    # An unquoted existing position cannot be liquidated at a fabricated price.
                    target.loc[missing] = drifted.loc[missing]
                    quoteable = ~missing
                    total = target.loc[quoteable].sum()
                    if total > 0:
                        target.loc[quoteable] *= max(0., 1 - target.loc[missing].sum()) / total
                    turnover = float((target - drifted).abs().sum())
                    holdings = target
                else:
                    holdings = drifted
            else:
                holdings = drifted
            cost = .001 * turnover
            # Trading happens at this close; the resulting weights earn next day's return.
            records.append(dict(date=date, gross_ret=gross, turnover=turnover, cost=cost,
                                net_ret=(1 + gross) * (1 - cost) - 1, missing_held=int(missing.sum())))
        result = pd.DataFrame(records).set_index('date')
        result['nav'] = (1 + result.net_ret).cumprod()
        result.to_csv(OUT / (name + '_daily.csv'))
        navs[name] = result.nav
        audit_valid = int(result.missing_held.sum()) == 0
        for sample, sub in [('full', result), ('pre_2024', result.loc[result.index < '2024-01-01']), ('holdout_2024_onward', result.loc[result.index >= '2024-01-01'])]:
            if len(sub) > 20:
                summaries.append(dict(strategy=name, sample=sample, **metrics(sub.net_ret),
                                      annual_turnover=float(sub.turnover.mean() * 252),
                                      price_coverage_complete=audit_valid, start=str(sub.index[0].date()), end=str(sub.index[-1].date())))
    pd.DataFrame(missing_all, columns=['strategy', 'date', 'ticker', 'weight']).to_csv(OUT / 'missing_held_prices.csv', index=False)
    pd.DataFrame(excluded_all, columns=['strategy', 'date', 'ticker']).to_csv(OUT / 'entry_exclusions.csv', index=False)
    # Cached price table contains benchmarks from 2020-12-01. Try public download
    # for full coverage, but preserve strategy results if the network is unavailable.
    import yfinance as yf
    for tic in ['SPY', 'QQQ']:
        try:
            p = yf.download(tic, start=str((dates[0] - pd.Timedelta(days=7)).date()),
                            end=str((dates[-1] + pd.Timedelta(days=1)).date()),
                            auto_adjust=True, progress=False, multi_level_index=False, timeout=25)
            if p.empty:
                raise RuntimeError('Public benchmark download empty')
            series = p.Close
        except Exception as exc:
            print(f'Benchmark {tic} fallback: {exc}', flush=True)
            with sqlite3.connect(cache / 'finrl_trading.db') as conn:
                p = pd.read_sql_query('SELECT date,adj_close FROM price_data WHERE ticker=? ORDER BY date', conn, params=[tic], parse_dates=['date'])
            series = p.set_index('date').adj_close
        series.to_csv(OUT / (tic + '_adjusted_close.csv'))
        coverage = series.reindex(dates)
        if coverage.notna().all():
            benchmark = series.pct_change(fill_method=None).reindex(dates)
            if benchmark.notna().all():
                benchmark.iloc[0] = 0.  # Common initial close; no pre-entry return.
                navs[tic] = (1 + benchmark).cumprod()
                for sample, sub in [('full', benchmark), ('pre_2024', benchmark.loc[benchmark.index < '2024-01-01']), ('holdout_2024_onward', benchmark.loc[benchmark.index >= '2024-01-01'])]:
                    if len(sub) > 20:
                        summaries.append(dict(strategy=tic, sample=sample, **metrics(sub), annual_turnover=0., price_coverage_complete=True,
                                              start=str(sub.index[0].date()), end=str(sub.index[-1].date())))
        else:
            print(f'{tic}: insufficient full-window coverage; no mismatched full-window benchmark reported', flush=True)
    pd.DataFrame(summaries).to_csv(OUT / 'metrics.csv', index=False)
    pd.DataFrame(navs).to_csv(OUT / 'nav_comparison.csv')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(11, 6))
    for name, curve in navs.items():
        ax.plot(curve.index, curve, label=name)
    ax.set(title='Research run: close-to-close, next-day holdings', ylabel='NAV', xlabel='Date')
    ax.legend(); ax.grid(alpha=.2); fig.tight_layout()
    fig.savefig(OUT / 'nav_comparison.png', dpi=160)
    plt.close(fig)
    (OUT / 'README.md').write_text('''# Overnight FinRL research run

New raw-data training with train-only median imputation, forward quarter CV,
purged labels, outer validation, quarterly execution, 0.1% traded-notional cost,
drifting holdings and next-day close-to-close returns. Original baseline untouched.
53 features include adj_close_q. Three predeclared portfolios are evaluated;
2024 onward is shown separately and must not be used to select parameters.

This is an experiment, not a validated final submission. Historical feature
vintages/restatements and anomalous filing metadata remain unverified. Entry
requires a contemporaneous quote and historical index membership; unavailable
historical tickers create a coverage-limited universe, not a fully bias-free one.
Held missing quotes are explicitly logged and carried at their last price;
those metrics are provisional and delisting outcomes need authoritative data.
Benchmark adjusted closes use the same return dates when coverage permits.
Transaction execution assumes the recorded close without slippage; verify this
assumption before final reporting. Full assignment/report/blog are not complete.
''')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cache', required=True, type=Path)
    ap.add_argument('--smoke', action='store_true')
    args = ap.parse_args()
    t = time.time()
    progress('loading')
    f, features, px, member = load_inputs(args.cache)
    end = px.index[-1]
    progress('inputs_ready', rows=len(f), feature_count=len(features), price_end=end)
    pred = train(f, features, end, args.smoke)
    progress('backtesting', prediction_rows=len(pred))
    if not args.smoke:
        backtest(pred, px, member, args.cache)
    progress('smoke_completed' if args.smoke else 'completed', elapsed_minutes=round((time.time() - t) / 60, 2), prediction_rows=len(pred))


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        progress('failed', error=str(exc))
        traceback.print_exc()
        sys.exit(1)
