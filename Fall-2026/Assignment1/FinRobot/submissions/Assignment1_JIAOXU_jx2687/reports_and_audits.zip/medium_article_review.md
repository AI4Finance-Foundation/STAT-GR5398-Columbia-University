# Medium article review

Date:2026-10-11. Canonical manuscript:medium_article.md; medium_draft.md mirrors it. Previous stale outline is retained as medium_outline_previous.md and is not for publication.

| Headline claim | Evidence file | Check |
| --- | --- | --- |
| Six actual baseline companies, eight sections each | audit/actual_execution_summary.csv; agent_evidence/*.json | Verified |
| Five formal Technology names; GOOGL outside sector | audit/sector_evidence.csv | Verified |
| 20 metric comparisons:16 matches,4 definition differences | audit/fmp_data_audit.csv | Verified; unreconciled differences retained |
| AMD D&A3004m; EBITDA proxy6698m; provider7275m | AMD original10K; audit/fmp_data_audit.csv; analyze_fmp_actual.py | Verified;577m difference |
| Future-year validity8/15 to15/15 | audit/fmp_temporal_validity.csv | Verified; metric is chronological only |
| 68 backtests;MAPE13.74% to15.86% | audit/forecast_backtest.csv | Recomputed; separate five-company SEC sample |
| 576 claims;177/397/2 labels | audit/grounding_claims.csv | Recomputed; provisional evaluation, not truth rate |
| Eight section rates and five corrections | audit/grounding_section_scorecard.csv;grounding_review_corrections.csv | Recomputed; extraction/entailment not fully independent |
| Three identical-input NVDA runs; risks category order prescribed | evaluation/NVDA_run2,NVDA_run3; risks_agent.py | Verified; no stability inference from headings |
| Rating/target variance undefined | audit/stability_actual.csv;stability_summary.json | Missing values explicitly retained |
| FiveDCF arithmetic checks and45 sensitivities | audit/fmp_valuation_audit.csv;fmp_full_dcf_sensitivity.csv | Verified; assumptions not validated |
| Runtime35.5-42.0seconds; recordedcost~$1.07 | actual_execution_summary.csv;api_cost_ledger.csv | Recomputed; exclusions stated |

Editorial checks: no fabricated company recommendation, no Unsupported=necessarily false equivalence, no forecast backtest sample conflation, no causal attribution inferred from financial correlation, no missing-value variance=zero claim, no exact total-billing claim, no statement that the article has been published. AI-assisted drafting and author review disclosed. Course requirement states analysis rather than pasted AI equity report; this is a new methods/results analysis, not a copy of generated company reports. This review does not establish permission under an unverified university-wide AI policy.

Audience/shape: technical course blog; user-selected manuscript is the primary artifact. Technical skill structure maps to opening findings, audit evidence tables, scope and methods, limitations, next steps and open questions. One compact rate table is sufficient; no new financial chart is needed for this editorial follow-up.

Source-link check: course README, GPT-4.1 official documentation and AMD issuer-hosted10K opened successfully. The web renderer returned an internal error for the NVIDIA PDF URL; verification uses the preserved original PDF and its recorded lineage, not a claim of successful live-page rendering.
