# FinRobot Assignment 1: current verified handoff

Deadline: October12,2026; exact hour/timezone unconfirmed. CourseWorks course timezone America/New_York does not establish submission cutoff. Course originals are in course/. Original code commit2717499b8e30f242640af08c4ad9afd1113c2d45, finrobot_equity, not the optional old notebook.

## Results and limitations

All five course starter names NVDA, AMD, INTC, AAPL, GOOGL ran the actual two-step CLI; formal same-sector Technology universe is NVDA, AMD, INTC, AAPL, MSFT. Every name has eight actual typed-agent evidence files and generated HTML reports, model gpt-4.1-2025-04-14. Two peers are configured per name; semiconductor versus hardware/software comparability is a limitation. Financial histories and quote snapshots have distinct retrieval dates recorded in FMP cache; do not call annual metrics live TTM.

Actual FMP financial audit:20 comparisons (NVDA,AMD):16 matches and4 EBITDA/margin definition differences. Source lineages, original NVIDIA annual report and original AMD issuer-hosted10K are saved. AMD D&A750+2254=3004million; FMP EBITDA includes a different non-operating adjustment basis. No unexplained discrepancy was hidden.

DCF: five independent arithmetic recomputations agree;45 full WACC/terminal-growth sensitivity cases saved. CFO minus capex is not unleveredFCFF; synthetic net debt10%EV and weighted-average diluted shares are material weaknesses. Intel negative raw DCF is floored at0 by the helper; this is an assumption failure, not a fair-value claim. Financial conclusions:NVDA growth/margin strength versus high valuation and baseline forecast-label errors;AMD expanding revenue with EBITDA-definition caveats;Intel negativeFCF invalidates a simplistic constant-growthDCF;Apple andMicrosoft positiveFCF do not establish an attractive investment without defensible discount/growth/debt assumptions. No Buy/Sell recommendation is justified by this mechanical audit.

Forecast improvement: actual-FMP future-year validity8/15 to15/15; SEC companion68 rolling-origin forecasts pooledMAPE13.7372% to15.8580%(worse). This is temporal consistency improvement, not validated predictive improvement. Forecast floor/cap and flat margins are assumptions, not learned macroeconomic relationships.

Grounding: claims were extracted and classified across all8 sections of NVDA,AMD,INTC. The same model performs provisional auditing; literal evidence excerpts are checked programmatically and nonliteral citations flagged separately. Formatting differences alone do not determine support. This does not independently prove entailment or extraction completeness. Counts and rates are actual computed automated evaluation results, not instructor-provided metrics beyond the required supported/total formula. Manual adjudication remains recommended. An actual news-agent output asserts headlines/analyst consensus despite no accessible news in its prompt. Agent instructions request regulatory/supply-chain context without supplying source evidence or an implemented browser tool; this structurally invites unsupported prior knowledge. Model prose should be reviewed before use.

Stability: NVDA has three real runs using identical saved financial user prompts and unchanged system instructions; full section outputs preserved. Rating/target absence is reported as missing, not zero variance. Top3 risks extracted with quoted excerpts (some abbreviated); category order is specified by the original risk prompt; semantic clustering requires review. HTML rating/target from Step2 market-fetch/default fields are separate from agent decisions; free-float95% and a trailingPE labelledforwardPE are upstream weaknesses. Never treat these defaults as measured financial facts.

Model usage costs use officialGPT4.1 rates ($2 input,$0.50cachedinput,$8output per milliontokens). API cost ledger covers saved report/repetition/evaluation responses. Several tiny preflight/debug responses were not fully recorded; total ledger is not a billing reconciliation. Actual provider charges may differ; billing dashboard is authoritative.

## Reproduce

Use the separate work/finrobot_env Python3.12.14; requirements.lock.txt contains installed versions. Private credentials are outside this deliverable. From workspace root:

```sh
work/finrobot_env/bin/python outputs/finrobot_assignment1/code/run_data_only.py --config work/private/config.ini
work/finrobot_env/bin/python outputs/finrobot_assignment1/code/analyze_fmp_actual.py
work/finrobot_env/bin/python outputs/finrobot_assignment1/code/run_actual_pipeline.py --config work/private/config.ini
work/finrobot_env/bin/python outputs/finrobot_assignment1/code/run_actual_pipeline.py --config work/private/config.ini --ticker GOOGL
work/finrobot_env/bin/python outputs/finrobot_assignment1/code/evaluate_agents.py work/private/config.ini
```

Scripts cache requests and evaluation artifacts; preserve them rather than rerun blindly. prepare_upstream.py applies improvement.patch,compatibility.patch,agent_alignment.patch to pinned originals on clean extraction. All three patches apply sequentially. Compatibility adapter is necessary because new FMP accounts cannot use legacyv3; no fabricated financial rows are introduced. Typed-agent wiring records actual prompts/output schemas/usage and disables tracing. Provider failure raises rather than writing canned successful text. NewsHTTP402 is disclosed; no claim of retrieving paid news.

## Assignment requirement checklist

| Requirement | Status | Evidence |
|---|---|---|
| Course-specified finrobot_equity; starter five | Complete | course/FinRobot_README.md Part0; actual_execution_summary.csv |
| Five companies same sector; two peers each | Complete with comparability limitation | Part1; formal five actual_runs/baseline peer CSVs |
| Two companies, ten metrics vs filings | Complete audit; four unresolved definition differences | Part2.1; fmp_data_audit.csv,filing_crosscheck.csv |
| Forecast/valuation audit and independent sensitivity | Complete with disclosed assumptions | Part2.2; fmp_valuation_audit.csv,fmp_full_dcf_sensitivity.csv |
| Eight sections across three companies grounding | Automated provisional evaluation complete; independent review incomplete | Part2.3; grounding_claims.csv,grounding_rates.csv |
| Same inputs three-run stability | Complete actual runs; absent decisions disclosed | Part2.3; stability_actual.csv,stability_summary.json,evaluation/NVDA_run* |
| One improvement and before/after | Complete; accuracy result negative | Part3B; improvement.patch,fmp_temporal_validity.csv,forecast_scorecard.csv |
| Research PDF with methodology/cost/runtime/judgment | Complete working research report | Part4; research_report.pdf,api_cost_ledger.csv,actual_execution_summary.csv |
| Medium student analysis publication | Not published | Part4; medium_article.md is a completed, checked AI-assisted article draft; not a publication |
| Name_UNI submission folder and course PR | Not submitted; identity not provided | Part8; user prohibits pushing/submission |
| Exact cutoff hour/timezone | Unable to confirm | Course original states date only; CourseWorks inspection findings |

Remaining personal steps:review your conclusions/AI assistance disclosure,review the completed medium_article.md draft and publish it under your own account if course policy permits,fill Name_UNI and follow course submission instructions. No GitHub push,submission,email orpublication was performed. Original FinRL project and its Positron kernel were untouched.

Saved API ledger subtotal: $1.0731; recorded input tokens:203218,output tokens:87917. Actual claim labels:{'Unsupported': 397, 'Supported': 177, 'Contradicted': 2}.

| section             |   total |   supported |   unsupported |   contradicted |   grounding_rate |
|:--------------------|--------:|------------:|--------------:|---------------:|-----------------:|
| company_overview    |     105 |          14 |            91 |              0 |         0.133333 |
| competitor_analysis |      73 |           8 |            65 |              0 |         0.109589 |
| investment_overview |      81 |          44 |            37 |              0 |         0.54321  |
| major_takeaways     |      63 |          33 |            30 |              0 |         0.52381  |
| news_summary        |      62 |          18 |            44 |              0 |         0.290323 |
| risks               |     104 |          22 |            82 |              0 |         0.211538 |
| tagline             |      24 |           5 |            17 |              2 |         0.208333 |
| valuation_overview  |      64 |          33 |            31 |              0 |         0.515625 |


Medium manuscript update: the full English article has been drafted and numerically checked. Canonical file:medium_article.md; check record:medium_article_review.md. medium_draft.md mirrors the article; medium_outline_previous.md preserves the superseded outline and is not for publication. Publication remains unperformed.
